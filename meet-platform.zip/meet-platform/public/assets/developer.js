document.addEventListener("DOMContentLoaded", function () {
    "use strict";
    const $ = (s, r=document) => r.querySelector(s);
    const $$ = (s, r=document) => [...r.querySelectorAll(s)];
    // theme
    $("#themeToggle").addEventListener("click", () => {
      const next = document.documentElement.getAttribute("data-theme") === "light" ? "dark" : "light";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem("theme", next);
    });
    // ---- i18n (bilingual EN / AR) ----
    // Dynamic strings set by JS (not in the DOM at load), keyed by language.
    const I18N = {
      en: { show:"Show", hide:"Hide", copy:"Copy", copied:"Copied", generate:"Generate", regenerate:"Regenerate",
        noKey:"No key yet — click Generate.", loadFail:"Couldn't load key.", keyCopied:"Key copied", newKey:"New key generated",
        confirmRegen:"Regenerate your API key? The current key will stop working immediately." },
      ar: { show:"إظهار", hide:"إخفاء", copy:"نسخ", copied:"تم النسخ", generate:"توليد", regenerate:"إعادة توليد",
        noKey:"لا يوجد مفتاح بعد — اضغط توليد.", loadFail:"تعذّر تحميل المفتاح.", keyCopied:"نُسخ المفتاح", newKey:"تم توليد مفتاح جديد",
        confirmRegen:"إعادة توليد مفتاح الـ API؟ سيتوقّف المفتاح الحالي عن العمل فورًا." }
    };
    let LANG = (() => { try { const l = localStorage.getItem("lang"); return (l==="ar"||l==="en") ? l : "en"; } catch(_) { return "en"; } })();
    const t = (k) => (I18N[LANG] && I18N[LANG][k]) || I18N.en[k] || k;

    // Capture the original English markup so we can restore it.
    $$("[data-ar]").forEach(el => { el.setAttribute("data-en", el.innerHTML); });
    $$("[data-ar-title]").forEach(el => { el.setAttribute("data-en-title", el.getAttribute("title") || ""); });

    function applyLang(lang) {
      LANG = (lang === "ar") ? "ar" : "en";
      try { localStorage.setItem("lang", LANG); } catch(_){}
      const ar = LANG === "ar";
      document.documentElement.lang = ar ? "ar" : "en";
      document.documentElement.dir  = ar ? "rtl" : "ltr";
      $$("[data-ar]").forEach(el => { el.innerHTML = ar ? el.getAttribute("data-ar") : el.getAttribute("data-en"); });
      $$("[data-ar-title]").forEach(el => { el.setAttribute("title", ar ? el.getAttribute("data-ar-title") : el.getAttribute("data-en-title")); });
      const lt = $("#langToggle"); if (lt) lt.textContent = ar ? "EN" : "ع";
      renderKey();                                   // dynamic key-card strings
      $$("pre .cp").forEach(b => { if (b.textContent !== t("copied")) b.textContent = t("copy"); });
    }
    $("#langToggle").addEventListener("click", () => applyLang(LANG === "ar" ? "en" : "ar"));


    function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove("show"),1800); }

    // base url everywhere
    const yrEl = $("#yr"); if (yrEl) yrEl.textContent = new Date().getFullYear();
    const BASE = location.origin;
    $("#baseUrl").textContent = BASE;
    $$("pre").forEach(p => { p.innerHTML = p.innerHTML.replace(/\$BASE/g, BASE).replace(/EMBED_URL_FROM_RESPONSE/g, BASE + "/embed.html#token=…&url=…"); });

    // copy buttons on every code block
    $$("pre").forEach(p => {
      const code = p.textContent;   // capture before adding the button
      const b = document.createElement("button");
      b.className = "cp"; b.textContent = t("copy");
      b.addEventListener("click", () => { navigator.clipboard.writeText(code.trim()).then(()=>{ b.textContent=t("copied"); toast(t("copied")); setTimeout(()=>b.textContent=t("copy"),1200); }); });
      p.appendChild(b);
    });

    // tabbed examples
    $$(".tabs").forEach(tabs => {
      const group = tabs.getAttribute("data-tabs");
      tabs.addEventListener("click", e => {
        const btn = e.target.closest(".tab"); if(!btn) return;
        $$(".tab", tabs).forEach(t=>t.classList.toggle("on", t===btn));
        const sel = btn.getAttribute("data-t");
        $$(`pre[data-tabgroup="${group}"]`).forEach(pre => { pre.style.display = pre.getAttribute("data-t")===sel ? "" : "none"; });
      });
    });

    // ---- API token management ----
    const api = {
      async req(path, opts={}) {
        const res = await fetch("/api"+path, { credentials:"include", headers:{ "Content-Type":"application/json" }, ...opts });
        let data=null; try{ data=await res.json(); }catch(_){}
        if (res.status === 401) { location.href = "/login.html?next=" + encodeURIComponent("/developer.html"); throw new Error("auth"); }
        if (!res.ok) throw new Error((data&&data.error)||("Error "+res.status));
        return data;
      }
    };
    let apiToken = null, revealed = false;
    const keyBox = $("#keyBox");
    function mask(t){ return t ? t.slice(0,12) + "•".repeat(Math.max(6, t.length-16)) + t.slice(-4) : ""; }
    function renderKey(){
      if (!apiToken) { keyBox.textContent = t("noKey"); $("#genLbl").textContent=t("generate"); $("#btnReveal").disabled=true; $("#btnCopy").disabled=true; return; }
      keyBox.textContent = revealed ? apiToken : mask(apiToken);
      $("#genLbl").textContent = t("regenerate");
      $("#btnReveal").disabled=false; $("#btnCopy").disabled=false;
      $("#btnReveal").lastChild.textContent = " " + (revealed ? t("hide") : t("show"));
    }
    $("#btnReveal").addEventListener("click", () => { revealed=!revealed; renderKey(); });
    $("#btnCopy").addEventListener("click", () => { if(apiToken) navigator.clipboard.writeText(apiToken).then(()=>toast(t("keyCopied"))); });
    $("#btnGen").addEventListener("click", async () => {
      if (apiToken && !(await App.confirm(t("confirmRegen"), { title: LANG === "ar" ? "تجديد المفتاح" : "Regenerate key", ok: LANG === "ar" ? "تجديد" : "Regenerate" }))) return;
      $("#btnGen").disabled=true;
      try { const d = await api.req("/account/api-token", { method:"POST" }); apiToken=d.apiToken; revealed=true; renderKey(); toast(t("newKey")); }
      catch(e){ if(e.message!=="auth") toast(e.message); }
      finally{ $("#btnGen").disabled=false; }
    });
    (async () => {
      try { const d = await api.req("/account/api-token"); apiToken=d.apiToken; renderKey(); }
      catch(e){ if(e.message!=="auth"){ keyBox.textContent=t("loadFail"); toast(e.message);} }
    })();

    applyLang(LANG);   // set initial language (restores English or swaps to Arabic)
  
});
