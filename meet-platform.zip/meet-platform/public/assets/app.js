/* ============================================================
   app.js — أدوات مشتركة: الثيم، api()، toast، الأيقونات، المستخدم
   يُربَط: <script src="/assets/app.js?v=1" defer></script>
   ============================================================ */
(function () {
  "use strict";

  /* ---------- الثيم (بلا وميض عند التحميل من <head>) ---------- */
  var THEME_KEY = "theme";
  function systemDark() { return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches; }
  function resolveTheme(pref) { return pref === "dark" || pref === "light" ? pref : (systemDark() ? "dark" : "light"); }
  function applyTheme(pref) {
    var mode = resolveTheme(pref);
    document.documentElement.setAttribute("data-theme", mode);
    return mode;
  }
  function getThemePref() { try { return localStorage.getItem(THEME_KEY) || "auto"; } catch (e) { return "auto"; } }
  function setThemePref(pref) {
    try { pref === "auto" ? localStorage.removeItem(THEME_KEY) : localStorage.setItem(THEME_KEY, pref); } catch (e) {}
    return applyTheme(pref);
  }
  function toggleTheme() {
    var now = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    return setThemePref(now);
  }
  // تطبيق فوري
  applyTheme(getThemePref());
  if (window.matchMedia) {
    try {
      window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", function () {
        if (getThemePref() === "auto") applyTheme("auto");
      });
    } catch (e) {}
  }

  /* ---------- الكوكيز / CSRF ---------- */
  function getCookie(name) {
    var m = document.cookie.match("(?:^|; )" + name.replace(/([.$?*|{}()\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)");
    return m ? decodeURIComponent(m[1]) : null;
  }
  function csrfToken() { return getCookie("meet_csrf") || ""; }

  /* ---------- api() — fetch موحّد مع CSRF تلقائي ---------- */
  async function api(path, opts) {
    opts = opts || {};
    var method = (opts.method || "GET").toUpperCase();
    var headers = Object.assign({ "Accept": "application/json" }, opts.headers || {});
    var body = opts.body;
    if (body && typeof body === "object" && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    if (method !== "GET" && method !== "HEAD") {
      var t = csrfToken();
      if (t) headers["X-CSRF-Token"] = t;
    }
    var url = path.charAt(0) === "/" ? path : "/api/" + path;
    if (url.indexOf("/api/") !== 0 && url.charAt(0) === "/") { /* مسار مطلق كما هو */ }
    var res = await fetch(url, { method: method, headers: headers, body: body, credentials: "same-origin" });
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var msg = (data && (data.error || data.message)) || ("HTTP " + res.status);
      var err = new Error(msg); err.status = res.status; err.data = data;
      if (res.status === 401 && !opts.noRedirect) { location.href = "/login.html"; }
      throw err;
    }
    return data;
  }

  /* ---------- toast ---------- */
  function toastHost() {
    var h = document.getElementById("toastHost");
    if (!h) { h = document.createElement("div"); h.id = "toastHost"; h.className = "toast-host"; document.body.appendChild(h); }
    return h;
  }
  function toast(msg, kind) {
    var el = document.createElement("div");
    el.className = "toast " + (kind === "err" ? "err" : "ok");
    el.textContent = msg;
    toastHost().appendChild(el);
    setTimeout(function () { el.style.opacity = "0"; el.style.transition = "opacity .25s"; setTimeout(function () { el.remove(); }, 260); }, 2600);
  }

  /* ---------- المستخدم / الخروج ---------- */
  var _me = null;
  async function me(force) {
    if (_me && !force) return _me;
    var d = await api("/api/auth/me", { noRedirect: true });
    _me = d && d.user ? d.user : d;
    return _me;
  }
  async function logout() {
    try { await api("/api/auth/logout", { method: "POST" }); } catch (e) {}
    location.href = "/login.html";
  }
  function initials(name) {
    if (!name) return "؟";
    var p = String(name).trim().split(/\s+/);
    return (p[0] ? p[0][0] : "") + (p[1] ? p[1][0] : "");
  }

  /* ---------- أدوات DOM مختصرة ---------- */
  function el(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  /* ---------- الأيقونات (سبرايت مضمّن) ---------- */
  var ICONS = {
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 6.8 19.4l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3 15H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 6.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 9 3.6V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a2 2 0 1 1 0 4h-.1z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    sun: '<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    code: '<path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l2 2M14 9l2 2"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    device: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5 5h14l3 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z"/>',
    video: '<path d="M15 10l4.5-3v10L15 14"/><rect x="2" y="6" width="13" height="12" rx="2"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5"/><path d="M16 5a3.5 3.5 0 0 1 0 6.5M22 20c0-2.6-1.4-4.3-3.5-5"/>',
    history: '<path d="M3 3v6h6"/><path d="M3.5 9a9 9 0 1 1-1 5"/><path d="M12 8v5l3 2"/>',
    link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1.5-1.5"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 2.5 15.3 0 18M12 3c-2.5 2.7-2.5 15.3 0 18"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    star: '<path d="M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9 6.8 19.2l1-5.8L3.5 9.2l5.9-.9z"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
    play: '<path d="M6 4l14 8-14 8z"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4"/>',
    lock2: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    calendarPlus: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M12 14v4M10 16h4"/>'
  };
  function svg(name, cls) {
    var body = ICONS[name] || "";
    return '<svg class="ic ' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + body + "</svg>";
  }
  function paintIcons(root) {
    (root || document).querySelectorAll("[data-icon]").forEach(function (n) {
      if (n.__painted) return; n.__painted = true;
      n.innerHTML = svg(n.getAttribute("data-icon")) + (n.getAttribute("data-icon-text") ? "<span>" + esc(n.getAttribute("data-icon-text")) + "</span>" : n.innerHTML);
    });
  }
  document.addEventListener("DOMContentLoaded", function () { paintIcons(document); });

  /* ---------- تفاعلات الهيدر الموحّد (بلا سكربت لكل صفحة) ---------- */
  function wireChrome() {
    // زر القائمة للجوّال
    document.querySelectorAll(".hdr-burger").forEach(function (b) {
      b.addEventListener("click", function () {
        var t = document.querySelector(b.getAttribute("data-target") || ".hdr-nav");
        if (t) t.classList.toggle("open");
      });
    });
    // تبديل الثيم
    document.querySelectorAll("[data-theme-toggle]").forEach(function (b) {
      b.addEventListener("click", function () { toggleTheme(); });
    });
    // خروج
    document.querySelectorAll("[data-logout]").forEach(function (b) {
      b.addEventListener("click", function (e) { e.preventDefault(); logout(); });
    });
    // قائمة المستخدم المنسدلة
    document.querySelectorAll("[data-user-menu]").forEach(function (btn) {
      var menu = document.getElementById(btn.getAttribute("data-user-menu"));
      if (!menu) return;
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        menu.style.display = menu.style.display === "block" ? "none" : "block";
      });
      document.addEventListener("click", function () { menu.style.display = "none"; });
      menu.addEventListener("click", function (e) { e.stopPropagation(); });
    });
  }
  document.addEventListener("DOMContentLoaded", wireChrome);

  /* ---------- تعبئة قائمة/زرّ المستخدم في الهيدر ---------- */
  function fillUser(user) {
    document.querySelectorAll("[data-user-name]").forEach(function (n) { n.textContent = user.name || user.email || "مستخدم"; });
    document.querySelectorAll("[data-user-email]").forEach(function (n) { n.textContent = user.email || ""; });
    document.querySelectorAll("[data-user-avatar]").forEach(function (n) { n.textContent = initials(user.name || user.email); });
    document.querySelectorAll("[data-admin-only]").forEach(function (n) { if (user.role !== "admin") n.style.display = "none"; });
  }

  /* ---------- التصدير ---------- */
  window.App = {
    api: api, me: me, logout: logout, toast: toast,
    getCookie: getCookie, csrfToken: csrfToken,
    applyTheme: applyTheme, setThemePref: setThemePref, getThemePref: getThemePref, toggleTheme: toggleTheme,
    initials: initials, el: el, esc: esc, svg: svg, icon: svg, paintIcons: paintIcons,
    fillUser: fillUser
  };
})();
