/* ============================================================
   app.js — أدوات مشتركة: الثيم، api()، toast، الأيقونات، المستخدم
   يُربَط: <script src="/assets/app.js?v=1" defer></script>
   ============================================================ */
(function () {
  "use strict";

  /* ---------- الثيم (بلا وميض عند التحميل من <head>) ---------- */
  var THEME_KEY = "theme";
  function systemDark() { return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches; }
  function resolveTheme(pref) { return pref === "dark" || pref === "light" ? pref : (systemDark() ? "dark" : "light"); }
  function applyTheme(pref) {
    var mode = resolveTheme(pref);
    document.documentElement.setAttribute("data-theme", mode);
    return mode;
  }
  function getThemePref() { try { return localStorage.getItem(THEME_KEY) || "auto"; } catch (e) { return "auto"; } }
  function setThemePref(pref) {
    try { pref === "auto" ? localStorage.removeItem(THEME_KEY) : localStorage.setItem(THEME_KEY, pref); } catch (e) {}
    return applyTheme(pref);
  }
  function toggleTheme() {
    var now = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    return setThemePref(now);
  }
  // تطبيق فوري
  applyTheme(getThemePref());
  if (window.matchMedia) {
    try {
      window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", function () {
        if (getThemePref() === "auto") applyTheme("auto");
      });
    } catch (e) {}
  }

  /* ---------- الكوكيز / CSRF ---------- */
  function getCookie(name) {
    var m = document.cookie.match("(?:^|; )" + name.replace(/([.$?*|{}()\[\]\\\/\+^])/g, "\\$1") + "=([^;]*)");
    return m ? decodeURIComponent(m[1]) : null;
  }
  function csrfToken() { return getCookie("meet_csrf") || ""; }

  /* ---------- api() — fetch موحّد مع CSRF تلقائي ---------- */
  async function api(path, opts) {
    opts = opts || {};
    var method = (opts.method || "GET").toUpperCase();
    var headers = Object.assign({ "Accept": "application/json" }, opts.headers || {});
    var body = opts.body;
    if (body && typeof body === "object" && !(body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    if (method !== "GET" && method !== "HEAD") {
      var t = csrfToken();
      if (t) headers["X-CSRF-Token"] = t;
    }
    var url = path.charAt(0) === "/" ? path : "/api/" + path;
    if (url.indexOf("/api/") !== 0 && url.charAt(0) === "/") { /* مسار مطلق كما هو */ }
    var res = await fetch(url, { method: method, headers: headers, body: body, credentials: "same-origin" });
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var msg = (data && (data.error || data.message)) || ("HTTP " + res.status);
      var err = new Error(msg); err.status = res.status; err.data = data;
      if (res.status === 401 && !opts.noRedirect) { location.href = "/index.html"; }
      throw err;
    }
    return data;
  }

  /* ---------- toast ---------- */
  function toastHost() {
    var h = document.getElementById("toastHost");
    if (!h) { h = document.createElement("div"); h.id = "toastHost"; h.className = "toast-host"; document.body.appendChild(h); }
    return h;
  }
  function toast(msg, kind) {
    var el = document.createElement("div");
    el.className = "toast " + (kind === "err" ? "err" : "ok");
    el.textContent = msg;
    toastHost().appendChild(el);
    setTimeout(function () { el.style.opacity = "0"; el.style.transition = "opacity .25s"; setTimeout(function () { el.remove(); }, 260); }, 2600);
  }

  /* ---------- المستخدم / الخروج ---------- */
  var _me = null;
  async function me(force) {
    if (_me && !force) return _me;
    var d = await api("/api/auth/me", { noRedirect: true });
    _me = d && d.user ? d.user : d;
    return _me;
  }
  async function logout() {
    try { await api("/api/auth/logout", { method: "POST" }); } catch (e) {}
    location.href = "/index.html";
  }
  function initials(name) {
    if (!name) return "؟";
    var p = String(name).trim().split(/\s+/);
    return (p[0] ? p[0][0] : "") + (p[1] ? p[1][0] : "");
  }

  /* ---------- أدوات DOM مختصرة ---------- */
  function el(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  /* ---------- الأيقونات (سبرايت مضمّن) ---------- */
  var ICONS = {
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    settings: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 6.8 19.4l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3 15H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 6.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 9 3.6V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a2 2 0 1 1 0 4h-.1z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    sun: '<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    code: '<path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l2 2M14 9l2 2"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    device: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5 5h14l3 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z"/>'
  };
  function svg(name, cls) {
    var body = ICONS[name] || "";
    return '<svg class="ic ' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true">' + body + "</svg>";
  }
  function paintIcons(root) {
    (root || document).querySelectorAll("[data-icon]").forEach(function (n) {
      if (n.__painted) return; n.__painted = true;
      n.innerHTML = svg(n.getAttribute("data-icon")) + (n.getAttribute("data-icon-text") ? "<span>" + esc(n.getAttribute("data-icon-text")) + "</span>" : n.innerHTML);
    });
  }
  document.addEventListener("DOMContentLoaded", function () { paintIcons(document); });

  /* ---------- التصدير ---------- */
  window.App = {
    api: api, me: me, logout: logout, toast: toast,
    getCookie: getCookie, csrfToken: csrfToken,
    applyTheme: applyTheme, setThemePref: setThemePref, getThemePref: getThemePref, toggleTheme: toggleTheme,
    initials: initials, el: el, esc: esc, svg: svg, icon: svg, paintIcons: paintIcons
  };
})();
