  "use strict";
  const api = {
    async request(method, path, body) {
      const opts = { method, credentials: "include", headers: {} };
      if (method !== "GET" && method !== "HEAD") {
        const m = document.cookie.match(/(?:^|;\s*)meet_csrf=([^;]+)/);
        if (m) opts.headers["X-CSRF-Token"] = decodeURIComponent(m[1]);
      }
      if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
      const res = await fetch("/api" + path, opts);
      let data = null; try { data = await res.json(); } catch (_) {}
      if (!res.ok) throw new Error((data && data.error) ? data.error : "حدث خطأ (" + res.status + ")");
      return data;
    },
    get(p) { return this.request("GET", p); },
    post(p, b) { return this.request("POST", p, b || {}); },
    patch(p, b) { return this.request("PATCH", p, b || {}); },
    del(p) { return this.request("DELETE", p); },
  };
  const el = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let toastTimer = null;
  function toast(msg) {
    const t = el("toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
  }

  /* tabs */
  function initTabs() {
    document.querySelectorAll('.adm-tabs [role="tab"]').forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll('.adm-tabs [role="tab"]').forEach((b) => b.setAttribute("aria-selected", "false"));
        btn.setAttribute("aria-selected", "true");
        document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
        el("tab-" + btn.getAttribute("data-tab")).classList.add("active");
      });
    });
  }

  /* ---------- nodes ---------- */
  const STATUS = {
    online: ["online", "متصل"], offline: ["offline", "خارج الخدمة"],
    provisioning: ["provisioning", "جارٍ التثبيت"], error: ["error", "خطأ"],
  };
  function nodeSkeletons(n) {
    let h = "";
    for (let i = 0; i < n; i++) h += '<div class="card node"><div class="sk sk-line" style="width:45%"></div>' +
      '<div class="sk sk-line" style="width:70%;height:10px"></div></div>';
    return h;
  }
  async function loadNodes() {
    const box = el("nodes");
    box.innerHTML = nodeSkeletons(2);
    el("nodesEmpty").classList.add("hidden");
    let nodes = [];
    try { nodes = (await api.get("/nodes")).nodes || []; }
    catch (e) { box.innerHTML = ""; toast(e.message); return; }
    box.innerHTML = "";
    if (!nodes.length) { el("nodesEmpty").classList.remove("hidden"); return; }
    nodes.forEach((n) => box.appendChild(renderNode(n)));
  }
  function renderNode(n) {
    const [dot, label] = STATUS[n.status] || STATUS.offline;
    const main = String(n.is_main) === "1";
    const div = document.createElement("div");
    div.className = "card node";
    div.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">' +
        '<div>' +
          '<div class="nm"><span class="dot ' + dot + '"></span>' + esc(n.name) +
            (main ? '<span class="adm-badge">أساسي</span>' : "") + "</div>" +
          '<div class="chip" dir="ltr" style="margin-top:6px">' + esc(n.host) + " · " + esc(n.ssh_user) + "@:" + esc(n.ssh_port) +
            (n.region ? " · " + esc(n.region) : "") + "</div>" +
          '<div style="color:var(--muted);font-size:12px;margin-top:6px">' + esc(label) +
            (n.last_error ? " — " + esc(n.last_error) : "") + "</div>" +
        "</div>" +
        (main ? "" :
          '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
            '<button class="btn btn-ghost btn-sm prov">تثبيت / إعادة</button>' +
            '<button class="btn btn-ghost btn-sm edit">تعديل</button>' +
            '<button class="btn btn-danger btn-sm del">حذف</button>' +
          "</div>") +
      "</div>" +
      '<div class="edit-form hidden" style="margin-top:12px">' +
        '<input class="field sm e-name" value="' + esc(n.name) + '" />' +
        '<input class="field sm e-host" dir="ltr" value="' + esc(n.host) + '" />' +
        '<input class="field sm e-region" placeholder="المنطقة" value="' + esc(n.region || "") + '" />' +
        '<input class="field sm e-user" dir="ltr" value="' + esc(n.ssh_user) + '" />' +
        '<input class="field sm e-port" dir="ltr" value="' + esc(n.ssh_port) + '" />' +
        '<button class="btn btn-primary btn-sm e-save">حفظ</button>' +
      "</div>";
    if (!main) {
      div.querySelector(".prov").addEventListener("click", async () => {
        const password = await App.prompt("أدخل كلمة مرور SSH. لن تُخزَّن على الخادم.", { title: "كلمة مرور SSH", ok: "اتصال", placeholder: "••••••••", type: "password" });
        if (!password) return;
        const btn = div.querySelector(".prov"); btn.textContent = "جارٍ التثبيت…"; btn.disabled = true;
        try { await api.post("/nodes/" + n.id + "/provision", { password }); toast("تم التثبيت"); }
        catch (ex) { toast("فشل التثبيت: " + ex.message); }
        loadNodes();
      });
      const form = div.querySelector(".edit-form");
      div.querySelector(".edit").addEventListener("click", () => form.classList.toggle("hidden"));
      div.querySelector(".e-save").addEventListener("click", async () => {
        try {
          await api.patch("/nodes/" + n.id, {
            name: form.querySelector(".e-name").value.trim(),
            host: form.querySelector(".e-host").value.trim(),
            region: form.querySelector(".e-region").value.trim(),
            ssh_user: form.querySelector(".e-user").value.trim(),
            ssh_port: parseInt(form.querySelector(".e-port").value, 10) || 22,
          });
          toast("تم الحفظ"); loadNodes();
        } catch (ex) { toast(ex.message); }
      });
      div.querySelector(".del").addEventListener("click", async () => {
        if (!await App.confirm("حذف السيرفر " + n.name + "؟", { title: "حذف السيرفر", ok: "حذف", danger: true })) return;
        try { await api.del("/nodes/" + n.id); loadNodes(); } catch (ex) { toast(ex.message); }
      });
    }
    return div;
  }

  /* ---------- presets CRUD ---------- */
  function presetRow(card, label, value) {
    const vkey = card.getAttribute("data-value");
    const row = document.createElement("div");
    row.className = "preset-row";
    row.innerHTML =
      '<input class="field sm p-label" placeholder="الاسم (مثل 720p)" value="' + esc(label) + '" />' +
      '<input class="field sm p-value" dir="ltr" style="max-width:120px" type="number" placeholder="' + esc(vkey) + '" value="' + esc(value) + '" />' +
      '<button class="icon-btn p-del" title="حذف"><svg class="ic"><use href="#ic-trash"/></svg></button>';
    row.querySelector(".p-del").addEventListener("click", () => row.remove());
    card.querySelector(".preset-list").appendChild(row);
    return row;
  }
  function fillPreset(card, items) {
    const list = card.querySelector(".preset-list");
    list.innerHTML = "";
    const vkey = card.getAttribute("data-value");
    (items || []).forEach((it) => presetRow(card, it.label, it[vkey]));
  }
  async function loadPresets() {
    let settings = {};
    try { settings = (await api.get("/admin/settings")).settings || {}; }
    catch (e) { toast(e.message); return; }
    document.querySelectorAll("[data-preset]").forEach((card) => {
      fillPreset(card, settings[card.getAttribute("data-preset")]);
    });
  }
  function initPresets() {
    document.querySelectorAll("[data-preset]").forEach((card) => {
      card.querySelector("[data-add]").addEventListener("click", () => presetRow(card, "", ""));
      card.querySelector("[data-save]").addEventListener("click", async () => {
        const key = card.getAttribute("data-preset");
        const vkey = card.getAttribute("data-value");
        const items = [];
        let bad = false;
        card.querySelectorAll(".preset-row").forEach((r) => {
          const label = r.querySelector(".p-label").value.trim();
          const val = parseInt(r.querySelector(".p-value").value, 10);
          if (!label || !Number.isFinite(val) || val <= 0) { bad = true; return; }
          const o = { label }; o[vkey] = val; items.push(o);
        });
        if (!items.length) { toast("أضف خيارًا واحدًا على الأقل"); return; }
        if (bad) { toast("تحقّق من القيم — كل خيار يحتاج اسمًا ورقمًا موجبًا"); return; }
        try { await api.post("/admin/settings", { [key]: items }); toast("تم الحفظ"); await loadPresets(); }
        catch (e) { toast(e.message); }
      });
    });
  }

  /* ---------- boot ---------- */
  let meId = null;
  const initials = (s) => String(s || "؟").trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "؟";
  const fmtLim = (v, unit) => (v === null ? "غير محدود" : v + " " + unit);
  const PLAN_LABELS = { normal: "Normal", vip1: "VIP 1", vip2: "VIP 2", vip3: "VIP 3" };
  function fmtDate(s) {
    if (!s) return "—";
    try { return new Date(String(s).replace(" ", "T") + "Z").toLocaleDateString("ar", { dateStyle: "medium" }); }
    catch (e) { return s; }
  }

  async function loadUsers() {
    const box = el("users");
    box.innerHTML = nodeSkeletons(3);
    el("usersEmpty").classList.add("hidden");
    let users = [];
    try { users = (await api.get("/admin/users")).users || []; }
    catch (e) { box.innerHTML = ""; toast(e.message); return; }
    box.innerHTML = "";
    if (!users.length) { el("usersEmpty").classList.remove("hidden"); return; }
    users.forEach((u) => box.appendChild(renderUser(u)));
  }

  function renderUser(u) {
    const isAdmin = u.role === "admin";
    const isMe = u.id === meId;
    const plan = u.plan || "normal";
    const div = document.createElement("div");
    div.className = "card urow";
    div.innerHTML =
      '<div class="uhead">' +
        '<span class="avatar">' + esc(initials(u.name || u.email)) + "</span>" +
        '<div class="uinfo">' +
          '<div class="un">' + esc(u.name || "—") +
            (isAdmin ? ' <span class="adm-badge">أدمن</span>' : "") +
            (isMe ? ' <span class="chip">أنت</span>' : "") + "</div>" +
          '<div class="ue" dir="ltr">' + esc(u.email) + "</div>" +
        "</div>" +
        (isAdmin ? "" :
          '<select class="field plan-sel">' +
            ['normal','vip1','vip2','vip3'].map((p) =>
              '<option value="' + p + '"' + (p === plan ? " selected" : "") + '>' + PLAN_LABELS[p] + "</option>").join("") +
          "</select>") +
        '<button class="btn btn-ghost btn-sm role-btn">' + (isAdmin ? "إزالة الأدمن" : "ترقية لأدمن") + "</button>" +
      "</div>" +
      '<div class="ulims">' +
        (isAdmin ? "" : '<span class="plan-badge ' + esc(plan) + '">' + PLAN_LABELS[plan] + "</span>") +
        '<span class="chip">رصيد الساعات: ' + esc(fmtLim(u.hoursBalance, "ساعة")) + "</span>" +
        '<span class="chip">سقف المشاركين: ' + esc(fmtLim(u.maxParticipants, "مشارك")) + "</span>" +
        (isAdmin ? "" : '<span class="chip">التجديد: ' + esc(fmtDate(u.planRenewsAt)) + "</span>") +
        (isAdmin ? "" : '<button class="btn btn-ghost btn-sm reset-btn" style="margin-inline-start:auto">تصفير الرصيد الآن</button>') +
      "</div>";

    const roleBtn = div.querySelector(".role-btn");
    if (isMe && isAdmin) { roleBtn.disabled = true; roleBtn.title = "لا يمكنك إزالة صلاحيتك"; }
    roleBtn.addEventListener("click", async () => {
      const next = isAdmin ? "user" : "admin";
      if (!await App.confirm((isAdmin ? "إزالة صلاحية الأدمن عن " : "ترقية ") + (u.name || u.email) + (isAdmin ? "؟" : " إلى أدمن؟"), { title: "تغيير الصلاحية", ok: isAdmin ? "إزالة" : "ترقية", danger: isAdmin })) return;
      try { await api.post("/admin/users/" + u.id + "/role", { role: next }); toast("تم تحديث الصلاحية"); loadUsers(); }
      catch (e) { toast(e.message); }
    });

    const resetBtn = div.querySelector(".reset-btn");
    if (resetBtn) resetBtn.addEventListener("click", async () => {
      if (!await App.confirm("تصفير رصيد " + (u.name || u.email) + " الآن؟ سيُعاد كاملًا من توزيعة باقته الحالية كأنه لم يُستخدم.", { title: "تصفير الرصيد", ok: "تصفير" })) return;
      resetBtn.disabled = true;
      try { await api.post("/admin/users/" + u.id + "/reset", {}); toast("تم تصفير الرصيد"); loadUsers(); }
      catch (e) { toast(e.message); resetBtn.disabled = false; }
    });

    const planSel = div.querySelector(".plan-sel");
    if (planSel) planSel.addEventListener("change", async () => {
      const next = planSel.value;
      if (!await App.confirm("تغيير باقة " + (u.name || u.email) + " إلى " + (PLAN_LABELS[next] || next) + "؟ سيُعاد رصيده من توزيعة الباقة الجديدة.", { title: "تغيير الباقة", ok: "تغيير" })) {
        planSel.value = plan; return;
      }
      try { await api.post("/admin/users/" + u.id + "/limits", { plan: next }); toast("تم تغيير الباقة"); loadUsers(); }
      catch (e) { toast(e.message); planSel.value = plan; }
    });
    return div;
  }

  /* ---------- الباقات (plan tiers) ---------- */
  const PLAN_ORDER = ["normal", "vip1", "vip2", "vip3"];
  const RESETS = { daily: "يومي", weekly: "أسبوعي", monthly: "شهري", off: "بلا تجديد" };
  let plansState = {};

  function renderPlanCard(key, t) {
    const hoursInf = t.hours === null || t.hours === undefined;
    const partInf = t.maxParticipants === null || t.maxParticipants === undefined;
    const div = document.createElement("div");
    div.className = "card prow";
    div.dataset.plan = key;
    div.innerHTML =
      '<div class="phead">' +
        '<div class="ptitle"><span class="plan-badge ' + esc(key) + '">' + (PLAN_LABELS[key] || key) + "</span></div>" +
        '<button class="btn btn-primary btn-sm p-save">حفظ</button>' +
      "</div>" +
      '<div class="pgrid">' +
        "<div>" +
          '<label class="lbl">رصيد الساعات شهريًّا</label>' +
          '<input class="field sm t-hours" dir="ltr" type="number" min="0" step="0.5" placeholder="مثال: 10" value="' +
            (hoursInf ? "" : esc(t.hours)) + '" ' + (hoursInf ? "disabled" : "") + " />" +
          '<label class="infinite"><input type="checkbox" class="t-hours-inf" ' + (hoursInf ? "checked" : "") + "> غير محدود</label>" +
        "</div>" +
        "<div>" +
          '<label class="lbl">سقف المشاركين لكل اجتماع</label>' +
          '<input class="field sm t-part" dir="ltr" type="number" min="1" step="1" placeholder="مثال: 25" value="' +
            (partInf ? "" : esc(t.maxParticipants)) + '" ' + (partInf ? "disabled" : "") + " />" +
          '<label class="infinite"><input type="checkbox" class="t-part-inf" ' + (partInf ? "checked" : "") + "> غير محدود</label>" +
        "</div>" +
        "<div>" +
          '<label class="lbl">دورة التجديد</label>' +
          '<select class="field sm t-reset">' +
            Object.keys(RESETS).map((r) =>
              '<option value="' + r + '"' + (r === (t.reset || "monthly") ? " selected" : "") + '>' + RESETS[r] + "</option>").join("") +
          "</select>" +
        "</div>" +
      "</div>";

    const hInf = div.querySelector(".t-hours-inf"), hInp = div.querySelector(".t-hours");
    const pInf = div.querySelector(".t-part-inf"), pInp = div.querySelector(".t-part");
    hInf.addEventListener("change", () => { hInp.disabled = hInf.checked; if (hInf.checked) hInp.value = ""; });
    pInf.addEventListener("change", () => { pInp.disabled = pInf.checked; if (pInf.checked) pInp.value = ""; });

    div.querySelector(".p-save").addEventListener("click", async () => {
      const hours = hInf.checked || hInp.value.trim() === "" ? null : Math.max(0, parseFloat(hInp.value));
      const maxParticipants = pInf.checked || pInp.value.trim() === "" ? null : Math.max(1, parseInt(pInp.value, 10));
      plansState[key] = { hours, maxParticipants, reset: div.querySelector(".t-reset").value };
      try { await api.post("/admin/plans", plansState); toast("تم حفظ الباقة"); await loadPlans(); }
      catch (e) { toast(e.message); }
    });
    return div;
  }

  async function loadPlans() {
    const box = el("plans");
    box.innerHTML = nodeSkeletons(4);
    try { plansState = (await api.get("/admin/plans")).plans || {}; }
    catch (e) { box.innerHTML = ""; toast(e.message); return; }
    box.innerHTML = "";
    PLAN_ORDER.forEach((k) => { if (plansState[k]) box.appendChild(renderPlanCard(k, plansState[k])); });
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const yr = el("yr"); if (yr) yr.textContent = new Date().getFullYear();
    let user = null;
    try { user = (await api.get("/auth/me")).user; } catch (_) {}
    if (!user) { location.href = "/login.html"; return; }
    if (user.role !== "admin") { location.href = "/dashboard.html"; return; }
    meId = user.sub || user.id || null;
    if (window.App && window.App.fillUser) window.App.fillUser(user);

    initTabs();
    initPresets();
    el("addBtn").addEventListener("click", async () => {
      const g = (id) => el(id).value.trim();
      const name = g("nName"), host = g("nHost");
      if (!name || !host) { toast("الاسم و IP مطلوبان"); return; }
      try {
        await api.post("/nodes", { name, host, region: g("nRegion"), ssh_user: g("nUser") || "root", ssh_port: parseInt(g("nPort"), 10) || 22 });
        ["nName", "nHost", "nRegion"].forEach((id) => (el(id).value = ""));
        toast("تمت الإضافة"); loadNodes();
      } catch (ex) { toast(ex.message); }
    });

    await loadUsers();
    await loadPlans();
    await loadNodes();
    await loadPresets();
  });
  
