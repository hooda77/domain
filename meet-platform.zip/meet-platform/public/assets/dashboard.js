  "use strict";
  document.addEventListener("DOMContentLoaded", function () {
    var A = window.App;
    var esc = A.esc, el = A.el;
    function toast(m, k) { A.toast(m, k); }

    /* ---------- الحالة + الإعدادات المسبقة ---------- */
    var PRESETS = null;
    var SEL = { maxHeight: null, maxBitrate: null, maxFps: null, durationHours: null };
    var CUR_TAB = "active";

    function buildSeg(containerId, items, valueKey, stateKey) {
      var box = el(containerId);
      box.innerHTML = "";
      items.forEach(function (it, idx) {
        var b = document.createElement("button");
        b.type = "button";
        b.textContent = it.label;
        var val = it[valueKey];
        var pressed = SEL[stateKey] === val || (SEL[stateKey] == null && idx === items.length - 1);
        if (pressed) SEL[stateKey] = val;
        b.setAttribute("aria-pressed", pressed ? "true" : "false");
        b.addEventListener("click", function () {
          SEL[stateKey] = val;
          [].slice.call(box.children).forEach(function (c) { c.setAttribute("aria-pressed", "false"); });
          b.setAttribute("aria-pressed", "true");
        });
        box.appendChild(b);
      });
    }

    async function loadPresets() {
      try {
        var data = await A.api("/api/settings/presets");
        PRESETS = data.presets || {};
      } catch (_) {
        PRESETS = {
          resolution_presets: [{ label: "144p", height: 144 }, { label: "240p", height: 240 }, { label: "360p", height: 360 }, { label: "480p", height: 480 }, { label: "720p", height: 720 }],
          bitrate_presets: [{ label: "200k", kbps: 200 }, { label: "300k", kbps: 300 }, { label: "500k", kbps: 500 }, { label: "800k", kbps: 800 }, { label: "1M", kbps: 1000 }],
          fps_presets: [{ label: "5 fps", fps: 5 }, { label: "8 fps", fps: 8 }, { label: "10 fps", fps: 10 }, { label: "12 fps", fps: 12 }, { label: "15 fps", fps: 15 }],
          duration_presets: [{ label: "ساعة", hours: 1 }, { label: "ساعتان", hours: 2 }]
        };
      }
      buildSeg("segRes", PRESETS.resolution_presets || [], "height", "maxHeight");
      buildSeg("segBit", PRESETS.bitrate_presets || [], "kbps", "maxBitrate");
      buildSeg("segFps", PRESETS.fps_presets || [], "fps", "maxFps");
      buildSeg("segDur", PRESETS.duration_presets || [], "hours", "durationHours");
    }

    /* ---------- النوافذ ---------- */
    var STEP_TITLES = { 1: "إنشاء اجتماع — التفاصيل", 2: "إنشاء اجتماع — الجودة والمدة" };
    function goStep(n) {
      document.querySelectorAll("#createWizard .step").forEach(function (s) { s.classList.toggle("on", +s.dataset.step === n); });
      document.querySelectorAll("#createWizard .sdot").forEach(function (d) { d.classList.toggle("on", +d.dataset.dot <= n); });
      var t = el("stepTitle"); if (t) t.textContent = STEP_TITLES[n] || "إنشاء اجتماع";
      var box = el("createWizard"); if (box) box.scrollTop = 0;
    }
    function openModal() { el("createModal").classList.add("open"); goStep(1); el("roomName").focus(); }
    function closeModal() { el("createModal").classList.remove("open"); var sm = el("sessionModal"); if (sm) sm.classList.remove("open"); }

    /* ---------- أدوات وقت ---------- */
    function fmtRemaining(ms) {
      if (ms <= 0) return "انتهت";
      var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
      if (h > 0) return h + "س " + m + "د";
      return m + "د " + (s % 60) + "ث";
    }
    function parseTs(s) {
      if (!s) return null;
      var d = new Date(String(s).replace(" ", "T") + "Z");
      return isNaN(d.getTime()) ? null : d.getTime();
    }
    function fmtDur(sec) {
      sec = Math.max(0, Number(sec) || 0);
      var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
      if (h) return h + "س " + m + "د";
      if (m) return m + "د " + s + "ث";
      return s + "ث";
    }
    function fmtDateTime(s) {
      var ts = parseTs(s);
      if (!ts) return "—";
      try { return new Date(ts).toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" }); } catch (_) { return "—"; }
    }
    function fmtStart(ts) { try { return new Date(ts).toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" }); } catch (_) { return ""; } }

    function skeletons(n) {
      var h = "";
      for (var i = 0; i < n; i++) {
        h += '<div class="feed-item"><div class="fi-icon skeleton" style="background:var(--surface2)"></div>' +
          '<div class="fi-body"><div class="skeleton" style="height:14px;width:55%;border-radius:7px"></div>' +
          '<div class="skeleton" style="height:11px;width:35%;border-radius:7px;margin-top:8px"></div></div></div>';
      }
      return h;
    }

    var expiryTimers = [];
    function clearExpiryTimers() { expiryTimers.forEach(clearInterval); expiryTimers = []; }

    /* ---------- قائمة الاجتماعات ---------- */
    async function loadRooms() {
      var box = el("rooms"), schedBox = el("scheduled");
      clearExpiryTimers();
      box.innerHTML = skeletons(3);
      if (schedBox) schedBox.innerHTML = "";
      el("empty").classList.add("hidden");
      var rooms = [];
      try {
        var data = await A.api("/api/rooms");
        rooms = data.rooms || data || [];
      } catch (e) { box.innerHTML = ""; toast(e.message || "تعذّر تحميل الاجتماعات", "err"); return; }
      box.innerHTML = ""; if (schedBox) schedBox.innerHTML = "";
      var activeCount = 0, schedCount = 0;

      rooms.forEach(function (r, i) {
        var active = Number(r.is_active) === 1;
        var code = r.room_code || r.code || "";
        var expTs = parseTs(r.expires_at), startTs = parseTs(r.starts_at);
        var scheduled = startTs && startTs > Date.now();
        var target = scheduled ? (schedBox || box) : box;
        if (scheduled) schedCount++; else activeCount++;
        var item = document.createElement("div");
        item.className = "feed-item" + (active ? "" : " ended");
        var timerId = "exp-" + code.replace(/[^a-z0-9]/gi, "");
        var meta = '<span dir="ltr">' + esc(code) + "</span>";
        if (scheduled) meta += "<span>" + A.svg("clock") + " " + esc(fmtStart(startTs)) + "</span>";
        if (Number(r.waiting_room) === 1) meta += "<span>غرفة انتظار</span>";
        if (Number(r.has_password) === 1) meta += "<span>🔒 كلمة مرور</span>";
        if (active && !scheduled && expTs) meta += '<span id="' + timerId + '">' + A.svg("clock") + ' <span class="rem">--</span></span>';
        else if (!active) meta += "<span>منتهٍ</span>";
        var actions = active
          ? '<button class="btn btn-primary btn-sm" data-join="' + esc(code) + '">' + (scheduled ? "دخول مبكّر" : "دخول") + "</button>"
          : '<button class="btn btn-ghost btn-sm" disabled>انتهى</button>';
        actions += '<button class="btn btn-ghost btn-sm" data-copy="' + esc(code) + '" title="نسخ رابط الدعوة">' + A.svg("copy") + "</button>";
        if (!active) actions += '<button class="btn btn-danger btn-sm" data-del="' + esc(code) + '" title="حذف">' + A.svg("trash") + "</button>";
        item.innerHTML =
          '<div class="fi-icon">' + A.svg("video") + "</div>" +
          '<div class="fi-body"><div class="fi-title"><span class="dot ' + (active ? "on" : "off") + '"></span>' + esc(r.name || "اجتماع") + "</div>" +
          '<div class="fi-meta">' + meta + "</div></div>" +
          '<div class="fi-actions">' + actions + "</div>";
        target.appendChild(item);

        if (active && !scheduled && expTs) {
          var node = item.querySelector("#" + CSS.escape(timerId));
          var rem = node ? node.querySelector(".rem") : null;
          var tick = function () {
            var ms = expTs - Date.now();
            if (!rem) return;
            rem.textContent = fmtRemaining(ms);
            if (ms <= 0) { rem.textContent = "انتهت"; loadRooms(); }
            else if (ms <= 60000 && node) node.classList.add("rem-danger");
          };
          tick();
          expiryTimers.push(setInterval(tick, 1000));
        }
      });

      var wire = function (container) {
        container.querySelectorAll("[data-join]").forEach(function (b) {
          b.addEventListener("click", function () { location.href = "/room.html?room=" + encodeURIComponent(b.getAttribute("data-join")); });
        });
        container.querySelectorAll("[data-copy]").forEach(function (b) {
          b.addEventListener("click", function () {
            var link = location.origin + "/room.html?room=" + encodeURIComponent(b.getAttribute("data-copy"));
            if (navigator.clipboard) navigator.clipboard.writeText(link);
            toast("تم نسخ رابط الدعوة");
          });
        });
        container.querySelectorAll("[data-del]").forEach(function (b) {
          b.addEventListener("click", async function () {
            var code = b.getAttribute("data-del");
            if (!await A.confirm("حذف هذا الاجتماع نهائيًا؟ لا يمكن التراجع.", { title: "حذف الاجتماع", ok: "حذف", danger: true })) return;
            b.disabled = true;
            try { await A.api("/api/rooms/" + encodeURIComponent(code), { method: "DELETE" }); toast("تم حذف الاجتماع"); loadRooms(); }
            catch (e) { b.disabled = false; toast((e && e.message) ? e.message : "تعذّر الحذف", "err"); }
          });
        });
      };
      wire(box); if (schedBox) wire(schedBox);

      if (CUR_TAB === "active" && !activeCount) el("empty").classList.remove("hidden");
      if (CUR_TAB === "scheduled" && !schedCount && schedBox) schedBox.innerHTML = '<div class="empty">لا اجتماعات مجدولة.</div>';
    }

    /* ---------- السجل ---------- */
    async function loadHistory() {
      var box = el("history");
      box.innerHTML = skeletons(3);
      var sessions = [];
      try { var data = await A.api("/api/rooms/history"); sessions = data.sessions || []; }
      catch (e) { box.innerHTML = ""; toast(e.message || "تعذّر تحميل السجل", "err"); return; }
      box.innerHTML = "";
      if (!sessions.length) { box.innerHTML = '<div class="empty">لا جلسات في السجل بعد.</div>'; return; }
      sessions.forEach(function (s) {
        var item = document.createElement("div");
        item.className = "feed-item ended";
        item.innerHTML =
          '<div class="fi-icon">' + A.svg("history") + "</div>" +
          '<div class="fi-body"><div class="fi-title">' + esc(s.name || "اجتماع") + "</div>" +
          '<div class="fi-meta"><span>' + A.svg("clock") + " " + esc(fmtDateTime(s.endedAt)) + "</span>" +
          "<span>المدة: " + esc(fmtDur(s.durationSeconds)) + "</span>" +
          "<span>الحضور: " + Number(s.participantCount || 0) + "</span></div></div>" +
          '<div class="fi-actions"><button class="btn btn-ghost btn-sm" data-detail="' + Number(s.id) + '">التفاصيل</button></div>';
        box.appendChild(item);
      });
      box.querySelectorAll("[data-detail]").forEach(function (b) {
        b.addEventListener("click", function () { showSessionDetail(b.getAttribute("data-detail")); });
      });
    }

    async function showSessionDetail(id) {
      var data;
      try { data = await A.api("/api/rooms/history/" + encodeURIComponent(id)); }
      catch (e) { toast(e.message || "تعذّر تحميل التفاصيل", "err"); return; }
      var s = data.session || {}, att = data.attendees || [];
      el("sessionTitle").textContent = s.name || "تفاصيل الجلسة";
      el("sessionMeta").textContent =
        "من " + fmtDateTime(s.startedAt) + " إلى " + fmtDateTime(s.endedAt) +
        " · المدة " + fmtDur(s.durationSeconds) + " · الحضور " + Number(s.participantCount || 0);
      var rows = att.length
        ? att.map(function (a) {
            var mins = (a.durationMinutes != null) ? a.durationMinutes : Math.round((Number(a.durationSeconds) || 0) / 60);
            return '<div style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid var(--border)">' +
              '<span style="min-width:0">' + esc(a.name || a.identity || "—") +
                (a.identity ? ' <span class="chip" dir="ltr" style="font-size:11px">' + esc(a.identity) + "</span>" : "") + "</span>" +
              '<span style="color:var(--muted);white-space:nowrap" dir="ltr">' + mins + " دقيقة · " + esc(fmtDur(a.durationSeconds)) + "</span></div>";
          }).join("")
        : '<div class="empty">لا سجلّ حضور لهذه الجلسة.</div>';
      el("sessionAttendees").innerHTML = rows;
      el("sessionModal").classList.add("open");
    }

    /* ---------- التبويبات ---------- */
    function switchTab(tab) {
      CUR_TAB = tab;
      document.querySelectorAll("#tabs [data-tab]").forEach(function (b) {
        b.classList.toggle("active", b.getAttribute("data-tab") === tab);
      });
      el("rooms").classList.toggle("hidden", tab !== "active");
      el("scheduled").classList.toggle("hidden", tab !== "scheduled");
      el("history").classList.toggle("hidden", tab !== "history");
      el("empty").classList.add("hidden");
      if (tab === "history") loadHistory();
    }

    /* ---------- الإنشاء + الانضمام ---------- */
    async function createRoom() {
      var name = el("roomName").value.trim() || "اجتماع";
      var btn = el("createBtn");
      var startsAt = null, rawStart = el("startsAt") ? el("startsAt").value : "", scheduledFuture = false;
      if (rawStart) {
        var d = new Date(rawStart);
        if (!isNaN(d.getTime())) { startsAt = d.toISOString(); scheduledFuture = d.getTime() > Date.now() + 60000; }
      }
      var waitingRoom = el("waitingRoom") ? el("waitingRoom").checked : false;
      var password = el("roomPassword") ? el("roomPassword").value.trim() : "";
      btn.disabled = true; btn.textContent = "جارٍ الإنشاء…";
      try {
        var data = await A.api("/api/rooms", { method: "POST", body: {
          name: name, maxHeight: SEL.maxHeight, maxBitrate: SEL.maxBitrate, maxFps: SEL.maxFps,
          durationHours: SEL.durationHours, startsAt: startsAt, waitingRoom: waitingRoom, password: password
        }});
        var code = (data.room && (data.room.code || data.room.room_code)) || data.code || data.room_code;
        closeModal();
        if (scheduledFuture) { toast("تم جدولة الاجتماع — ادخل من القائمة وقت البدء"); loadRooms(); }
        else if (code) location.href = "/room.html?room=" + encodeURIComponent(code);
        else { toast("تم الإنشاء"); loadRooms(); }
      } catch (e) { toast(e.message || "تعذّر الإنشاء", "err"); }
      finally { btn.disabled = false; btn.textContent = "إنشاء ودخول"; }
    }

    function joinByCode() {
      var c = el("joinCode").value.trim();
      if (!c) { toast("أدخل رمز الاجتماع", "err"); return; }
      location.href = "/room.html?room=" + encodeURIComponent(c);
    }

    /* ---------- الإقلاع ---------- */
    var yr = el("yr"); if (yr) yr.textContent = new Date().getFullYear();

    (async function boot() {
      var me = null;
      try { me = await A.me(true); } catch (_) { location.href = "/login.html"; return; }
      var u = (me && (me.user || me)) || {};
      if (!u || (!u.id && !u.email && !u.sub)) { location.href = "/login.html"; return; }
      A.fillUser(u);
      var isAdmin = (u.role === "admin" || u.is_admin);
      if (isAdmin) document.querySelectorAll("[data-admin-only]").forEach(function (n) { n.style.display = ""; });

      (function () {
        var box = el("limitsInfo"); if (!box) return;
        var PLAN_LABELS = { normal: "Normal", vip1: "VIP 1", vip2: "VIP 2", vip3: "VIP 3" };
        var STAR = '<svg class="star" viewBox="0 0 24 24"><path d="M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 17.8 5.9 20.4l1.5-6.8L2.2 9l6.9-.7z"/></svg>';
        function fmtRenew(s) {
          if (!s) return null;
          try { return new Date(String(s).replace(" ", "T") + "Z").toLocaleDateString("ar", { dateStyle: "medium" }); }
          catch (e) { return null; }
        }
        function stat(l, v, inf) { return '<div class="rail-stat"><span>' + l + '</span><span class="v' + (inf ? " inf" : "") + '">' + esc(v) + "</span></div>"; }
        var plan = u.plan || "normal";
        var badge = '<div class="plan-hero"><span class="plan-badge ' + esc(plan) + '">' +
          (plan === "normal" ? "" : STAR) + (PLAN_LABELS[plan] || plan) + "</span></div>";

        if (isAdmin) {
          box.innerHTML = '<div class="plan-hero"><span class="plan-badge vip3">' + STAR + "أدمن</span></div>" +
            stat("رصيد الساعات", "غير محدود", true) + stat("سقف المشاركين", "غير محدود", true);
          return;
        }

        var html = badge;
        // رصيد الساعات — شريط تقدّم إن كانت السعة محدودة
        if (u.hoursBalance == null) {
          html += stat("رصيد الساعات", "غير محدود", true);
        } else {
          var cap = (u.planHours != null && u.planHours > 0) ? u.planHours : null;
          var pct = cap ? Math.max(0, Math.min(100, Math.round((u.hoursBalance / cap) * 100))) : 100;
          var low = cap && pct <= 15;
          html += '<div class="bal-wrap"><div class="bal-top"><span class="lab">رصيد الساعات</span>' +
            '<span class="val">' + esc(u.hoursBalance) + (cap ? " / " + esc(cap) : "") + " ساعة</span></div>" +
            '<div class="bal-bar' + (low ? " low" : "") + '"><i style="width:' + pct + '%"></i></div></div>';
        }
        html += stat("سقف المشاركين", u.maxParticipants == null ? "غير محدود" : (u.maxParticipants + " مشارك"), u.maxParticipants == null);
        var renew = fmtRenew(u.planRenewsAt);
        if (renew) html += '<div class="rail-renew">' + A.svg("history") + " التجديد القادم: " + esc(renew) + "</div>";
        box.innerHTML = html;
      })();

      document.querySelectorAll("[data-open-create]").forEach(function (b) { b.addEventListener("click", openModal); });
      el("nextStep").addEventListener("click", function () { goStep(2); });
      el("prevStep").addEventListener("click", function () { goStep(1); });
      document.querySelectorAll("[data-close-modal]").forEach(function (b) { b.addEventListener("click", closeModal); });
      el("createModal").addEventListener("click", function (e) { if (e.target === el("createModal")) closeModal(); });
      el("sessionModal").addEventListener("click", function (e) { if (e.target === el("sessionModal")) closeModal(); });
      document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });
      document.querySelectorAll("#tabs [data-tab]").forEach(function (b) {
        b.addEventListener("click", function () { switchTab(b.getAttribute("data-tab")); });
      });
      el("createBtn").addEventListener("click", createRoom);
      el("joinBtn").addEventListener("click", joinByCode);
      el("joinCode").addEventListener("keydown", function (e) { if (e.key === "Enter") joinByCode(); });
      el("refresh").addEventListener("click", function () { if (CUR_TAB === "history") loadHistory(); else loadRooms(); });

      await loadPresets();
      await loadRooms();
    })();
  });
  
