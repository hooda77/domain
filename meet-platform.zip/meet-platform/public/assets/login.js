    document.addEventListener("DOMContentLoaded", function () {
      var A = window.App;
      var params = new URLSearchParams(location.search);
      var next = params.get("next") || "/dashboard.html";
      // إن كان مسجّلًا بالفعل، حوّله للوحة التحكم
      A.me(true).then(function (u) { if (u && (u.id || u.email)) location.href = next; }).catch(function () {});
      document.getElementById("loginForm").addEventListener("submit", async function (e) {
        e.preventDefault();
        var btn = document.getElementById("submitBtn");
        btn.disabled = true; btn.textContent = "جارٍ الدخول…";
        try {
          await A.api("/api/auth/login", { method: "POST", noRedirect: true, body: {
            email: document.getElementById("email").value.trim(),
            password: document.getElementById("password").value
          }});
          location.href = next;
        } catch (err) {
          A.toast(err.message || "تعذّر تسجيل الدخول", "err");
          btn.disabled = false; btn.textContent = "تسجيل الدخول";
        }
      });
    });
  
