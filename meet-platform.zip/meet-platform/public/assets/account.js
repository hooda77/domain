/* account.js — منطق صفحة الحساب (تبويبات، بروفايل، أمان، API، مظهر) */
(function () {
  "use strict";
  var A = window.App, el = A.el, api = A.api, toast = A.toast, esc = A.esc;

  /* ---- التبويبات ---- */
  function activate(name) {
    document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("active", t.getAttribute("data-tab") === name); });
    document.querySelectorAll(".tabpane").forEach(function (p) { p.classList.toggle("active", p.id === "pane-" + name); });
    try { history.replaceState(null, "", "#" + name); } catch (e) {}
  }
  document.getElementById("tabs").addEventListener("click", function (e) {
    var t = e.target.closest(".tab"); if (t) activate(t.getAttribute("data-tab"));
  });
  var initial = (location.hash || "").replace("#", "");
  if (["profile", "security", "developer", "appearance"].indexOf(initial) >= 0) activate(initial);

  /* ---- المظهر ---- */
  function paintThemeOpts() {
    var pref = A.getThemePref();
    document.querySelectorAll(".theme-opt").forEach(function (o) { o.classList.toggle("active", o.getAttribute("data-theme-pref") === pref); });
  }
  document.getElementById("themeOpts").addEventListener("click", function (e) {
    var o = e.target.closest(".theme-opt"); if (!o) return;
    A.setThemePref(o.getAttribute("data-theme-pref")); paintThemeOpts();
  });
  el("themeBtn").addEventListener("click", function () { A.toggleTheme(); paintThemeOpts(); });
  paintThemeOpts();

  function fmtDate(s) {
    if (!s) return "—";
    try { return new Date(s.replace(" ", "T") + "Z").toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" }); }
    catch (e) { return s; }
  }

  /* ---- تحميل البروفايل ---- */
  async function loadProfile() {
    try {
      var d = await api("/api/account/profile");
      var u = d.profile || d.user || d;
      el("avatar").textContent = A.initials(u.name);
      el("pName").textContent = u.name || "—";
      el("pEmail").textContent = u.email || "—";
      el("pRole").textContent = u.role === "admin" ? "مدير" : "مستخدم";
      el("fName").value = u.name || "";
      el("fEmail").value = u.email || "";
      el("pCreated").textContent = fmtDate(u.createdAt || u.created_at);
      el("pLogin").textContent = fmtDate(u.lastLoginAt || u.last_login_at);
    } catch (e) { toast(e.message, "err"); }
  }

  async function loadApiToken() {
    try {
      var d = await api("/api/account/api-token");
      if (d && d.apiToken) el("apiTok").value = d.apiToken;
    } catch (e) {}
  }

  el("saveProfile").addEventListener("click", async function () {
    var btn = this; btn.disabled = true;
    try {
      await api("/api/account/profile", { method: "POST", body: { name: el("fName").value.trim(), email: el("fEmail").value.trim() } });
      toast("تم حفظ الملف الشخصي");
      loadProfile();
    } catch (e) { toast(e.message, "err"); } finally { btn.disabled = false; }
  });

  /* ---- كلمة المرور ---- */
  el("savePass").addEventListener("click", async function () {
    var cur = el("curPass").value, np = el("newPass").value, cp = el("conPass").value;
    if (np.length < 6) return toast("كلمة المرور الجديدة قصيرة (٦ أحرف على الأقل)", "err");
    if (np !== cp) return toast("تأكيد كلمة المرور غير مطابق", "err");
    var btn = this; btn.disabled = true;
    try {
      var d = await api("/api/account/password", { method: "POST", body: { current: cur, new: np, revokeOthers: el("revokeOthers").checked } });
      toast("تم تحديث كلمة المرور" + (d && d.revokedSessions ? " (أُنهيت " + d.revokedSessions + " جلسة)" : ""));
      el("curPass").value = el("newPass").value = el("conPass").value = "";
      loadSessions();
    } catch (e) { toast(e.message, "err"); } finally { btn.disabled = false; }
  });

  /* ---- الجلسات ---- */
  async function loadSessions() {
    var host = el("sessList");
    try {
      var d = await api("/api/account/sessions");
      var list = d.sessions || d || [];
      if (!list.length) { host.innerHTML = '<div class="empty"><div data-icon="device"></div><h4>لا جلسات</h4></div>'; A.paintIcons(host); return; }
      host.innerHTML = list.map(function (s) {
        return '<div class="sess">' +
          '<span class="avatar" style="width:34px;height:34px">' + A.svg("device") + '</span>' +
          '<div class="meta"><div class="ua">' + esc(s.ua || "جهاز غير معروف") + (s.current ? ' <span class="badge badge-ok">هذا الجهاز</span>' : '') + '</div>' +
          '<div class="muted" style="font-size:12.5px">' + esc(s.ip || "") + ' • آخر ظهور ' + fmtDate(s.lastSeen) + '</div></div>' +
          (s.current ? '' : '<button class="icon-btn revoke" data-sid="' + esc(s.sid) + '" title="إنهاء">' + A.svg("trash") + '</button>') +
          '</div>';
      }).join("");
    } catch (e) { host.innerHTML = '<div class="empty"><h4>تعذّر تحميل الجلسات</h4><div class="muted">' + esc(e.message) + '</div></div>'; }
  }
  el("sessList").addEventListener("click", async function (e) {
    var b = e.target.closest(".revoke"); if (!b) return;
    b.disabled = true;
    try { await api("/api/account/sessions/" + encodeURIComponent(b.getAttribute("data-sid")), { method: "DELETE" }); toast("أُنهيت الجلسة"); loadSessions(); }
    catch (err) { toast(err.message, "err"); b.disabled = false; }
  });
  el("revokeAll").addEventListener("click", async function () {
    if (!confirm("إنهاء كل الجلسات الأخرى؟")) return;
    try { var d = await api("/api/account/sessions/revoke-all", { method: "POST" }); toast("أُنهيت " + ((d && (d.revoked != null ? d.revoked : d.revokedSessions)) || 0) + " جلسة"); loadSessions(); }
    catch (e) { toast(e.message, "err"); }
  });

  /* ---- مفتاح API ---- */
  el("copyTok").addEventListener("click", function () {
    var v = el("apiTok").value; if (!v) return;
    navigator.clipboard.writeText(v).then(function () { toast("نُسخ المفتاح"); });
  });
  el("genTok").addEventListener("click", async function () {
    if (!confirm("إنشاء/تجديد المفتاح سيُبطل المفتاح الحالي. متابعة؟")) return;
    try { var d = await api("/api/account/api-token", { method: "POST" }); el("apiTok").value = (d && d.apiToken) || ""; toast("تم إنشاء المفتاح"); }
    catch (e) { toast(e.message, "err"); }
  });
  el("delTok").addEventListener("click", async function () {
    if (!confirm("حذف المفتاح؟")) return;
    try { await api("/api/account/api-token", { method: "DELETE" }); el("apiTok").value = ""; toast("حُذف المفتاح"); }
    catch (e) { toast(e.message, "err"); }
  });

  /* ---- بدء ---- */
  loadProfile();
  loadApiToken();
  loadSessions();
})();
