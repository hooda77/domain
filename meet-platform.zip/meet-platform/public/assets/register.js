    document.addEventListener("DOMContentLoaded", function () {
      var A = window.App;
      A.me(true).then(function (u) { if (u && (u.id || u.email)) location.href = "/dashboard.html"; }).catch(function () {});
      document.getElementById("regForm").addEventListener("submit", async function (e) {
        e.preventDefault();
        var name = document.getElementById("name").value.trim();
        var email = document.getElementById("email").value.trim();
        var pass = document.getElementById("password").value;
        var confirm = document.getElementById("confirm").value;
        if (pass.length < 6) return A.toast("كلمة المرور قصيرة (٦ أحرف على الأقل)", "err");
        if (pass !== confirm) return A.toast("تأكيد كلمة المرور غير مطابق", "err");
        var btn = document.getElementById("submitBtn");
        btn.disabled = true; btn.textContent = "جارٍ الإنشاء…";
        try {
          await A.api("/api/auth/register", { method: "POST", noRedirect: true, body: { name: name, email: email, password: pass } });
          location.href = "/dashboard.html";
        } catch (err) {
          A.toast(err.message || "تعذّر إنشاء الحساب", "err");
          btn.disabled = false; btn.textContent = "إنشاء الحساب";
        }
      });
    });
  
