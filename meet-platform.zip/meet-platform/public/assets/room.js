    // ================= api =================
    const api = {
      async request(method, path, body) {
        const opts = { method, credentials: "same-origin", headers: {} };
        if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
        const res = await fetch("/api" + path, opts);
        let data = null; try { data = await res.json(); } catch (_) {}
        if (!res.ok) throw new Error((data && data.error) ? data.error : "حدث خطأ (" + res.status + ")");
        return data;
      },
      get(p) { return this.request("GET", p); },
      post(p, b) { return this.request("POST", p, b || {}); },
      del(p) { return this.request("DELETE", p); },
    };
    // ================= session =================
    const session = {
      user: null,
      async load() { try { const d = await api.get("/auth/me"); this.user = d.user; return this.user; } catch (_) { this.user = null; return null; } },
      async requireAuth(redirect = "/index.html") {
        const u = await this.load();
        if (!u) window.location.href = redirect + "?next=" + encodeURIComponent(location.pathname + location.search);
        return u;
      },
    };
        // ================= room =================
    (async function () {
      const code = new URLSearchParams(location.search).get("room");
      if (!code) { location.href = "/dashboard.html"; return; }
      const user = await session.requireAuth("/index.html");
      if (!user) return;

      const LK = window.LivekitClient;
      const { Room, RoomEvent, Track, VideoPresets } = LK;

      let roomInfo, joinInfo;
      try {
        roomInfo = await api.get("/rooms/" + code);
      } catch (ex) { await App.alert(ex.message); location.href = "/dashboard.html"; return; }

      // اكتساب توكن الانضمام مع دعم الجدولة/غرفة الانتظار (تُعاد بـ 200 + waiting:true)
      joinInfo = await acquireJoin();
      if (!joinInfo) return;

      async function acquireJoin() {
        let overlay = null, cdTimer = null, roomPassword = "";
        const cleanup = () => { if (cdTimer) clearInterval(cdTimer); cdTimer = null; if (overlay) { overlay.remove(); overlay = null; } };
        function render(info) {
          if (!overlay) {
            overlay = document.createElement("div");
            overlay.className = "wait-overlay";
            overlay.innerHTML = '<div class="wait-card"><div class="wait-spin"><span class="spinner"></span></div>' +
              '<h2 class="wait-title"></h2><p class="wait-sub"></p><button class="wait-cancel">مغادرة</button></div>';
            document.body.appendChild(overlay);
            overlay.querySelector(".wait-cancel").addEventListener("click", () => { cleanup(); location.href = "/dashboard.html"; });
          }
          const title = overlay.querySelector(".wait-title"), sub = overlay.querySelector(".wait-sub");
          if (info.reason === "scheduled" && info.startsAt) {
            title.textContent = "لم يبدأ الاجتماع بعد";
            if (!cdTimer) {
              const startTs = new Date(info.startsAt.replace(" ", "T") + "Z").getTime();
              const upd = () => {
                const ms = startTs - Date.now();
                if (ms <= 0) { sub.textContent = "يبدأ الآن… جارٍ الدخول"; return; }
                const tot = Math.floor(ms / 1000), h = Math.floor(tot / 3600), m = Math.floor((tot % 3600) / 60), s = tot % 60;
                const pad = (n) => String(n).padStart(2, "0");
                sub.textContent = "يبدأ خلال " + (h > 0 ? h + ":" : "") + pad(m) + ":" + pad(s);
              };
              upd(); cdTimer = setInterval(upd, 1000);
            }
          } else {
            title.textContent = "بانتظار موافقة المضيف";
            sub.textContent = "سيتم إدخالك تلقائيًا فور موافقة المضيف على طلبك…";
          }
        }
        // نافذة إدخال كلمة مرور الاجتماع
        function promptPassword(wrong) {
          return new Promise((resolve) => {
            cleanup();
            const ov = document.createElement("div");
            ov.className = "wait-overlay";
            ov.innerHTML = '<div class="wait-card">' +
              '<div class="pw-lock"><svg viewBox="0 0 24 24" width="34" height="34"><rect x="4" y="10" width="16" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2"/></svg></div>' +
              '<h2 class="wait-title">اجتماع محمي بكلمة مرور</h2>' +
              '<p class="wait-sub">أدخل كلمة مرور الاجتماع للمتابعة.</p>' +
              '<input type="password" class="pw-input" placeholder="كلمة المرور" autocomplete="current-password" />' +
              '<p class="pw-err"' + (wrong ? "" : ' style="display:none"') + '>كلمة المرور غير صحيحة، حاول مجددًا.</p>' +
              '<div class="pw-actions"><button class="wait-cancel">مغادرة</button><button class="pw-go">دخول</button></div>' +
              '</div>';
            document.body.appendChild(ov);
            const input = ov.querySelector(".pw-input");
            setTimeout(() => input.focus(), 50);
            const submit = () => { const v = input.value.trim(); if (!v) { input.focus(); return; } ov.remove(); resolve(v); };
            ov.querySelector(".pw-go").addEventListener("click", submit);
            input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
            ov.querySelector(".wait-cancel").addEventListener("click", () => { ov.remove(); resolve(null); });
          });
        }
        while (true) {
          let info;
          try { info = await api.post("/rooms/" + code + "/token", { password: roomPassword }); }
          catch (ex) { cleanup(); await App.alert(ex.message); location.href = "/dashboard.html"; return null; }
          if (info && info.token) { cleanup(); return info; }
          if (info && info.needPassword) {
            const pw = await promptPassword(!!info.wrong);
            if (pw === null) { cleanup(); location.href = "/dashboard.html"; return null; }
            roomPassword = pw; continue;
          }
          if (info && info.waiting) { render(info); await new Promise((r) => setTimeout(r, 3000)); continue; }
          cleanup(); await App.alert("تعذّر الانضمام إلى الاجتماع"); location.href = "/dashboard.html"; return null;
        }
      }

      let isHost = !!joinInfo.isHost;
      let isOwner = !!joinInfo.isOwner;
      let locks = safeParse(joinInfo.settings);

      const gridEl = document.getElementById("grid");
      const spotlightEl = document.getElementById("spotlight");
      const connectingEl = document.getElementById("connecting");
      const searchEl = document.getElementById("search");
      const countEl = document.getElementById("count");
      const el = (id) => document.getElementById(id);

      el("roomName").textContent = roomInfo.room.name;
      el("roomCode").textContent = code;
      el("btnShare").addEventListener("click", async () => {
        const url = location.href;
        const shareData = { title: roomInfo.room.name || "اجتماع", text: "انضم إلى اجتماعي:", url };
        if (navigator.share) {
          try { await navigator.share(shareData); return; } catch (_) { /* أُلغي أو غير مدعوم — نكمل للنسخ */ }
        }
        try { await navigator.clipboard.writeText(url); toast("تم نسخ رابط الاجتماع"); }
        catch (_) { toast("تعذّر النسخ — انسخ الرابط يدويًا"); }
      });

      if (isHost) { el("btnMod").classList.remove("hidden"); el("btnRec").classList.remove("hidden"); }

      const tiles = new Map();
      let pinnedId = null;
      let userPinned = false;

      // حالة التسجيل المحلي (تُستخدم داخل attachTrack لإضافة الصوت الجديد للمزيج)
      let recActive = false, audioCtx = null, audioDest = null, mediaRecorder = null, recChunks = [], recMime = "";
      let recAudioScope = "all", recTargetIdentity = null, recOwnedTracks = [];
      const recConnected = new WeakSet();

      function safeParse(s) { try { return JSON.parse(s || "{}"); } catch (_) { return {}; } }
      function nameOf(p) { return p.name || "مستخدم"; }
      function metaOf(p) { return safeParse(p.metadata); }
      function initial(name) { return (name || "؟").trim().charAt(0); }
      function updateCount() { gridEl.dataset.count = String(tiles.size); const cn = el("countN"); if (cn) cn.textContent = String(tiles.size); layoutGrid(); }

      // شبكة تكيّفية بأسلوب Google Meet: نحسب أفضل عدد أعمدة يملأ المساحة المرئية بأكبر تايلات 16:9 ممكنة،
      // فيبدو التوزيع منظّمًا ومتساويًا على الهاتف والحاسوب دون تمرير أو فوضى.
      let _layoutRAF = 0;
      function layoutGrid() {
        if (_layoutRAF) return;
        _layoutRAF = requestAnimationFrame(() => {
          _layoutRAF = 0;
          if (document.body.dataset.mode === "spotlight") { gridEl.style.removeProperty("--cols"); gridEl.style.removeProperty("--tileW"); return; }
          const vis = [];
          tiles.forEach((t) => { if (!t.classList.contains("filtered-out")) vis.push(t); });
          const n = vis.length;
          if (!n) return;
          const W = gridEl.clientWidth, H = gridEl.clientHeight;
          if (W < 20 || H < 20) return;
          const gap = 12, AR = 16 / 9;
          let best = { area: -1, cols: 1, w: 0 };
          for (let cols = 1; cols <= n; cols++) {
            const rows = Math.ceil(n / cols);
            const tw = (W - gap * (cols - 1)) / cols;
            const th = (H - gap * (rows - 1)) / rows;
            if (tw <= 0 || th <= 0) continue;
            let w = tw, h = w / AR;
            if (h > th) { h = th; w = h * AR; }
            const area = w * h;
            if (area > best.area) best = { area, cols, w };
          }
          gridEl.style.setProperty("--cols", best.cols);
          gridEl.style.setProperty("--tileW", Math.floor(best.w) + "px");
        });
      }

      // مؤشّر جودة الاتصال لكل تايل
      function setQuality(identity, q) {
        const t = tiles.get(identity);
        if (!t) return;
        const ind = t.querySelector(".quality-ind");
        if (!ind) return;
        const cls = (q === "excellent" || q === "good" || q === "poor") ? q : (q === "lost" ? "poor" : "good");
        ind.classList.remove("q-excellent", "q-good", "q-poor");
        ind.classList.add("q-" + (cls === "excellent" ? "excellent" : cls === "poor" ? "poor" : "good"));
      }

      // مجموعة الأيدي المرفوعة (حالة لحظية عبر قناة البيانات)
      const handsUp = new Set();
      let localHandUp = false;
      let wbReady = false;

      // ============ الجودة: يحدّدها منشئ الغرفة على السيرفر، والترميز يتمّ على جهاز المستخدم ============
      // كل التايلات عريضة 16:9 (زي التليفزيون)؛ فيديو الموبايل الطولي يُقصّ ليملأ المستطيل.
      const q = joinInfo.quality || { maxHeight: 360, maxBitrate: 800, maxFps: 15 };
      const capH = Math.max(120, q.maxHeight | 0);            // "الدقة" = ارتفاع 16:9
      const capFps = Math.min(15, Math.max(5, q.maxFps | 0)); // مسموح 5..15
      const capBps = Math.max(200, Math.min(1000, q.maxBitrate | 0)) * 1000; // 200k..1M
      const capW = (() => { let w = Math.round(capH * 16 / 9); return w % 2 ? w + 1 : w; })(); // 16:9 عريض
      const lowH = capH >= 360 ? 180 : Math.min(144, capH);
      const lowW = (() => { let w = Math.round(lowH * 16 / 9); return w % 2 ? w + 1 : w; })();
      const room = new Room({
        adaptiveStream: true,
        dynacast: true,
        videoCaptureDefaults: { resolution: { width: capW, height: capH, frameRate: capFps }, facingMode: "user" },
        publishDefaults: {
          simulcast: true,
          videoSimulcastLayers: [
            { width: lowW, height: lowH, encoding: { maxBitrate: Math.round(capBps * 0.35), maxFramerate: Math.min(capFps, 10) } },
            { width: capW, height: capH, encoding: { maxBitrate: capBps, maxFramerate: capFps } },
          ],
          videoEncoding: { maxBitrate: capBps, maxFramerate: capFps },
          screenShareEncoding: { maxBitrate: Math.min(capBps * 2, 1500000), maxFramerate: Math.min(capFps, 10) },
          screenShareAudioEncoding: { maxBitrate: 96000 },
        },
      });

      function upsertTile(p) {
        let t = tiles.get(p.identity);
        if (!t) {
          t = document.createElement("div");
          t.className = "tile";
          t.dataset.identity = p.identity;
          t.innerHTML =
            '<div class="avatar"></div>' +
            '<video autoplay playsinline' + (p.isLocal ? " muted" : "") + "></video>" +
            '<div class="tile-actions">' +
              '<button class="btn-pin" title="تكبير"><svg><use href="#ic-pin"/></svg></button>' +
              '<button class="btn-full" title="ملء الشاشة"><svg><use href="#ic-full"/></svg></button>' +
            '</div>' +
            '<div class="label"><span class="mic"><svg><use href="#ic-mic"/></svg></span>' +
            '<span class="quality-ind" title="جودة الاتصال"><i></i><i></i><i></i></span>' +
            '<span class="nm"></span>' +
            '<span class="hand-badge" title="رفع اليد">✋</span>' +
            '<span class="speaking-badge"><span class="dot"></span>يتحدث الآن</span>' +
            '<span class="badge-host hidden">مضيف</span></div>';
          tiles.set(p.identity, t);
          gridEl.appendChild(t);
          updateCount();
          t.querySelector(".btn-pin").addEventListener("click", (e) => { e.stopPropagation(); userPinned = true; setPinned(pinnedId === p.identity ? null : p.identity); });
          t.querySelector(".btn-full").addEventListener("click", (e) => { e.stopPropagation(); if (document.fullscreenElement) document.exitFullscreen(); else t.requestFullscreen?.().catch(() => {}); });
          t.addEventListener("dblclick", () => { userPinned = true; setPinned(pinnedId === p.identity ? null : p.identity); });
          applyFilter();
        }
        t.querySelector(".avatar").textContent = initial(nameOf(p));
        t.querySelector(".nm").textContent = nameOf(p) + (p.isLocal ? " (أنت)" : "");
        const host = metaOf(p).role === "host";
        t.querySelector(".badge-host").classList.toggle("hidden", !host);
        t.dataset.name = nameOf(p);
        if (host && !userPinned && !pinnedId) setPinned(p.identity);
        if (p.connectionQuality) setQuality(p.identity, p.connectionQuality);
        if (handsUp.has(p.identity)) t.classList.add("hand-up");
        return t;
      }

      function removeTile(identity) {
        const t = tiles.get(identity);
        if (t) { if (pinnedId === identity) setPinned(null); t.remove(); tiles.delete(identity); updateCount(); }
      }
      function setPinned(identity) {
        if (pinnedId && tiles.has(pinnedId)) gridEl.appendChild(tiles.get(pinnedId));
        tiles.forEach((t) => t.classList.remove("pinned"));
        pinnedId = identity && tiles.has(identity) ? identity : null;
        if (pinnedId) {
          const t = tiles.get(pinnedId);
          spotlightEl.appendChild(t);
          t.classList.add("pinned");
          document.body.dataset.mode = "spotlight";
        } else {
          document.body.dataset.mode = "grid";
        }
        layoutGrid();
      }

      el("btnLayout").addEventListener("click", () => {
        if (pinnedId) { userPinned = true; setPinned(null); }
        else {
          let target = null;
          for (const [id, t] of tiles) { const b = t.querySelector(".badge-host"); if (b && !b.classList.contains("hidden")) { target = id; break; } }
          if (!target) target = tiles.keys().next().value;
          userPinned = true; setPinned(target || null);
        }
      });

      function applyFilter() {
        const q = (searchEl?.value || "").trim().toLowerCase();
        tiles.forEach((t) => {
          const hit = !q || (t.dataset.name || "").toLowerCase().includes(q);
          t.classList.toggle("filtered-out", !hit);
        });
        layoutGrid();
      }
      searchEl?.addEventListener("input", applyFilter);
      window.addEventListener("resize", layoutGrid);
      if (window.ResizeObserver) { try { new ResizeObserver(layoutGrid).observe(gridEl); } catch (_) {} }

      function showVideo(identity, on) {
        const t = tiles.get(identity);
        if (!t) return;
        t.querySelector("video").style.display = on ? "block" : "none";
        t.querySelector(".avatar").style.display = on ? "none" : "flex";
      }

      function attachTrack(track, p) {
        const t = upsertTile(p);
        if (track.kind === Track.Kind.Video) {
          const v = t.querySelector("video");
          track.attach(v);
          // اعكس العرض الذاتي للكاميرا فقط (كالمرآة) — لا الشاشة ولا الطرف الآخر
          v.style.transform = (p.isLocal && track.source === Track.Source.Camera) ? "scaleX(-1)" : "none";
          showVideo(p.identity, true);
        }
        else if (track.kind === Track.Kind.Audio && !p.isLocal) {
          const a = track.attach(); a.style.display = "none"; document.body.appendChild(a);
          if (recActive) maybeConnectAudio(track.mediaStreamTrack, p);
        }
      }
      room
        .on(RoomEvent.TrackSubscribed, (track, pub, p) => attachTrack(track, p))
        .on(RoomEvent.TrackUnsubscribed, (track, pub, p) => { track.detach(); if (track.kind === Track.Kind.Video) showVideo(p.identity, false); })
        .on(RoomEvent.LocalTrackPublished, (pub) => { if (pub.track) attachTrack(pub.track, room.localParticipant); })
        .on(RoomEvent.TrackMuted, (pub, p) => { if (pub.kind === Track.Kind.Video) showVideo(p.identity, false); })
        .on(RoomEvent.TrackUnmuted, (pub, p) => { if (pub.kind === Track.Kind.Video) showVideo(p.identity, true); })
        .on(RoomEvent.ParticipantConnected, (p) => { upsertTile(p); renderParticipants(); if (localHandUp) broadcastHand(true); })
        .on(RoomEvent.ParticipantDisconnected, (p) => { handsUp.delete(p.identity); removeTile(p.identity); renderParticipants(); })
        .on(RoomEvent.ActiveSpeakersChanged, (speakers) => { const active = new Set(speakers.map((s) => s.identity)); tiles.forEach((t, id) => t.classList.toggle("speaking", active.has(id))); })
        .on(RoomEvent.ConnectionQualityChanged, (q, p) => setQuality(p.identity, q))
        .on(RoomEvent.RoomMetadataChanged, (m) => { locks = safeParse(m); applyLocks(); })
        .on(RoomEvent.ParticipantMetadataChanged, (_prev, p) => {
          upsertTile(p);
          if (p.isLocal) {
            const nowHost = metaOf(p).role === "host";
            if (nowHost !== isHost) { setHostMode(nowHost); toast(nowHost ? "تم تعيينك مشرفًا للاجتماع" : "أُلغيت صلاحية إشرافك"); }
          } else { renderParticipants(); }
        })
        .on(RoomEvent.DataReceived, onData)
        .on(RoomEvent.Disconnected, () => { location.href = "/dashboard.html"; });

      try { await room.connect(joinInfo.url, joinInfo.token); }
      catch (ex) { await App.alert("تعذّر الاتصال: " + ex.message); location.href = "/dashboard.html"; return; }
      connectingEl.style.display = "none";

      upsertTile(room.localParticipant);
      room.remoteParticipants.forEach((p) => upsertTile(p));

      // ---- العدّاد التنازلي لمدة الغرفة (تُغلق تلقائيًا عند الانتهاء) ----
      if (joinInfo.expiresAt) {
        const endTs = new Date(joinInfo.expiresAt.replace(" ", "T") + "Z").getTime();
        const timerEl = el("timer");
        const timerT = el("timerT");
        timerEl.classList.remove("hidden");
        let ended = false;
        const tick = () => {
          const ms = endTs - Date.now();
          if (ms <= 0) {
            if (ended) return; ended = true;
            timerT.textContent = "انتهى";
            App.alert("انتهت مدة الاجتماع.");
            room.disconnect();
            return;
          }
          const total = Math.floor(ms / 1000);
          const h = Math.floor(total / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
          const pad = (n) => String(n).padStart(2, "0");
          timerT.textContent = (h > 0 ? h + ":" : "") + pad(m) + ":" + pad(s);
          timerEl.classList.toggle("text-red-400", ms <= 60000);
        };
        tick();
        setInterval(tick, 1000);
      }

      // الميك والكاميرا يبدآن مُطفأين ولا يُطلب أي إذن حتى ينقر المستخدم.
      const btnMic = el("btnMic"), btnCam = el("btnCam"), btnScreen = el("btnScreen"),
            btnChat = el("btnChat"), btnMod = el("btnMod"), btnLeave = el("btnLeave");
      // حالة أوّلية: مُطفأ (off) بلا نقطة خضراء
      btnMic.classList.add("off"); btnCam.classList.add("off");

      // نافذة مساعدة عند رفض الإذن — تُرشد المستخدم لإعادة السماح من المتصفح
      function showPermHelp(kind) {
        const label = kind === "camera" ? "الكاميرا" : "الميكروفون";
        const back = document.createElement("div");
        back.className = "rec-dialog-back";
        back.innerHTML =
          '<div class="rec-dialog">' +
            '<h3>تم حظر ' + label + '</h3>' +
            '<ul class="perm-list">' +
              '<li><b>1.</b> انقر أيقونة القفل/الكاميرا بجانب العنوان في المتصفح.</li>' +
              '<li><b>2.</b> اضبط إذن ' + label + ' على «سماح».</li>' +
              '<li><b>3.</b> أعد المحاولة بالنقر على الزر مرة أخرى.</li>' +
            '</ul>' +
            '<div class="perm-step">لو لم يظهر طلب الإذن، حدّث الصفحة بعد السماح.</div>' +
            '<div class="rec-actions"><button class="wb-btn" id="permRetry">إعادة المحاولة</button>' +
            '<button class="wb-btn close" id="permClose">إغلاق</button></div>' +
          '</div>';
        document.body.appendChild(back);
        const close = () => back.remove();
        back.querySelector("#permClose").addEventListener("click", close);
        back.addEventListener("click", (e) => { if (e.target === back) close(); });
        back.querySelector("#permRetry").addEventListener("click", () => {
          close();
          if (kind === "camera") toggleDevice("cam"); else toggleDevice("mic");
        });
      }

      // مبدّل موحّد للأجهزة مع حالة تحميل + إعادة طلب الإذن حتى بعد الرفض السابق
      async function toggleDevice(which) {
        const cam = which === "cam";
        const btn = cam ? btnCam : btnMic;
        if (btn.classList.contains("loading")) return;
        if (!isHost && (cam ? locks.lockCamera : locks.lockMic)) { toast("هذه الميزة مقفلة من المضيف"); return; }
        const turningOn = cam ? !room.localParticipant.isCameraEnabled : !room.localParticipant.isMicrophoneEnabled;
        btn.classList.add("loading"); btn.classList.remove("off", "active");
        try {
          if (cam) await room.localParticipant.setCameraEnabled(turningOn);
          else await room.localParticipant.setMicrophoneEnabled(turningOn);
          btn.classList.toggle("active", turningOn);
          btn.classList.toggle("off", !turningOn);
        } catch (ex) {
          // إعادة الحالة إلى مُطفأ
          btn.classList.add("off");
          const name = ex && (ex.name || ex.constructor?.name);
          if (name === "NotAllowedError" || name === "SecurityError" || /permission|denied/i.test(ex?.message || "")) {
            showPermHelp(cam ? "camera" : "mic");
          } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
            toast(cam ? "لا توجد كاميرا متاحة" : "لا يوجد ميكروفون متاح");
          } else {
            toast("تعذّر تشغيل " + (cam ? "الكاميرا" : "الميكروفون"));
          }
        } finally {
          btn.classList.remove("loading");
        }
      }

      btnMic.addEventListener("click", () => toggleDevice("mic"));
      btnCam.addEventListener("click", () => toggleDevice("cam"));
      btnScreen.addEventListener("click", async () => {
        if (btnScreen.classList.contains("loading")) return;
        if (!isHost && locks.lockScreenshare) { toast("مشاركة الشاشة مقفلة من المضيف"); return; }
        const on = !room.localParticipant.isScreenShareEnabled;
        btnScreen.classList.add("loading");
        try {
          // التقاط صوت النظام/التبويب مع الشاشة (يعمل على Chrome/Edge؛ Firefox محدود)
          await room.localParticipant.setScreenShareEnabled(on, on ? { audio: true, selfBrowserSurface: "include", systemAudio: "include" } : undefined);
          btnScreen.classList.toggle("active", on);
        } catch (ex) {
          const name = ex && (ex.name || ex.constructor?.name);
          if (name !== "NotAllowedError") toast("تعذّرت مشاركة الشاشة");
        } finally {
          btnScreen.classList.remove("loading");
        }
      });
      btnChat.addEventListener("click", () => togglePanel("chatPanel"));
      if (btnMod) btnMod.addEventListener("click", () => { togglePanel("modPanel"); renderParticipants(); });
      btnLeave.addEventListener("click", () => { stopRecording(); room.disconnect(); });

      // ================= رفع اليد =================
      const btnHand = el("btnHand");
      function broadcastHand(up, targetIdentity) {
        const id = targetIdentity || room.localParticipant.identity;
        const nm = targetIdentity ? "" : nameOf(room.localParticipant);
        try {
          room.localParticipant.publishData(
            enc.encode(JSON.stringify({ t: "hand", identity: id, name: nm, up: !!up })),
            { reliable: true }
          );
        } catch (_) {}
      }
      function setHandTile(identity, up) {
        if (up) handsUp.add(identity); else handsUp.delete(identity);
        const t = tiles.get(identity);
        if (t) t.classList.toggle("hand-up", up);
        if (isHost) renderParticipants();
      }
      if (btnHand) {
        btnHand.addEventListener("click", () => {
          localHandUp = !localHandUp;
          btnHand.classList.toggle("hand-on", localHandUp);
          setHandTile(room.localParticipant.identity, localHandUp);
          broadcastHand(localHandUp);
          if (localHandUp) toast("تم رفع يدك");
        });
      }

      // ================= السبّورة المشتركة =================
      const wbOverlay = el("wbOverlay"), wbCanvas = el("wbCanvas"), btnBoard = el("btnBoard");
      const wbCtx = wbCanvas ? wbCanvas.getContext("2d") : null;
      let wbColor = "#111111", wbWidth = 5, wbEraseW = 30, wbTool = "pen";
      let wbDrawing = false, wbLast = null, wbCur = null;
      const wbActions = []; // [{id,color,w,erase,segs:[{x0,y0,x1,y1}]}] — إحداثيات مطبَّعة 0..1
      const wbRedo = [];
      const wbLive = {}; // مخزّن مؤقت للخطوط الجارية من المشاركين الآخرين، مفتاحه id
      const wbCanDraw = () => isHost || !locks.lockBoard;
      const wbSend = (obj) => { try { room.localParticipant.publishData(enc.encode(JSON.stringify({ t: "wb", ...obj })), { reliable: true }); } catch (_) {} };
      const wbNewId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

      function wbResize() {
        if (!wbCanvas) return;
        const r = wbCanvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        wbCanvas.width = Math.max(1, Math.round(r.width * dpr));
        wbCanvas.height = Math.max(1, Math.round(r.height * dpr));
        wbRedraw();
      }
      function wbDrawSeg(seg, st) {
        if (!wbCtx) return;
        const dpr = window.devicePixelRatio || 1;
        wbCtx.globalCompositeOperation = st.erase ? "destination-out" : "source-over";
        wbCtx.strokeStyle = st.erase ? "rgba(0,0,0,1)" : st.color;
        wbCtx.lineWidth = st.w * dpr;
        wbCtx.lineCap = "round"; wbCtx.lineJoin = "round";
        wbCtx.beginPath();
        wbCtx.moveTo(seg.x0 * wbCanvas.width, seg.y0 * wbCanvas.height);
        wbCtx.lineTo(seg.x1 * wbCanvas.width, seg.y1 * wbCanvas.height);
        wbCtx.stroke();
      }
      function wbRedraw() {
        if (!wbCtx) return;
        wbCtx.globalCompositeOperation = "source-over";
        wbCtx.clearRect(0, 0, wbCanvas.width, wbCanvas.height);
        for (const a of wbActions) for (const seg of a.segs) wbDrawSeg(seg, a);
        wbCtx.globalCompositeOperation = "source-over";
      }
      function wbUpdateButtons() {
        const u = el("wbUndo"), r = el("wbRedo");
        const can = wbCanDraw();
        if (u) u.disabled = !can || wbActions.length === 0;
        if (r) r.disabled = !can || wbRedo.length === 0;
      }
      function wbApplyLock() {
        if (!wbOverlay) return;
        const locked = !wbCanDraw();
        wbOverlay.classList.toggle("locked", locked);
        wbCanvas.classList.toggle("locked", locked);
        const clr = el("wbClear"); if (clr) clr.style.display = isHost ? "" : "none";
        ["wbTools", "wbColor", "wbWidths", "wbEraserSizes"].forEach((id) => { const n = el(id); if (n) n.style.opacity = locked ? ".4" : "1"; });
        wbUpdateButtons();
      }
      function wbPoint(e) {
        const r = wbCanvas.getBoundingClientRect();
        return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
      }
      if (wbCanvas) {
        wbCanvas.addEventListener("pointerdown", (e) => {
          if (!wbCanDraw()) return;
          wbDrawing = true; wbLast = wbPoint(e); wbCanvas.setPointerCapture(e.pointerId);
          wbCur = { id: wbNewId(), color: wbColor, w: wbTool === "eraser" ? wbEraseW : wbWidth, erase: wbTool === "eraser", segs: [] };
          wbSend({ op: "start", id: wbCur.id, color: wbCur.color, w: wbCur.w, erase: wbCur.erase });
        });
        wbCanvas.addEventListener("pointermove", (e) => {
          if (!wbDrawing || !wbCur || !wbCanDraw()) return;
          const p = wbPoint(e);
          const seg = { x0: wbLast.x, y0: wbLast.y, x1: p.x, y1: p.y };
          wbLast = p;
          wbCur.segs.push(seg); wbDrawSeg(seg, wbCur);
          wbSend({ op: "draw", id: wbCur.id, ...seg });
        });
        const endDraw = () => {
          if (wbDrawing && wbCur) {
            if (wbCur.segs.length) { wbActions.push(wbCur); wbRedo.length = 0; wbSend({ op: "end", id: wbCur.id }); }
            wbUpdateButtons();
          }
          wbDrawing = false; wbCur = null;
        };
        wbCanvas.addEventListener("pointerup", endDraw);
        wbCanvas.addEventListener("pointercancel", endDraw);
        wbCanvas.addEventListener("pointerleave", endDraw);
      }
      // اختيار الأداة: قلم / ممحاة
      el("wbTools")?.addEventListener("click", (e) => {
        const b = e.target.closest("button"); if (!b) return;
        wbTool = b.dataset.tool;
        el("wbTools").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
        const eraser = wbTool === "eraser";
        el("wbEraserSizes").style.display = eraser ? "flex" : "none";
        el("wbWidths").style.display = eraser ? "none" : "flex";
        el("wbColor").style.display = eraser ? "none" : "";
      });
      el("wbColor")?.addEventListener("input", (e) => { wbColor = e.target.value; });
      el("wbWidths")?.addEventListener("click", (e) => {
        const b = e.target.closest("button"); if (!b) return;
        wbWidth = parseInt(b.dataset.w, 10) || 5;
        el("wbWidths").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      });
      el("wbEraserSizes")?.addEventListener("click", (e) => {
        const b = e.target.closest("button"); if (!b) return;
        wbEraseW = parseInt(b.dataset.e, 10) || 30;
        el("wbEraserSizes").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      });
      el("wbUndo")?.addEventListener("click", () => {
        if (!wbCanDraw() || !wbActions.length) return;
        const a = wbActions.pop(); wbRedo.push(a); wbRedraw(); wbUpdateButtons();
        wbSend({ op: "undo", id: a.id });
      });
      el("wbRedo")?.addEventListener("click", () => {
        if (!wbCanDraw() || !wbRedo.length) return;
        const a = wbRedo.pop(); wbActions.push(a); wbRedraw(); wbUpdateButtons();
        wbSend({ op: "redo", action: a });
      });
      el("wbClear")?.addEventListener("click", () => {
        if (!isHost) return;
        wbActions.length = 0; wbRedo.length = 0; wbRedraw(); wbUpdateButtons();
        wbSend({ op: "clear" });
      });
      el("wbClose")?.addEventListener("click", () => { if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); wbClose(); });
      el("wbFull")?.addEventListener("click", () => {
        if (document.fullscreenElement) { document.exitFullscreen?.().catch(() => {}); }
        else { wbOverlay.requestFullscreen?.().catch(() => {}); }
      });
      document.addEventListener("fullscreenchange", () => {
        const full = document.fullscreenElement === wbOverlay;
        wbOverlay.classList.toggle("wb-full", full);
        const fb = el("wbFull"); if (fb) fb.textContent = full ? "⛶ إنهاء ملء الشاشة" : "⛶ ملء الشاشة";
        if (!wbOverlay.classList.contains("hidden")) wbResize();
      });
      function wbIsOpen() { return wbOverlay && !wbOverlay.classList.contains("hidden"); }
      function wbClose() { if (btnBoard) btnBoard.classList.remove("active"); wbOverlay.classList.add("hidden"); }
      if (btnBoard) {
        btnBoard.addEventListener("click", () => {
          const opening = !wbIsOpen();
          if (opening) {
            // إغلاق أي لوحة جانبية أخرى — السبّورة حصرية
            ["chatPanel", "modPanel"].forEach((o) => el(o)?.classList.add("hidden"));
            wbOverlay.classList.remove("hidden");
            btnBoard.classList.add("active");
            wbResize(); wbApplyLock();
            // اطلب مزامنة اللوحة من الآخرين (يرد أول عميل لديه رسم)
            wbSend({ op: "sync-request" });
          } else { wbClose(); }
        });
      }
      window.addEventListener("resize", () => { if (wbIsOpen()) wbResize(); });
      wbReady = true; wbApplyLock();

      // ================= لوحة غرفة الانتظار (المضيف) =================
      let waitingPollTimer = null;
      async function pollWaitingOnce() {
        if (!isHost) return;
        let list = [];
        try { const r = await api.get("/rooms/" + code + "/waiting"); list = r.waiting || []; } catch (_) { return; }
        renderWaiting(list);
      }
      function renderWaiting(list) {
        const sec = el("waitingSection"), box = el("waitingList"), cnt = el("waitingCount");
        if (!sec || !box) return;
        sec.style.display = list.length ? "" : "none";
        if (cnt) cnt.textContent = String(list.length);
        box.innerHTML = "";
        for (const w of list) {
          const row = document.createElement("div");
          row.className = "wait-row";
          row.innerHTML = '<span class="truncate text-sm">' + escapeHtml(w.name || "مستخدم") + '</span>';
          const acts = document.createElement("div"); acts.className = "wr-actions";
          const ok = document.createElement("button"); ok.className = "wr-btn ok"; ok.textContent = "قبول";
          const no = document.createElement("button"); no.className = "wr-btn no"; no.textContent = "رفض";
          ok.addEventListener("click", () => decide(w.userId, "admit", w.name));
          no.addEventListener("click", () => decide(w.userId, "deny", w.name));
          acts.appendChild(ok); acts.appendChild(no); row.appendChild(acts); box.appendChild(row);
        }
      }
      async function decide(userId, decision, name) {
        try {
          await api.post("/rooms/" + code + "/admit", { userId, decision });
          toast(decision === "admit" ? "تم قبول " + (name || "") : "تم رفض " + (name || ""));
          pollWaitingOnce();
        } catch (ex) { App.alert(ex.message); }
      }
      function startWaitingPoll() {
        if (waitingPollTimer || !isHost || !(roomInfo.room && roomInfo.room.waitingRoom)) return;
        pollWaitingOnce();
        waitingPollTimer = setInterval(pollWaitingOnce, 3500);
      }
      function stopWaitingPoll() {
        if (waitingPollTimer) { clearInterval(waitingPollTimer); waitingPollTimer = null; }
        const sec = el("waitingSection"); if (sec) sec.style.display = "none";
      }
      startWaitingPoll();

      // ترقية/تنزيل صلاحية الإشراف حيًّا (بلا إعادة اتصال)
      function setHostMode(on) {
        isHost = on;
        el("btnMod").classList.toggle("hidden", !on);
        el("btnRec").classList.toggle("hidden", !on);
        if (!on) { el("modPanel")?.classList.add("hidden"); stopRecording(); }
        applyLocks();
        if (on) renderParticipants();
        if (on) startWaitingPoll(); else stopWaitingPoll();
      }

      // إشعار عابر
      let toastTimer = null;
      function toast(text) {
        let t = el("toast");
        if (!t) { t = document.createElement("div"); t.id = "toast"; t.className = "toast"; document.body.appendChild(t); }
        t.textContent = text; t.classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => t.classList.remove("show"), 3000);
      }

      const btnEndMeeting = el("btnEndMeeting");
      if (btnEndMeeting) {
        btnEndMeeting.addEventListener("click", async () => {
          if (!await App.confirm("إنهاء الاجتماع للجميع؟ سيتم فصل كل المشاركين وإغلاق الغرفة.", { title: "إنهاء الاجتماع", ok: "إنهاء", danger: true })) return;
          try { await api.post("/rooms/" + code + "/end"); } catch (_) {}
          room.disconnect();
        });
      }
      // فتح/إغلاق اللوحات الجانبية — أيّ لوحة تُغلق السبّورة تلقائيًا (حصرية متبادلة)
      function togglePanel(id) {
        const panel = el(id);
        if (!panel) return;
        const willOpen = panel.classList.contains("hidden");
        // فتح لوحة جانبية يغلق السبّورة إن كانت مفتوحة (بدل منع الفتح)
        if (willOpen && wbIsOpen()) wbClose();
        ["chatPanel", "modPanel"].forEach((o) => { if (o !== id) el(o)?.classList.add("hidden"); });
        panel.classList.toggle("hidden");
      }
      document.querySelectorAll(".side-close").forEach((b) =>
        b.addEventListener("click", () => el(b.dataset.close)?.classList.add("hidden")));

      // ---- تطبيق الأقفال على الواجهة ----
      function applyLocks() {
        if (!isHost) {
          if (locks.lockMic && room.localParticipant.isMicrophoneEnabled) room.localParticipant.setMicrophoneEnabled(false);
          if (locks.lockCamera && room.localParticipant.isCameraEnabled) room.localParticipant.setCameraEnabled(false);
          if (locks.lockScreenshare && room.localParticipant.isScreenShareEnabled) room.localParticipant.setScreenShareEnabled(false);
          btnMic.style.opacity = locks.lockMic ? ".4" : "1";
          btnCam.style.opacity = locks.lockCamera ? ".4" : "1";
          btnScreen.style.opacity = locks.lockScreenshare ? ".4" : "1";
          el("chatInput").disabled = !!locks.lockChat;
        }
        document.querySelectorAll("[data-lock]").forEach((cb) => { cb.checked = !!locks[camel(cb.dataset.lock)]; });
        if (wbReady) wbApplyLock();
      }
      function camel(k) { return k.replace(/_([a-z])/g, (_, c) => c.toUpperCase()); }
      applyLocks();

      // ================= الدردشة =================
      const enc = new TextEncoder(), dec = new TextDecoder();
      const chatMsgs = el("chatMsgs"), chatInput = el("chatInput"), chatSend = el("chatSend");

      function addMsg(from, text, mine) {
        const div = document.createElement("div");
        div.className = mine ? "text-left" : "text-right";
        div.innerHTML =
          '<span class="block text-xs text-gray-400">' + escapeHtml(from) + "</span>" +
          '<span class="inline-block bg-gray-700 rounded-lg px-2 py-1 mt-0.5">' + escapeHtml(text) + "</span>";
        chatMsgs.appendChild(div);
        chatMsgs.scrollTop = chatMsgs.scrollHeight;
      }

      function sendChat() {
        if (!isHost && locks.lockChat) return;
        const text = chatInput.value.trim();
        if (!text) return;
        const payload = enc.encode(JSON.stringify({ t: "chat", name: nameOf(room.localParticipant), text }));
        room.localParticipant.publishData(payload, { reliable: true });
        addMsg(nameOf(room.localParticipant), text, true);
        chatInput.value = "";
      }
      chatSend.addEventListener("click", sendChat);
      chatInput.addEventListener("keydown", (e) => { if (e.key === "Enter") sendChat(); });

      function onData(payload, participant) {
        let msg; try { msg = JSON.parse(dec.decode(payload)); } catch (_) { return; }
        try {
          if (msg.t === "chat") addMsg(msg.name || "مستخدم", msg.text || "", false);
          else if (msg.t === "role" && msg.identity === room.localParticipant.identity) {
            const nowHost = msg.role === "host";
            if (nowHost !== isHost) { setHostMode(nowHost); toast(nowHost ? "تم تعيينك مشرفًا للاجتماع" : "أُلغيت صلاحية إشرافك"); }
          }
          else if (msg.t === "hand") {
            const up = !!msg.up;
            setHandTile(msg.identity, up);
            if (up && isHost && msg.identity !== room.localParticipant.identity) toast("✋ " + (msg.name || "مشارك") + " رفع يده");
          }
          else if (msg.t === "wb") {
            const open = wbIsOpen();
            if (msg.op === "start") {
              wbLive[msg.id] = { id: msg.id, color: msg.color || "#111111", w: msg.w || 5, erase: !!msg.erase, segs: [] };
            } else if (msg.op === "draw") {
              let a = wbLive[msg.id];
              if (!a) { a = wbLive[msg.id] = { id: msg.id, color: msg.color || "#111111", w: msg.w || 5, erase: !!msg.erase, segs: [] }; }
              const seg = { x0: msg.x0, y0: msg.y0, x1: msg.x1, y1: msg.y1 };
              a.segs.push(seg);
              if (open) wbDrawSeg(seg, a);
            } else if (msg.op === "end") {
              const a = wbLive[msg.id];
              if (a) { delete wbLive[msg.id]; if (a.segs.length) { wbActions.push(a); wbRedo.length = 0; } if (!open) { /* سيُرسم عند الفتح */ } wbUpdateButtons(); }
            } else if (msg.op === "undo") {
              const i = wbActions.findIndex((x) => x.id === msg.id);
              if (i >= 0) { const a = wbActions.splice(i, 1)[0]; wbRedo.push(a); if (open) wbRedraw(); wbUpdateButtons(); }
            } else if (msg.op === "redo") {
              if (msg.action && msg.action.id) {
                const ri = wbRedo.findIndex((x) => x.id === msg.action.id);
                if (ri >= 0) wbRedo.splice(ri, 1);
                if (!wbActions.some((x) => x.id === msg.action.id)) wbActions.push(msg.action);
                if (open) wbRedraw(); wbUpdateButtons();
              }
            } else if (msg.op === "clear") {
              wbActions.length = 0; wbRedo.length = 0; for (const k in wbLive) delete wbLive[k];
              if (open) wbRedraw(); wbUpdateButtons();
            } else if (msg.op === "sync-request") {
              if (wbActions.length && participant) {
                try {
                  room.localParticipant.publishData(
                    enc.encode(JSON.stringify({ t: "wb", op: "sync", actions: wbActions })),
                    { reliable: true, destinationIdentities: [participant.identity] }
                  );
                } catch (_) {}
              }
            } else if (msg.op === "sync" && Array.isArray(msg.actions)) {
              if (wbActions.length === 0) { wbActions.push(...msg.actions); if (open) wbRedraw(); wbUpdateButtons(); }
            }
          }
        } catch (_) { /* عناصر لم تُهيّأ بعد في أول أجزاء الاتصال — نتجاهل بأمان */ }
      }

      function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
      }
      // ================= لوحة الإدارة (المضيف/المشرف) =================
      document.querySelectorAll("[data-lock]").forEach((cb) => {
        cb.addEventListener("change", async () => {
          if (!isHost) return;
          const patch = {};
          document.querySelectorAll("[data-lock]").forEach((c) => { patch[c.dataset.lock] = c.checked; });
          try {
            const r = await api.post("/rooms/" + code + "/settings", patch);
            locks = safeParse(r.settings);
            applyLocks();
          } catch (ex) { App.alert(ex.message); }
        });
      });

      // قائمة المشاركين + الكتم/الطرد (للمضيف)
      function renderParticipants() {
        if (!isHost) return;
        const box = el("participants");
        if (!box) return;
        box.innerHTML = "";
        const all = [room.localParticipant, ...room.remoteParticipants.values()];
        for (const p of all) {
          const row = document.createElement("div");
          row.className = "p-row";
          const isMe = p.isLocal;
          const handMark = handsUp.has(p.identity) ? ' <span title="رفع اليد">✋</span>' : '';
          row.innerHTML = '<div class="flex items-center gap-2 min-w-0">' +
            '<span class="p-avatar">' + escapeHtml(initial(nameOf(p))) + '</span>' +
            '<span class="truncate text-sm">' + escapeHtml(nameOf(p)) + (isMe ? " (أنت)" : "") + handMark + '</span></div>';
          if (!isMe) {
            const actions = document.createElement("div");
            actions.className = "flex gap-1 flex-shrink-0";
            const muteBtn = document.createElement("button");
            muteBtn.className = "p-btn mute";
            muteBtn.textContent = "كتم";
            muteBtn.addEventListener("click", async () => {
              let sid = null;
              p.trackPublications.forEach((pub) => {
                if (pub.kind === Track.Kind.Audio && pub.source === Track.Source.Microphone) sid = pub.trackSid;
              });
              if (!sid) { p.trackPublications.forEach((pub) => { if (pub.kind === Track.Kind.Audio) sid = pub.trackSid; }); }
              if (!sid) { App.alert("لا يوجد مسار صوت لكتمه."); return; }
              try { await api.post("/rooms/" + code + "/mute", { identity: p.identity, trackSid: sid, muted: true }); }
              catch (ex) { App.alert(ex.message); }
            });
            const kickBtn = document.createElement("button");
            kickBtn.className = "p-btn kick";
            kickBtn.textContent = "طرد";
            kickBtn.addEventListener("click", async () => {
              if (!await App.confirm("طرد " + nameOf(p) + "؟", { title: "طرد مشارك", ok: "طرد", danger: true })) return;
              try { await api.post("/rooms/" + code + "/kick", { identity: p.identity }); } catch (ex) { App.alert(ex.message); }
            });
            actions.appendChild(muteBtn); actions.appendChild(kickBtn);
            // إنزال يد مشارك رافع (بثّ حالة لحظية للجميع)
            if (handsUp.has(p.identity)) {
              const lowBtn = document.createElement("button");
              lowBtn.className = "p-btn";
              lowBtn.textContent = "إنزال اليد";
              lowBtn.addEventListener("click", () => { setHandTile(p.identity, false); broadcastHand(false, p.identity); });
              actions.appendChild(lowBtn);
            }
            // تعيين/إلغاء مشرف — لصاحب الاجتماع أو أدمن المنصّة فقط
            if (isOwner) {
              const targetIsHost = metaOf(p).role === "host";
              const coBtn = document.createElement("button");
              coBtn.className = "p-btn";
              coBtn.textContent = targetIsHost ? "إلغاء الإشراف" : "تعيين مشرف";
              coBtn.addEventListener("click", async () => {
                const uid = metaOf(p).userId;
                if (!uid) { App.alert("تعذّر تحديد المستخدم"); return; }
                try {
                  if (targetIsHost) await api.del("/rooms/" + code + "/cohost/" + uid);
                  else await api.post("/rooms/" + code + "/cohost", { userId: uid });
                  // بلّغ الطرف المعنيّ فورًا كي تتغيّر واجهته بلا إعادة تحميل
                  try {
                    const note = enc.encode(JSON.stringify({ t: "role", identity: "u" + uid, role: targetIsHost ? "user" : "host" }));
                    room.localParticipant.publishData(note, { reliable: true });
                  } catch (_) {}
                  renderParticipants();
                } catch (ex) { App.alert(ex.message); }
              });
              actions.appendChild(coBtn);
            }
            row.appendChild(actions);
          }
          box.appendChild(row);
        }
      }

      // ================= التسجيل المحلي =================
      // المُسجِّل يختار: أيّ فيديو (مشارك/شاشة) + نطاق الصوت (الجميع أو هذا المشارك فقط).
      // فرونت-إند بالكامل: لا يُرفع شيء للسيرفر. MP4 إن دعمه المتصفح، وإلا WebM.
      const btnRec = el("btnRec");

      // كل مصادر الفيديو المتاحة الآن (كاميرا/شاشة لكل مشارك له مسار فيديو حيّ)
      function videoSources() {
        const out = [];
        const add = (p) => p.trackPublications.forEach((pub) => {
          if (pub.kind === Track.Kind.Video && pub.track && pub.track.mediaStreamTrack && !pub.isMuted) {
            const isScreen = pub.source === Track.Source.ScreenShare;
            out.push({
              identity: p.identity,
              track: pub.track.mediaStreamTrack,
              label: nameOf(p) + (p.isLocal ? " (أنت)" : "") + (isScreen ? " — شاشة" : " — كاميرا"),
            });
          }
        });
        add(room.localParticipant);
        room.remoteParticipants.forEach(add);
        return out;
      }

      function connectAudioToMix(mst) {
        if (!mst || !audioCtx || !audioDest || recConnected.has(mst)) return;
        try {
          const src = audioCtx.createMediaStreamSource(new MediaStream([mst]));
          src.connect(audioDest);
          recConnected.add(mst);
        } catch (_) {}
      }

      // يوصّل صوت المسار فقط إن كان ضمن النطاق المختار (الجميع أو المشارك المستهدف)
      function maybeConnectAudio(mst, p) {
        if (recAudioScope === "none") return;
        if (recAudioScope === "one" && p && p.identity !== recTargetIdentity) return;
        connectAudioToMix(mst);
      }

      function collectScopedAudio() {
        const collect = (p) => p.trackPublications.forEach((pub) => {
          if (pub.kind === Track.Kind.Audio && pub.track && pub.track.mediaStreamTrack) maybeConnectAudio(pub.track.mediaStreamTrack, p);
        });
        collect(room.localParticipant);
        room.remoteParticipants.forEach(collect);
      }

      // قائمة كل المشاركين (لاختيار صوت شخص معيّن — مستقلًا عن الفيديو)
      function participantList() {
        const out = [];
        const add = (p) => out.push({ identity: p.identity, label: nameOf(p) + (p.isLocal ? " (أنت)" : "") });
        add(room.localParticipant);
        room.remoteParticipants.forEach(add);
        return out;
      }

      // نافذة اختيار مصدر التسجيل
      function openRecDialog() {
        if (typeof wbIsOpen === "function" && wbIsOpen()) wbClose();
        const vids = videoSources();
        const parts = participantList();
        const canVideo = vids.length > 0;
        const back = document.createElement("div");
        back.className = "rec-dialog-back";
        const vidOpts = canVideo
          ? vids.map((s, i) =>
              '<label class="rec-opt"><input type="radio" name="rec-vid" value="' + i + '"' + (i === 0 ? " checked" : "") + '><span>' + escapeHtml(s.label) + '</span></label>'
            ).join("")
          : '<div class="rec-lbl" style="margin:0">لا يوجد فيديو نشط الآن — يمكنك التسجيل صوتيًا فقط.</div>';
        const partOpts = parts.map((p) =>
          '<option value="' + escapeHtml(p.identity) + '">' + escapeHtml(p.label) + '</option>'
        ).join("");
        back.innerHTML =
          '<div class="rec-dialog" role="dialog" aria-modal="true">' +
            '<h3>بدء التسجيل</h3>' +
            '<div class="rec-sec"><div class="rec-lbl">نوع التسجيل</div>' +
              '<label class="rec-opt"><input type="radio" name="rec-type" value="screen" checked><span>🖥️ تسجيل شاشتي (اختر شاشة/نافذة/تبويب)</span></label>' +
              '<label class="rec-opt"><input type="radio" name="rec-type" value="video"' + (canVideo ? "" : " disabled") + '><span>فيديو مشارك من الاجتماع</span></label>' +
              '<label class="rec-opt"><input type="radio" name="rec-type" value="audio"><span>صوت فقط</span></label>' +
            '</div>' +
            '<div class="rec-sec" data-sec="vid" style="display:none"><div class="rec-lbl">الفيديو المُسجَّل</div>' + vidOpts + '</div>' +
            '<div class="rec-sec"><div class="rec-lbl">الصوت</div>' +
              '<label class="rec-opt"><input type="radio" name="rec-aud" value="all" checked><span>صوت الجميع (مدمج)</span></label>' +
              '<label class="rec-opt"><input type="radio" name="rec-aud" value="one"><span>صوت شخص معيّن</span></label>' +
              '<label class="rec-opt"><input type="radio" name="rec-aud" value="none"><span>بدون صوت المشاركين</span></label>' +
              '<select class="rec-select" data-aud-target style="display:none">' + partOpts + '</select>' +
            '</div>' +
            '<div class="rec-hint rec-lbl" style="margin-top:-4px">تلميح: «تسجيل شاشتي» + «صوت الجميع» = شاشتك مع أصوات كل المشاركين. اختر «صوت شخص معيّن» لصوت واحد فقط.</div>' +
            '<div class="rec-actions"><button class="wb-btn close" data-rec-cancel>إلغاء</button><button class="pw-go" data-rec-go>ابدأ التسجيل</button></div>' +
          '</div>';
        document.body.appendChild(back);
        const close = () => back.remove();
        const vidSec = back.querySelector('[data-sec="vid"]');
        const audSel = back.querySelector('[data-aud-target]');
        const syncType = () => {
          const t = back.querySelector('input[name="rec-type"]:checked').value;
          if (vidSec) vidSec.style.display = (t === "video" && canVideo) ? "" : "none";
        };
        const syncAud = () => {
          audSel.style.display = back.querySelector('input[name="rec-aud"]:checked').value === "one" ? "" : "none";
        };
        back.querySelectorAll('input[name="rec-type"]').forEach((r) => r.addEventListener("change", syncType));
        back.querySelectorAll('input[name="rec-aud"]').forEach((r) => r.addEventListener("change", syncAud));
        back.addEventListener("click", (e) => { if (e.target === back) close(); });
        back.querySelector("[data-rec-cancel]").addEventListener("click", close);
        back.querySelector("[data-rec-go]").addEventListener("click", async () => {
          const type = back.querySelector('input[name="rec-type"]:checked').value;
          const scope = back.querySelector('input[name="rec-aud"]:checked').value;
          const audTarget = scope === "one" ? audSel.value : null;
          let videoTrack = null, extraAudio = [];
          if (type === "screen") {
            // التقاط شاشة/نافذة مباشرةً للتسجيل (لا يُبثّ للغرفة) — يعمل على Chrome/Edge/Firefox
            let disp;
            try {
              disp = await navigator.mediaDevices.getDisplayMedia({
                video: { frameRate: 30 },
                audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
              });
            } catch (ex) {
              const nm = ex && (ex.name || "");
              if (nm !== "NotAllowedError" && nm !== "AbortError") toast("تعذّر التقاط الشاشة");
              return;
            }
            videoTrack = disp.getVideoTracks()[0] || null;
            extraAudio = disp.getAudioTracks(); // صوت النظام/التبويب إن وُجد
            if (!videoTrack) { toast("لم يتم اختيار شاشة"); return; }
            recOwnedTracks = disp.getTracks(); // مسارات نملكها ويجب إيقافها عند انتهاء التسجيل
          } else if (type === "video" && canVideo) {
            const vi = +back.querySelector('input[name="rec-vid"]:checked').value;
            videoTrack = vids[vi].track;
          }
          close();
          startRecording(videoTrack, scope, audTarget, extraAudio);
        });
      }

      async function startRecording(videoTrack, scope, targetIdentity, extraAudio) {
        if (recActive) return;
        try {
          recAudioScope = scope === "one" ? "one" : (scope === "none" ? "none" : "all");
          recTargetIdentity = targetIdentity || null;
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          audioDest = audioCtx.createMediaStreamDestination();
          if (recAudioScope !== "none") collectScopedAudio();
          // أضِف صوت الشاشة الملتقَط (النظام/التبويب) إن وُجد
          (extraAudio || []).forEach((tr) => { try { connectAudioToMix(tr); } catch (_) {} });
          const outTracks = [];
          if (videoTrack) outTracks.push(videoTrack);
          const mixedAudio = audioDest.stream.getAudioTracks();
          if (mixedAudio.length) outTracks.push(...mixedAudio);
          if (!outTracks.length) throw new Error("لا يوجد صوت أو فيديو للتسجيل.");
          // إن انتهت الشاشة الملتقطة (المستخدم ضغط «إيقاف المشاركة») يتوقف التسجيل تلقائيًا
          if (videoTrack) videoTrack.addEventListener("ended", () => stopRecording(), { once: true });
          const mixStream = new MediaStream(outTracks);
          if (videoTrack) {
            recMime = MediaRecorder.isTypeSupported("video/mp4")
              ? "video/mp4"
              : (MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus") ? "video/webm;codecs=vp8,opus" : "video/webm");
          } else {
            recMime = MediaRecorder.isTypeSupported("audio/mp4")
              ? "audio/mp4"
              : (MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm");
          }
          recChunks = [];
          mediaRecorder = new MediaRecorder(mixStream, { mimeType: recMime });
          mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size) recChunks.push(e.data); };
          mediaRecorder.onstop = () => finalizeRecording();
          mediaRecorder.start(1000);
          recActive = true;
          btnRec.classList.add("recording");
          btnRec.querySelector(".lb").textContent = "إيقاف";
          toast("بدأ التسجيل على جهازك");
        } catch (ex) {
          recActive = false;
          try { audioCtx && audioCtx.close(); } catch (_) {}
          try { recOwnedTracks.forEach((tr) => tr.stop()); } catch (_) {}
          recOwnedTracks = [];
          audioCtx = audioDest = null;
          App.alert("تعذّر بدء التسجيل: " + ex.message);
        }
      }

      function stopRecording() {
        if (!recActive) return;
        recActive = false;
        try { if (mediaRecorder && mediaRecorder.state !== "inactive") mediaRecorder.stop(); } catch (_) {}
        btnRec.classList.remove("recording");
        const lb = btnRec.querySelector(".lb"); if (lb) lb.textContent = "تسجيل";
      }

      function finalizeRecording() {
        try {
          const isAudio = recMime.startsWith("audio/");
          const ext = recMime.startsWith("video/mp4") ? "mp4"
            : recMime.startsWith("audio/mp4") ? "m4a"
            : "webm";
          const blob = new Blob(recChunks, { type: recMime.split(";")[0] });
          recChunks = [];
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
          a.href = url; a.download = (isAudio ? "audio-" : "meeting-") + code + "-" + ts + "." + ext;
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 4000);
          toast("تم حفظ التسجيل (" + ext.toUpperCase() + ")");
        } catch (_) {}
        try { audioCtx && audioCtx.close(); } catch (_) {}
        try { recOwnedTracks.forEach((tr) => tr.stop()); } catch (_) {}
        recOwnedTracks = [];
        audioCtx = audioDest = null; mediaRecorder = null;
        recAudioScope = "all"; recTargetIdentity = null;
      }

      btnRec.addEventListener("click", () => { recActive ? stopRecording() : openRecDialog(); });
      window.addEventListener("beforeunload", stopRecording);
    })();
