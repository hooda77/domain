-- ================================================================
--  007 — أعمدة الملف الشخصي على users (updated_at, last_login_at)
--  MySQL 8 لا يدعم ADD COLUMN IF NOT EXISTS، فنفحص information_schema
--  أولًا لكل عمود (idempotent) عبر PREPARE/EXECUTE.
-- ================================================================
SET NAMES utf8mb4;

SET @has_updated := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'updated_at'
);
SET @ddl := IF(@has_updated = 0,
  'ALTER TABLE users ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL',
  'DO 0');
PREPARE _mk1 FROM @ddl; EXECUTE _mk1; DEALLOCATE PREPARE _mk1;

SET @has_login := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'last_login_at'
);
SET @ddl := IF(@has_login = 0,
  'ALTER TABLE users ADD COLUMN last_login_at TIMESTAMP NULL DEFAULT NULL',
  'DO 0');
PREPARE _mk2 FROM @ddl; EXECUTE _mk2; DEALLOCATE PREPARE _mk2;
