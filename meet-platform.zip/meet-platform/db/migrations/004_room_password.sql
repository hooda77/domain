-- ================================================================
--  Migration 004 — كلمة مرور اختيارية للاجتماع
--  idempotent — آمنة لإعادة التطبيق على DB حيّة بلا فقد بيانات.
-- ================================================================
SET NAMES utf8mb4;

DROP PROCEDURE IF EXISTS add_col_if_missing;
DELIMITER //
CREATE PROCEDURE add_col_if_missing(IN tbl VARCHAR(64), IN col VARCHAR(64), IN ddl VARCHAR(255))
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND COLUMN_NAME = col
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN `', col, '` ', ddl);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

CALL add_col_if_missing('rooms', 'password_hash', 'VARCHAR(255) NULL DEFAULT NULL');

DROP PROCEDURE IF EXISTS add_col_if_missing;
