-- ================================================================
--  008 — حدود الحساب: رصيد ساعات المستخدم + سقف عدد المشاركين
--  users.minutes_balance : رصيد الدقائق المتاح للاستضافة (NULL = غير محدود)
--  users.max_participants : أقصى عدد مشاركين في اجتماع المستخدم (NULL = غير محدود)
--  rooms.max_participants : لقطة من حدّ المضيف وقت الإنشاء (NULL = غير محدود)
--  MySQL 8 لا يدعم ADD COLUMN IF NOT EXISTS → فحص information_schema (idempotent).
-- ================================================================
SET NAMES utf8mb4;

-- users.minutes_balance
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'minutes_balance');
SET @ddl := IF(@has = 0,
  'ALTER TABLE users ADD COLUMN minutes_balance INT NULL DEFAULT NULL',
  'DO 0');
PREPARE _m1 FROM @ddl; EXECUTE _m1; DEALLOCATE PREPARE _m1;

-- users.max_participants
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'max_participants');
SET @ddl := IF(@has = 0,
  'ALTER TABLE users ADD COLUMN max_participants INT NULL DEFAULT NULL',
  'DO 0');
PREPARE _m2 FROM @ddl; EXECUTE _m2; DEALLOCATE PREPARE _m2;

-- rooms.max_participants (لقطة حدّ المضيف)
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rooms' AND COLUMN_NAME = 'max_participants');
SET @ddl := IF(@has = 0,
  'ALTER TABLE rooms ADD COLUMN max_participants INT NULL DEFAULT NULL',
  'DO 0');
PREPARE _m3 FROM @ddl; EXECUTE _m3; DEALLOCATE PREPARE _m3;
