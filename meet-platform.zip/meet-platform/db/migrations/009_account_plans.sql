-- ================================================================
--  009 — نظام الباقات (plans/tiers) + فهارس أداء
--  users.plan              : باقة المستخدم (normal|vip1|vip2|vip3) — الافتراضي normal
--  users.plan_period_start : بداية نافذة التخصيص الحالية (مرساة التجديد الدوّار لكل مستخدم)
--  users.plan_renews_at    : موعد التجديد القادم (مشتقّ؛ يُخزَّن للعرض وتسريع الفحص)
--  توزيعات الباقات نفسها تُخزَّن في app_settings تحت المفتاح 'plan_tiers'.
--  التجديد كسول (بلا cron): يُحسب عند أوّل وصول بعد انقضاء الفترة.
--  MySQL 8 لا يدعم ADD COLUMN IF NOT EXISTS → فحص information_schema (idempotent).
-- ================================================================
SET NAMES utf8mb4;

-- users.plan
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'plan');
SET @ddl := IF(@has = 0,
  'ALTER TABLE users ADD COLUMN plan VARCHAR(16) NOT NULL DEFAULT ''normal''',
  'DO 0');
PREPARE _p1 FROM @ddl; EXECUTE _p1; DEALLOCATE PREPARE _p1;

-- users.plan_period_start
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'plan_period_start');
SET @ddl := IF(@has = 0,
  'ALTER TABLE users ADD COLUMN plan_period_start DATETIME NULL DEFAULT NULL',
  'DO 0');
PREPARE _p2 FROM @ddl; EXECUTE _p2; DEALLOCATE PREPARE _p2;

-- users.plan_renews_at
SET @has := (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'plan_renews_at');
SET @ddl := IF(@has = 0,
  'ALTER TABLE users ADD COLUMN plan_renews_at DATETIME NULL DEFAULT NULL',
  'DO 0');
PREPARE _p3 FROM @ddl; EXECUTE _p3; DEALLOCATE PREPARE _p3;

-- ---- فهارس أداء للقوائم الساخنة (idempotent عبر information_schema.STATISTICS) ----

-- rooms(host_user_id) — قوائم «غرفي» + السجل لكل مضيف
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rooms' AND INDEX_NAME = 'idx_rooms_host');
SET @ddl := IF(@has = 0, 'ALTER TABLE rooms ADD INDEX idx_rooms_host (host_user_id)', 'DO 0');
PREPARE _p4 FROM @ddl; EXECUTE _p4; DEALLOCATE PREPARE _p4;

-- rooms(is_active, expires_at) — حلقة الكنس + القوائم النشطة
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rooms' AND INDEX_NAME = 'idx_rooms_active_expiry');
SET @ddl := IF(@has = 0, 'ALTER TABLE rooms ADD INDEX idx_rooms_active_expiry (is_active, expires_at)', 'DO 0');
PREPARE _p5 FROM @ddl; EXECUTE _p5; DEALLOCATE PREPARE _p5;

-- rooms(archived_at) — حذف المؤرشفة بعد ساعة
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rooms' AND INDEX_NAME = 'idx_rooms_archived');
SET @ddl := IF(@has = 0, 'ALTER TABLE rooms ADD INDEX idx_rooms_archived (archived_at)', 'DO 0');
PREPARE _p6 FROM @ddl; EXECUTE _p6; DEALLOCATE PREPARE _p6;

-- attendance(session_id) — ربط الحضور بالجلسة في السجل
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND INDEX_NAME = 'idx_attendance_session');
SET @ddl := IF(@has = 0, 'ALTER TABLE attendance ADD INDEX idx_attendance_session (session_id)', 'DO 0');
PREPARE _p7 FROM @ddl; EXECUTE _p7; DEALLOCATE PREPARE _p7;

-- attendance(room_code, left_at) — إغلاق صفوف الحضور المفتوحة عند الأرشفة
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance' AND INDEX_NAME = 'idx_attendance_room_left');
SET @ddl := IF(@has = 0, 'ALTER TABLE attendance ADD INDEX idx_attendance_room_left (room_code, left_at)', 'DO 0');
PREPARE _p8 FROM @ddl; EXECUTE _p8; DEALLOCATE PREPARE _p8;

-- meeting_sessions(host_user_id, ended_at) — سجل الجلسات لكل مضيف
SET @has := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'meeting_sessions' AND INDEX_NAME = 'idx_sessions_host_ended');
SET @ddl := IF(@has = 0, 'ALTER TABLE meeting_sessions ADD INDEX idx_sessions_host_ended (host_user_id, ended_at)', 'DO 0');
PREPARE _p9 FROM @ddl; EXECUTE _p9; DEALLOCATE PREPARE _p9;
