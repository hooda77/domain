-- ================================================================
--  Migration 003 — مزايا احترافية (جدولة، غرفة انتظار، قفل السبّورة)
--  idempotent — آمنة لإعادة التطبيق على DB حيّة بلا فقد بيانات.
-- ================================================================
SET NAMES utf8mb4;

-- إجراء مساعد يضيف العمود فقط إن لم يكن موجودًا (MySQL 8 لا يدعم IF NOT EXISTS للأعمدة)
DROP PROCEDURE IF EXISTS add_col_if_missing;
DELIMITER //
CREATE PROCEDURE add_col_if_missing(IN tbl VARCHAR(64), IN col VARCHAR(64), IN ddl VARCHAR(255))
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND COLUMN_NAME = col
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN `', col, '` ', ddl);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

-- أعمدة الجدولة وغرفة الانتظار على rooms ---------------------------
CALL add_col_if_missing('rooms', 'starts_at',    'TIMESTAMP NULL DEFAULT NULL');
CALL add_col_if_missing('rooms', 'waiting_room', 'TINYINT(1) NOT NULL DEFAULT 0');

-- قفل السبّورة على room_settings -----------------------------------
CALL add_col_if_missing('room_settings', 'lock_board', 'TINYINT(1) NOT NULL DEFAULT 0');

DROP PROCEDURE IF EXISTS add_col_if_missing;

-- جدول طلبات الدخول لغرفة الانتظار ---------------------------------
CREATE TABLE IF NOT EXISTS room_admissions (
  room_id    BIGINT UNSIGNED NOT NULL,
  user_id    BIGINT UNSIGNED NOT NULL,
  name       VARCHAR(120) NOT NULL,
  status     ENUM('pending','admitted','denied') NOT NULL DEFAULT 'pending',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (room_id, user_id),
  CONSTRAINT fk_adm_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  CONSTRAINT fk_adm_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
