-- ================================================================
--  006 — سجل الجلسات والحضور (يبقى بعد حذف صفّ الغرفة)
--  جدولان مستقلّان بلا CASCADE من rooms (مفتاحهما room_code نصّي
--  + host_user_id مُخزَّن) كي يبقى السجل بعد حذف الغرفة المنتهية.
--  + عمود rooms.archived_at لعلامة الأرشفة (idempotent + توقيت الحذف).
-- ================================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS meeting_sessions (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  room_code         VARCHAR(16) NOT NULL,
  name              VARCHAR(190) NOT NULL,
  host_user_id      BIGINT UNSIGNED NULL,
  started_at        TIMESTAMP NULL DEFAULT NULL,
  ended_at          TIMESTAMP NULL DEFAULT NULL,
  duration_seconds  INT UNSIGNED NOT NULL DEFAULT 0,
  participant_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_ms_host (host_user_id),
  KEY idx_ms_code (room_code),
  KEY idx_ms_ended (ended_at),
  CONSTRAINT fk_ms_user FOREIGN KEY (host_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attendance (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id       BIGINT UNSIGNED NULL,
  room_code        VARCHAR(16) NOT NULL,
  identity         VARCHAR(190) NOT NULL,
  name             VARCHAR(190) NOT NULL DEFAULT '',
  joined_at        TIMESTAMP NULL DEFAULT NULL,
  left_at          TIMESTAMP NULL DEFAULT NULL,
  duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_at_sess (session_id),
  KEY idx_at_open (room_code, identity, left_at),
  CONSTRAINT fk_at_sess FOREIGN KEY (session_id) REFERENCES meeting_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- علامة أرشفة الغرفة للسجل (تمنع الأرشفة المزدوجة وتحكم توقيت الحذف)
-- MySQL 8 لا يدعم ADD COLUMN IF NOT EXISTS، لذا نفحص information_schema أولًا (idempotent)
SET @has_archived := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rooms' AND COLUMN_NAME = 'archived_at'
);
SET @ddl := IF(@has_archived = 0,
  'ALTER TABLE rooms ADD COLUMN archived_at TIMESTAMP NULL DEFAULT NULL',
  'DO 0');
PREPARE _mk_stmt FROM @ddl;
EXECUTE _mk_stmt;
DEALLOCATE PREPARE _mk_stmt;

