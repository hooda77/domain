-- ================================================================
--  Migration 002 — إعدادات الجودة + مدة الغرفة + إعدادات عامة قابلة للتحرير
-- ================================================================
SET NAMES utf8mb4;

-- إعدادات عامة قابلة للتحرير من لوحة الأدمن (قوائم الجودة/المدة...) ----
CREATE TABLE IF NOT EXISTS app_settings (
  k          VARCHAR(80)  NOT NULL,
  v          JSON         NOT NULL,
  updated_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- القيم الافتراضية (تُدرج مرة واحدة؛ التحرير من الأدمن بانل) --------
INSERT INTO app_settings (k, v) VALUES
  ('resolution_presets', JSON_ARRAY(
      JSON_OBJECT('label','240p','height',240),
      JSON_OBJECT('label','360p','height',360),
      JSON_OBJECT('label','480p','height',480),
      JSON_OBJECT('label','720p','height',720)
  )),
  ('bitrate_presets', JSON_ARRAY(
      JSON_OBJECT('label','200k','kbps',200),
      JSON_OBJECT('label','800k','kbps',800),
      JSON_OBJECT('label','1M','kbps',1000)
  )),
  ('fps_presets', JSON_ARRAY(
      JSON_OBJECT('label','10 fps','fps',10),
      JSON_OBJECT('label','15 fps','fps',15)
  )),
  ('duration_presets', JSON_ARRAY(
      JSON_OBJECT('label','ساعة','hours',1),
      JSON_OBJECT('label','ساعتان','hours',2),
      JSON_OBJECT('label','3 ساعات','hours',3),
      JSON_OBJECT('label','4 ساعات','hours',4),
      JSON_OBJECT('label','5 ساعات','hours',5),
      JSON_OBJECT('label','6 ساعات','hours',6)
  ))
ON DUPLICATE KEY UPDATE k = k;

-- أعمدة الجودة/المدة على الغرف (MySQL 8 لا يدعم IF NOT EXISTS للأعمدة)
-- إجراء مساعد يضيف العمود فقط إن لم يكن موجودًا (تشغيل آمن متكرر) ----
DROP PROCEDURE IF EXISTS add_col_if_missing;
DELIMITER //
CREATE PROCEDURE add_col_if_missing(IN tbl VARCHAR(64), IN col VARCHAR(64), IN ddl VARCHAR(255))
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = tbl AND COLUMN_NAME = col
  ) THEN
    SET @s = CONCAT('ALTER TABLE `', tbl, '` ADD COLUMN `', col, '` ', ddl);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

CALL add_col_if_missing('rooms', 'max_height',       'INT NOT NULL DEFAULT 360');
CALL add_col_if_missing('rooms', 'max_bitrate_kbps', 'INT NOT NULL DEFAULT 800');
CALL add_col_if_missing('rooms', 'max_fps',          'INT NOT NULL DEFAULT 15');
CALL add_col_if_missing('rooms', 'duration_minutes', 'INT NOT NULL DEFAULT 120');
CALL add_col_if_missing('rooms', 'expires_at',       'TIMESTAMP NULL DEFAULT NULL');

DROP PROCEDURE IF EXISTS add_col_if_missing;
