-- ================================================================
--  مخطط قاعدة بيانات منصة الاجتماعات (MySQL 8+)
-- ================================================================
SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- المستخدمون --------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email         VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name          VARCHAR(120) NOT NULL,
  role          ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- النودز (سيرفرات الميديا) -----------------------------------------
CREATE TABLE IF NOT EXISTS nodes (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name         VARCHAR(120) NOT NULL,
  host         VARCHAR(190) NOT NULL,           -- IP أو hostname
  ssh_user     VARCHAR(120) NOT NULL DEFAULT 'root',
  ssh_port     INT NOT NULL DEFAULT 22,
  region       VARCHAR(120) DEFAULT NULL,
  is_main      TINYINT(1) NOT NULL DEFAULT 0,   -- السيرفر الأساسي (لوحة + نود)
  status       ENUM('online','offline','provisioning','error') NOT NULL DEFAULT 'provisioning',
  last_error   TEXT DEFAULT NULL,
  last_seen    TIMESTAMP NULL DEFAULT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_nodes_host (host)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- الغرف -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rooms (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  room_code    VARCHAR(16) NOT NULL,            -- ID المختصر الذي يُرسل للناس
  name         VARCHAR(190) NOT NULL,
  host_user_id BIGINT UNSIGNED NOT NULL,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  max_height       INT NOT NULL DEFAULT 360,   -- أقصى دقة رأسية (px)
  max_bitrate_kbps INT NOT NULL DEFAULT 800,   -- أقصى bitrate بالكيلوبت
  max_fps          INT NOT NULL DEFAULT 15,    -- أقصى إطارات/ثانية
  duration_minutes INT NOT NULL DEFAULT 120,   -- مدة الغرفة بالدقائق
  starts_at    TIMESTAMP NULL DEFAULT NULL,    -- موعد البدء المجدول (NULL = فوري)
  waiting_room TINYINT(1) NOT NULL DEFAULT 0,  -- تفعيل غرفة الانتظار
  expires_at   TIMESTAMP NULL DEFAULT NULL,    -- تُغلق تلقائيًا بعده
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at     TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rooms_code (room_code),
  KEY idx_rooms_host (host_user_id),
  CONSTRAINT fk_rooms_host FOREIGN KEY (host_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إعدادات الغرفة (أقفال الأدمن) ------------------------------------
CREATE TABLE IF NOT EXISTS room_settings (
  room_id          BIGINT UNSIGNED NOT NULL,
  lock_camera      TINYINT(1) NOT NULL DEFAULT 0,
  lock_mic         TINYINT(1) NOT NULL DEFAULT 0,
  lock_chat        TINYINT(1) NOT NULL DEFAULT 0,
  lock_screenshare TINYINT(1) NOT NULL DEFAULT 0,
  lock_board       TINYINT(1) NOT NULL DEFAULT 0,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (room_id),
  CONSTRAINT fk_settings_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- المطرودون من الغرفة ----------------------------------------------
CREATE TABLE IF NOT EXISTS kicked (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  room_id    BIGINT UNSIGNED NOT NULL,
  identity   VARCHAR(190) NOT NULL,             -- هوية المشارك في LiveKit
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_kicked (room_id, identity),
  CONSTRAINT fk_kicked_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- المشرفون المعيّنون لكل غرفة (co-hosts) --------------------------
CREATE TABLE IF NOT EXISTS room_cohosts (
  room_id    BIGINT UNSIGNED NOT NULL,
  user_id    BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (room_id, user_id),
  KEY idx_cohosts_user (user_id),
  CONSTRAINT fk_cohosts_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  CONSTRAINT fk_cohosts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- طلبات الدخول لغرفة الانتظار --------------------------------------
CREATE TABLE IF NOT EXISTS room_admissions (
  room_id    BIGINT UNSIGNED NOT NULL,
  user_id    BIGINT UNSIGNED NOT NULL,
  name       VARCHAR(120) NOT NULL,
  status     ENUM('pending','admitted','denied') NOT NULL DEFAULT 'pending',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (room_id, user_id),
  CONSTRAINT fk_adm_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  CONSTRAINT fk_adm_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- التسجيلات ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS recordings (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  room_id    BIGINT UNSIGNED NOT NULL,
  egress_id  VARCHAR(120) DEFAULT NULL,
  filename   VARCHAR(255) DEFAULT NULL,
  status     ENUM('starting','active','ending','complete','failed') NOT NULL DEFAULT 'starting',
  size_bytes BIGINT UNSIGNED DEFAULT NULL,
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at   TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_recordings_room (room_id),
  KEY idx_recordings_egress (egress_id),
  CONSTRAINT fk_recordings_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إعدادات عامة قابلة للتحرير من لوحة الأدمن -------------------------
CREATE TABLE IF NOT EXISTS app_settings (
  k          VARCHAR(80)  NOT NULL,
  v          JSON         NOT NULL,
  updated_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_settings (k, v) VALUES
  ('resolution_presets', JSON_ARRAY(
      JSON_OBJECT('label','240p','height',240),
      JSON_OBJECT('label','360p','height',360),
      JSON_OBJECT('label','480p','height',480),
      JSON_OBJECT('label','720p','height',720))),
  ('bitrate_presets', JSON_ARRAY(
      JSON_OBJECT('label','200k','kbps',200),
      JSON_OBJECT('label','800k','kbps',800),
      JSON_OBJECT('label','1M','kbps',1000))),
  ('fps_presets', JSON_ARRAY(
      JSON_OBJECT('label','10 fps','fps',10),
      JSON_OBJECT('label','15 fps','fps',15))),
  ('duration_presets', JSON_ARRAY(
      JSON_OBJECT('label','ساعة','hours',1),
      JSON_OBJECT('label','ساعتان','hours',2),
      JSON_OBJECT('label','3 ساعات','hours',3),
      JSON_OBJECT('label','4 ساعات','hours',4),
      JSON_OBJECT('label','5 ساعات','hours',5),
      JSON_OBJECT('label','6 ساعات','hours',6)))
ON DUPLICATE KEY UPDATE k = k;
