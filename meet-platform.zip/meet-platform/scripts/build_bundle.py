#!/usr/bin/env python3
"""يبني meet-platform.zip بمسارات forward-slash وجذر meet-platform/ (لا PowerShell)."""
import zipfile, os

ROOT = "meet-platform"
INCLUDE_DIRS = ["backend", "public", "db", "config", "nginx", "php", "scripts"]
INCLUDE_FILES = ["install.sh", "README.md", "composer.json", ".env.example", "docker-compose.yml"]
SKIP_PARTS = {".git", "node_modules", ".claude", "vendor", "__pycache__"}


def norm(p):
    return p.replace(os.sep, "/")


def keep(path):
    parts = set(norm(path).split("/"))
    return not (parts & SKIP_PARTS)


def main():
    n = 0
    with zipfile.ZipFile("meet-platform.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for d in INCLUDE_DIRS:
            if not os.path.isdir(d):
                continue
            for base, dirs, files in os.walk(d):
                dirs[:] = [x for x in dirs if x not in SKIP_PARTS]
                if not keep(base):
                    continue
                for f in files:
                    if f.endswith((".zip", ".log", ".pyc")):
                        continue
                    p = os.path.join(base, f)
                    z.write(p, ROOT + "/" + norm(p))
                    n += 1
        for f in INCLUDE_FILES:
            if os.path.isfile(f):
                z.write(f, ROOT + "/" + f)
                n += 1
    print("files written:", n)


if __name__ == "__main__":
    main()
