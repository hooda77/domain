<?php
// ================================================================
//  cleanup.php — تنظيف دوري يُشغَّل عبر systemd timer/cron
//  - يؤرشف الغرف التي تجاوزت مدتها (سجل + فصل الجميع)
//  - يحذف صفّ الغرفة المؤرشفة بعد ساعة (السجل يبقى)
//  - يقلّم السجل الأقدم من 30 يومًا
//  التشغيل:  php /var/www/scripts/cleanup.php
// ================================================================
declare(strict_types=1);

require __DIR__ . '/../backend/config.php';

use App\Db;
use App\LiveKit;

// حمّل دوال التطبيق (archive_room وغيرها) دون تنفيذ التوجيه
// index.php يعرّف الدوال ثم يوجّه؛ نحن نستدعي archive_room مباشرة عبر تكرار المنطق هنا
// لتفادي أعباء التوجيه، ننفّذ الأرشفة بنفس خطوات archive_room.

$now = date('c');

/** أرشفة غرفة (مطابقة لِـ archive_room في index.php) */
function cli_archive_room(array $room): void
{
    if (!empty($room['archived_at'])) return;
    $code = (string) $room['room_code'];
    try {
        Db::q("UPDATE attendance SET left_at=NOW(), duration_seconds=GREATEST(0, TIMESTAMPDIFF(SECOND, joined_at, NOW())) WHERE room_code=? AND left_at IS NULL", [$code]);
        $agg = Db::one("SELECT COUNT(DISTINCT identity) AS cnt, MIN(joined_at) AS first_join FROM attendance WHERE room_code=?", [$code]) ?: ['cnt' => 0, 'first_join' => null];
        $startedAt = $agg['first_join'] ?: ($room['starts_at'] ?? $room['created_at'] ?? date('Y-m-d H:i:s'));
        $endedAt   = $room['ended_at'] ?: date('Y-m-d H:i:s');
        $dur       = max(0, strtotime($endedAt) - strtotime((string) $startedAt));
        $sid = Db::insert("INSERT INTO meeting_sessions (room_code, name, host_user_id, started_at, ended_at, duration_seconds, participant_count) VALUES (?,?,?,?,?,?,?)", [$code, (string) ($room['name'] ?? $code), $room['host_user_id'] ?? null, $startedAt, $endedAt, $dur, (int) $agg['cnt']]);
        Db::q("UPDATE attendance SET session_id=? WHERE room_code=? AND session_id IS NULL", [$sid, $code]);
    } catch (\Throwable $e) {}
    try { Db::q("UPDATE rooms SET is_active=0, ended_at=COALESCE(ended_at, NOW()), archived_at=NOW() WHERE id=?", [$room['id']]); } catch (\Throwable $e) {}
    try { LiveKit::deleteRoom($code); } catch (\Throwable $e) {}
}

// 1) أرشِف الغرف المنتهية بالمدة
$archived = 0;
try {
    $rows = Db::all("SELECT * FROM rooms WHERE is_active=1 AND expires_at IS NOT NULL AND expires_at <= NOW()");
    foreach ($rows as $r) { cli_archive_room($r); $archived++; }
} catch (\Throwable $e) {
    fwrite(STDERR, "archive error: " . $e->getMessage() . "\n");
}

// 2) احذف صفّ الغرفة المؤرشفة بعد ساعة (السجل يبقى — بلا FK للغرف)
$deleted = 0;
try {
    $st = Db::q("DELETE FROM rooms WHERE archived_at IS NOT NULL AND archived_at <= (NOW() - INTERVAL 1 HOUR)");
    $deleted = $st->rowCount();
} catch (\Throwable $e) {
    fwrite(STDERR, "delete error: " . $e->getMessage() . "\n");
}

// 3) قلّم السجل الأقدم من 30 يومًا (CASCADE يزيل attendance المرتبط)
$pruned = 0;
try {
    $st = Db::q("DELETE FROM meeting_sessions WHERE ended_at IS NOT NULL AND ended_at <= (NOW() - INTERVAL 30 DAY)");
    $pruned = $st->rowCount();
} catch (\Throwable $e) {
    fwrite(STDERR, "prune error: " . $e->getMessage() . "\n");
}

fwrite(STDOUT, "[$now] cleanup: archived=$archived deleted=$deleted pruned=$pruned\n");
