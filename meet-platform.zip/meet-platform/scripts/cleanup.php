<?php
// ================================================================
//  cleanup.php — تنظيف دوري يُشغَّل عبر systemd timer/cron
//  - يغلق الغرف التي تجاوزت مدتها
//  - يحذف نهائيًا الاجتماعات المنتهية منذ أكثر من 24 ساعة (CASCADE)
//  التشغيل:  php /var/www/scripts/cleanup.php
// ================================================================
declare(strict_types=1);

require __DIR__ . '/../backend/config.php';

use App\Db;
use App\LiveKit;

$now = date('c');

// 1) أغلق الغرف المنتهية بالمدة
$closed = 0;
try {
    $rows = Db::all("SELECT * FROM rooms WHERE is_active=1 AND expires_at IS NOT NULL AND expires_at <= NOW()");
    foreach ($rows as $r) {
        Db::q("UPDATE rooms SET is_active=0, ended_at=NOW() WHERE id=?", [$r['id']]);
        try { LiveKit::deleteRoom($r['room_code']); } catch (\Throwable $e) {}
        $closed++;
    }
} catch (\Throwable $e) {
    fwrite(STDERR, "close error: " . $e->getMessage() . "\n");
}

// 2) احذف الاجتماعات المنتهية منذ أكثر من 24 ساعة
$deleted = 0;
try {
    $st = Db::q("DELETE FROM rooms WHERE is_active=0 AND ended_at IS NOT NULL AND ended_at <= (NOW() - INTERVAL 24 HOUR)");
    $deleted = $st->rowCount();
} catch (\Throwable $e) {
    fwrite(STDERR, "delete error: " . $e->getMessage() . "\n");
}

fwrite(STDOUT, "[$now] cleanup: closed=$closed deleted=$deleted\n");
