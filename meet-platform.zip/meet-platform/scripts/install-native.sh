#!/usr/bin/env bash
# ================================================================
#  install-native.sh — تنصيب المنصة أصليًا (بدون Docker) بإصدارات مثبّتة
#  يُشغّل على السيرفر الأساسي (Ubuntu 22.04) بصلاحية root
#  يُستدعى من داخل مجلد المشروع المرفوع (يحتوي backend/ public/ …)
# ================================================================
set -euo pipefail

# ---- إعدادات ثابتة (مثبّتة الإصدار) ----
APP_DOMAIN="${APP_DOMAIN:-gobixo.com}"
LIVEKIT_DOMAIN="${LIVEKIT_DOMAIN:-livekit.gobixo.com}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@gobixo.com}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-admin123}"
PUBLIC_IP="${PUBLIC_IP:-89.167.19.237}"
PHP_VER="8.2"
LIVEKIT_VERSION="1.13.7"

SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"   # جذر المشروع المرفوع
APP_DIR="/var/www/meet"
REC_DIR="/var/lib/meet/recordings"
ENV_FILE="$APP_DIR/.env"

export DEBIAN_FRONTEND=noninteractive

log(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }

# ================================================================
log "0/9  إزالة أي Docker سابق (إن وُجد) + حِزم أساسية"
systemctl stop docker 2>/dev/null || true
apt-get remove -y docker docker-engine docker.io containerd runc docker-ce docker-ce-cli containerd.io docker-compose-plugin 2>/dev/null || true
apt-get update -y
apt-get install -y curl wget gnupg lsb-release ca-certificates software-properties-common \
  unzip git jq openssl gettext-base ufw

# ================================================================
log "1/9  توليد/تحميل الأسرار في .env"
mkdir -p "$APP_DIR" "$REC_DIR"
gen(){ openssl rand -hex "${1:-24}"; }
if [ -f "$ENV_FILE" ]; then
  set -a; . "$ENV_FILE"; set +a
fi
JWT_SECRET="${JWT_SECRET:-$(gen 32)}"
DB_PASSWORD="${DB_PASSWORD:-$(gen 20)}"
DB_ROOT_PASSWORD="${DB_ROOT_PASSWORD:-$(gen 20)}"
REDIS_PASSWORD="${REDIS_PASSWORD:-$(gen 20)}"
LIVEKIT_API_KEY="${LIVEKIT_API_KEY:-APt$(gen 6)}"
LIVEKIT_API_SECRET="${LIVEKIT_API_SECRET:-$(gen 32)}"
TURN_SECRET="${TURN_SECRET:-$(gen 24)}"

cat > "$ENV_FILE" <<ENV
APP_DOMAIN=$APP_DOMAIN
LIVEKIT_DOMAIN=$LIVEKIT_DOMAIN
ADMIN_EMAIL=$ADMIN_EMAIL
APP_URL=https://$APP_DOMAIN
APP_ENV=production
JWT_SECRET=$JWT_SECRET
JWT_TTL=604800
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=meet
DB_USER=meet
DB_PASSWORD=$DB_PASSWORD
DB_ROOT_PASSWORD=$DB_ROOT_PASSWORD
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_PASSWORD=$REDIS_PASSWORD
LIVEKIT_URL=wss://$LIVEKIT_DOMAIN
LIVEKIT_HTTP_URL=http://127.0.0.1:7880
LIVEKIT_API_KEY=$LIVEKIT_API_KEY
LIVEKIT_API_SECRET=$LIVEKIT_API_SECRET
RECORDINGS_DIR=$REC_DIR
PUBLIC_IP=$PUBLIC_IP
TURN_SECRET=$TURN_SECRET
ENV
chmod 600 "$ENV_FILE"
set -a; . "$ENV_FILE"; set +a
# ================================================================
log "2/9  MySQL 8.0"
apt-get install -y mysql-server
systemctl enable --now mysql
mysql --protocol=socket -uroot <<SQL
CREATE DATABASE IF NOT EXISTS meet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'meet'@'127.0.0.1' IDENTIFIED BY '$DB_PASSWORD';
CREATE USER IF NOT EXISTS 'meet'@'localhost' IDENTIFIED BY '$DB_PASSWORD';
ALTER USER 'meet'@'127.0.0.1' IDENTIFIED BY '$DB_PASSWORD';
ALTER USER 'meet'@'localhost' IDENTIFIED BY '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON meet.* TO 'meet'@'127.0.0.1';
GRANT ALL PRIVILEGES ON meet.* TO 'meet'@'localhost';
FLUSH PRIVILEGES;
SQL

# ================================================================
log "3/9  Redis (بكلمة مرور + appendonly)"
apt-get install -y redis-server
sed -i "s/^# *requirepass .*/requirepass $REDIS_PASSWORD/; s/^requirepass .*/requirepass $REDIS_PASSWORD/" /etc/redis/redis.conf
grep -q "^requirepass " /etc/redis/redis.conf || echo "requirepass $REDIS_PASSWORD" >> /etc/redis/redis.conf
sed -i "s/^appendonly .*/appendonly yes/" /etc/redis/redis.conf
grep -q "^appendonly yes" /etc/redis/redis.conf || echo "appendonly yes" >> /etc/redis/redis.conf
systemctl enable redis-server
systemctl restart redis-server

# ================================================================
log "4/9  PHP $PHP_VER-FPM + إضافات + Composer"
add-apt-repository -y ppa:ondrej/php
apt-get update -y
apt-get install -y php${PHP_VER}-fpm php${PHP_VER}-mysql php${PHP_VER}-mbstring \
  php${PHP_VER}-bcmath php${PHP_VER}-curl php${PHP_VER}-xml php${PHP_VER}-zip php${PHP_VER}-gd
systemctl enable --now php${PHP_VER}-fpm
if ! command -v composer >/dev/null 2>&1; then
  php -r "copy('https://getcomposer.org/installer','/tmp/composer-setup.php');"
  php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
  rm -f /tmp/composer-setup.php
fi

# ================================================================
log "5/9  نشر ملفات التطبيق"
mkdir -p "$APP_DIR"
cp -a "$SRC_DIR/backend" "$APP_DIR/"
cp -a "$SRC_DIR/public"  "$APP_DIR/"
cp -a "$SRC_DIR/db"      "$APP_DIR/"
cp -a "$SRC_DIR/composer.json" "$APP_DIR/"
[ -f "$SRC_DIR/composer.lock" ] && cp -a "$SRC_DIR/composer.lock" "$APP_DIR/" || true
cd "$APP_DIR"
COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader --no-interaction
chown -R www-data:www-data "$APP_DIR" "$REC_DIR"

# ================================================================
log "6/9  استيراد المخطط + الهجرة + إنشاء الأدمن"
mysql -uroot meet < "$APP_DIR/db/schema.sql"
mysql -uroot meet < "$APP_DIR/db/migrations/002_quality_duration.sql"
ADMIN_HASH="$(php -r 'echo password_hash($argv[1], PASSWORD_BCRYPT);' "$ADMIN_PASSWORD")"
mysql -uroot meet <<SQL
INSERT INTO users (email,password_hash,name,role)
VALUES ('$ADMIN_EMAIL','$ADMIN_HASH','Admin','admin')
ON DUPLICATE KEY UPDATE role='admin';
INSERT INTO nodes (name,host,ssh_user,ssh_port,region,is_main,status,last_seen)
VALUES ('السيرفر الأساسي','$PUBLIC_IP','root',22,'main',1,'online',NOW())
ON DUPLICATE KEY UPDATE is_main=1,status='online',last_seen=NOW();
SQL
# ================================================================
log "7/9  LiveKit server $LIVEKIT_VERSION (binary + systemd)"
if [ ! -x /usr/local/bin/livekit-server ] || ! livekit-server --version 2>/dev/null | grep -q "$LIVEKIT_VERSION"; then
  TARBALL="livekit_${LIVEKIT_VERSION}_linux_amd64.tar.gz"
  curl -fsSL -o "/tmp/$TARBALL" \
    "https://github.com/livekit/livekit/releases/download/v${LIVEKIT_VERSION}/${TARBALL}"
  tar -xzf "/tmp/$TARBALL" -C /tmp
  install -m 0755 /tmp/livekit-server /usr/local/bin/livekit-server
  rm -f "/tmp/$TARBALL"
fi
mkdir -p /etc/livekit
envsubst < "$SRC_DIR/config/livekit.yaml.tmpl" > /etc/livekit/livekit.yaml
cat > /etc/systemd/system/livekit.service <<UNIT
[Unit]
Description=LiveKit Server
After=network.target redis-server.service
Wants=redis-server.service
[Service]
ExecStart=/usr/local/bin/livekit-server --config /etc/livekit/livekit.yaml
Restart=always
RestartSec=2
LimitNOFILE=1048576
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable livekit
systemctl restart livekit

# ================================================================
log "8/9  coturn"
apt-get install -y coturn
sed -i 's/^#TURNSERVER_ENABLED=1/TURNSERVER_ENABLED=1/' /etc/default/coturn 2>/dev/null || true
grep -q '^TURNSERVER_ENABLED=1' /etc/default/coturn 2>/dev/null || echo 'TURNSERVER_ENABLED=1' >> /etc/default/coturn
envsubst < "$SRC_DIR/config/turnserver.conf.tmpl" > /etc/turnserver.conf
systemctl enable coturn
systemctl restart coturn || true

# ================================================================
log "9/9  nginx + TLS (Let's Encrypt) + جدار ناري"
apt-get install -y nginx certbot python3-certbot-nginx

# شهادة مبدئية ذاتية التوقيع كي يقلع nginx قبل certbot
SS=/etc/ssl/meet
mkdir -p "$SS"
if [ ! -f "$SS/fullchain.pem" ]; then
  openssl req -x509 -nodes -newkey rsa:2048 -days 3650 \
    -keyout "$SS/privkey.pem" -out "$SS/fullchain.pem" \
    -subj "/CN=$APP_DOMAIN" >/dev/null 2>&1
fi

mkdir -p /var/www/certbot
cat > /etc/nginx/sites-available/meet.conf <<NGINX
server {
    listen 80;
    server_name $APP_DOMAIN $LIVEKIT_DOMAIN;
    location /.well-known/acme-challenge/ { root /var/www/certbot; }
    location / { return 301 https://\$host\$request_uri; }
}
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $APP_DOMAIN;
    ssl_certificate     $SS/fullchain.pem;
    ssl_certificate_key $SS/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    root /var/www/meet/public;
    index index.html;
    client_max_body_size 20m;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    location / { try_files \$uri \$uri/ \$uri.html =404; }
    location /api/ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php${PHP_VER}-fpm.sock;
        fastcgi_param SCRIPT_FILENAME /var/www/meet/backend/api/index.php;
        fastcgi_param REQUEST_URI \$request_uri;
        fastcgi_read_timeout 120s;
    }
}
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $LIVEKIT_DOMAIN;
    ssl_certificate     $SS/fullchain.pem;
    ssl_certificate_key $SS/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    location / {
        proxy_pass http://127.0.0.1:7880;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 600s;
        proxy_send_timeout 600s;
    }
}
NGINX
ln -sf /etc/nginx/sites-available/meet.conf /etc/nginx/sites-enabled/meet.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl enable nginx && systemctl restart nginx

# شهادات حقيقية: جرّب النطاقين معًا ثم livekit وحده كخطة بديلة
if certbot certonly --webroot -w /var/www/certbot \
     -d "$APP_DOMAIN" -d "$LIVEKIT_DOMAIN" \
     --non-interactive --agree-tos -m "$ADMIN_EMAIL" 2>/tmp/cb.log; then
  LE="/etc/letsencrypt/live/$APP_DOMAIN"
elif certbot certonly --webroot -w /var/www/certbot \
     -d "$LIVEKIT_DOMAIN" \
     --non-interactive --agree-tos -m "$ADMIN_EMAIL" 2>>/tmp/cb.log; then
  LE="/etc/letsencrypt/live/$LIVEKIT_DOMAIN"
else
  LE=""
  echo "!! تعذّر إصدار شهادة Let's Encrypt — سيبقى nginx على الشهادة الذاتية. راجع /tmp/cb.log"
fi
if [ -n "$LE" ] && [ -f "$LE/fullchain.pem" ]; then
  sed -i "s#$SS/fullchain.pem#$LE/fullchain.pem#g; s#$SS/privkey.pem#$LE/privkey.pem#g" \
    /etc/nginx/sites-available/meet.conf
  nginx -t && systemctl reload nginx
fi

# جدار ناري
ufw allow 22/tcp; ufw allow 80/tcp; ufw allow 443/tcp
ufw allow 7881/tcp; ufw allow 50000:50200/udp
ufw allow 3478/tcp; ufw allow 3478/udp; ufw allow 5349/tcp
ufw allow 49152:49252/udp
ufw --force enable

# ================================================================
log "تحقّق نهائي"
sleep 3
echo "--- services ---"
for s in mysql redis-server php${PHP_VER}-fpm livekit coturn nginx; do
  printf '%-18s %s\n' "$s" "$(systemctl is-active $s 2>/dev/null)"
done
echo "--- ports ---"
ss -ltnp 2>/dev/null | grep -E ':(80|443|3306|6379|7880|7881) ' || true
echo "--- livekit http ---"
curl -fsS http://127.0.0.1:7880/ -o /dev/null -w 'livekit_http=%{http_code}\n' || echo 'livekit down'
echo "--- api me (متوقّع 401) ---"
curl -fsS -k https://127.0.0.1/api/auth/me -H "Host: $APP_DOMAIN" -o /dev/null -w 'api=%{http_code}\n' || true
echo
echo "================= تم ================="
echo "الموقع:   https://$APP_DOMAIN"
echo "LiveKit:  wss://$LIVEKIT_DOMAIN"
echo "أدمن:     $ADMIN_EMAIL / (كلمة المرور التي مُرِّرت)"
echo "ملاحظة: التسجيل (Egress) يتطلّب عامل تسجيل منفصل (chromium+gstreamer) — غير مُفعّل في هذا التنصيب الأصلي."
