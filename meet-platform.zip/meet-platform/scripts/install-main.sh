#!/usr/bin/env bash
# ================================================================
#  install-main.sh — تثبيت السيرفر الأساسي (اللوحة + DB + نود LiveKit)
#  شغّله على السيرفر الأساسي بصلاحية root:  sudo bash scripts/install-main.sh
# ================================================================
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
echo "==> مجلد المشروع: $ROOT"

# ---- 1) أدوات أساسية ----
if ! command -v docker >/dev/null 2>&1; then
  echo "==> تثبيت Docker..."
  curl -fsSL https://get.docker.com | sh
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "==> تثبيت إضافة docker compose..."
  apt-get update -y && apt-get install -y docker-compose-plugin || true
fi
command -v openssl >/dev/null 2>&1 || { apt-get update -y && apt-get install -y openssl; }
command -v gettext-base >/dev/null 2>&1 || apt-get install -y gettext-base || true  # envsubst

# ---- 2) الأسئلة ----
read -rp "الدومين الأساسي للّوحة (مثال meet.example.com): " APP_DOMAIN
read -rp "دومين LiveKit (مثال livekit.example.com): " LIVEKIT_DOMAIN
read -rp "بريد الأدمن (لإنشاء أول حساب + شهادات TLS): " ADMIN_EMAIL
read -rp "عنوان IP العام لهذا السيرفر: " PUBLIC_IP
read -rsp "كلمة مرور الأدمن (اتركها فارغة لتوليد عشوائية): " ADMIN_PASSWORD; echo

rand() { openssl rand -hex "${1:-16}"; }

# ---- 3) توليد .env ----
if [ -f .env ]; then
  echo "==> .env موجود — سيُعاد استخدامه."
else
  echo "==> توليد .env بأسرار عشوائية..."
  cat > .env <<EOF
APP_DOMAIN=${APP_DOMAIN}
LIVEKIT_DOMAIN=${LIVEKIT_DOMAIN}
ADMIN_EMAIL=${ADMIN_EMAIL}
APP_URL=https://${APP_DOMAIN}
APP_ENV=production
JWT_SECRET=$(rand 32)
JWT_TTL=604800
DB_HOST=mysql
DB_PORT=3306
DB_NAME=meet
DB_USER=meet
DB_PASSWORD=$(rand 16)
DB_ROOT_PASSWORD=$(rand 16)
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=$(rand 16)
LIVEKIT_URL=wss://${LIVEKIT_DOMAIN}
LIVEKIT_HTTP_URL=http://livekit:7880
LIVEKIT_API_KEY=API$(rand 6)
LIVEKIT_API_SECRET=$(rand 32)
RECORDINGS_DIR=/recordings
PUBLIC_IP=${PUBLIC_IP}
TURN_SECRET=$(rand 24)
EOF
fi

# حمّل المتغيّرات للاستخدام في envsubst
set -a; . ./.env; set +a

# ---- 4) توليد ملفات الإعداد من القوالب ----
echo "==> توليد ملفات الإعداد (envsubst)..."
mkdir -p data/certbot/conf data/certbot/www recordings
envsubst < config/livekit.yaml.tmpl     > config/livekit.yaml
envsubst < config/egress.yaml.tmpl      > config/egress.yaml
envsubst < config/turnserver.conf.tmpl  > config/turnserver.conf
envsubst '${APP_DOMAIN} ${LIVEKIT_DOMAIN}' < nginx/default.conf.tmpl > nginx/default.conf

# ---- 5) شهادة TLS مؤقتة ذاتية التوقيع (كي يقلع nginx قبل ACME) ----
CERT_DIR="data/certbot/conf/live/${APP_DOMAIN}"
if [ ! -f "${CERT_DIR}/fullchain.pem" ]; then
  echo "==> توليد شهادة مؤقتة ذاتية التوقيع..."
  mkdir -p "$CERT_DIR"
  openssl req -x509 -nodes -newkey rsa:2048 -days 1 \
    -keyout "${CERT_DIR}/privkey.pem" -out "${CERT_DIR}/fullchain.pem" \
    -subj "/CN=${APP_DOMAIN}" >/dev/null 2>&1
fi

# ---- 6) تشغيل الستاك ----
echo "==> بناء وتشغيل الحاويات..."
docker compose up -d --build

echo "==> انتظار جاهزية قاعدة البيانات..."
for i in $(seq 1 30); do
  if docker compose exec -T mysql mysqladmin ping -h localhost -p"${DB_ROOT_PASSWORD}" >/dev/null 2>&1; then break; fi
  sleep 2
done

# ---- 7) تثبيت اعتماديات PHP + إنشاء الأدمن ----
echo "==> composer install..."
docker compose exec -T php composer install --no-dev --optimize-autoloader --working-dir=/var/www || \
  docker compose run --rm php composer install --no-dev --optimize-autoloader --working-dir=/var/www

echo "==> إنشاء أول حساب أدمن..."
docker compose exec -T -e ADMIN_PASSWORD="${ADMIN_PASSWORD}" php php /var/www/backend/scripts/seed-admin.php

# ---- 8) تسجيل السيرفر الأساسي كنود في قاعدة البيانات ----
echo "==> تسجيل السيرفر الأساسي كنود..."
docker compose exec -T mysql mysql -u root -p"${DB_ROOT_PASSWORD}" "${DB_NAME}" <<SQL || true
INSERT INTO nodes (name, host, ssh_user, ssh_port, region, is_main, status)
VALUES ('السيرفر الأساسي', '${PUBLIC_IP}', 'root', 22, 'main', 1, 'online')
ON DUPLICATE KEY UPDATE is_main = 1, status = 'online';
SQL

# ---- 9) شهادات Let's Encrypt الحقيقية ----
echo "==> محاولة الحصول على شهادة Let's Encrypt..."
docker run --rm \
  -v "${ROOT}/data/certbot/conf:/etc/letsencrypt" \
  -v "${ROOT}/data/certbot/www:/var/www/certbot" \
  certbot/certbot certonly --webroot -w /var/www/certbot \
  -d "${APP_DOMAIN}" -d "${LIVEKIT_DOMAIN}" \
  --email "${ADMIN_EMAIL}" --agree-tos --no-eff-email --non-interactive \
  && docker compose exec -T nginx nginx -s reload \
  || echo "!! تعذّر إصدار شهادة Let's Encrypt الآن — تحقّق من DNS ثم أعد المحاولة. الموقع يعمل بشهادة مؤقتة."

echo ""
echo "================================================================"
echo "  ✓ اكتمل التثبيت"
echo "  اللوحة:   https://${APP_DOMAIN}"
echo "  LiveKit:  wss://${LIVEKIT_DOMAIN}"
echo "  الأدمن:   ${ADMIN_EMAIL}"
echo "================================================================"
