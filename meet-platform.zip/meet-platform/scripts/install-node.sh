#!/usr/bin/env bash
# ================================================================
#  install-node.sh — تنصيب نود ميديا إضافية (LiveKit + coturn) أصليًا
#  يُرفع ويُشغّل عبر SSH من لوحة الأدمن (POST /nodes/:id/provision)
#  يعتمد على متغيّرات بيئة تُصدَّر في أول السكربت من الباك-إند:
#    MAIN_IP REDIS_PORT REDIS_PASSWORD LIVEKIT_API_KEY LIVEKIT_API_SECRET
#    TURN_SECRET APP_DOMAIN NODE_PUBLIC_IP
#  النود تنضمّ لنفس Redis الخاص بالسيرفر الأساسي ⇒ عنقود LiveKit واحد
#  يوزّع الغرف تلقائيًا على أفرغ نود.
# ================================================================
set -euo pipefail

# ---- قيم افتراضية/تحقّق من المتغيّرات ----
MAIN_IP="${MAIN_IP:?MAIN_IP مطلوب}"
REDIS_PORT="${REDIS_PORT:-6379}"
REDIS_PASSWORD="${REDIS_PASSWORD:?REDIS_PASSWORD مطلوب}"
LIVEKIT_API_KEY="${LIVEKIT_API_KEY:?LIVEKIT_API_KEY مطلوب}"
LIVEKIT_API_SECRET="${LIVEKIT_API_SECRET:?LIVEKIT_API_SECRET مطلوب}"
TURN_SECRET="${TURN_SECRET:-}"
APP_DOMAIN="${APP_DOMAIN:-}"
NODE_PUBLIC_IP="${NODE_PUBLIC_IP:-}"
LIVEKIT_VERSION="1.13.7"

export DEBIAN_FRONTEND=noninteractive
log(){ printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }

# ================================================================
log "1/6  حِزم أساسية"
apt-get update -y
apt-get install -y curl wget ca-certificates ufw jq openssl

# ================================================================
log "2/6  تنزيل/تركيب LiveKit server $LIVEKIT_VERSION"
PUSHED=/tmp/livekit-server.push
if [ -s "$PUSHED" ]; then
  # ثنائي مدفوع من الأساسي عبر SFTP ⇒ ركّبه مباشرةً (install يستبدل بأمان حتى لو كان قيد التشغيل)
  echo "    تركيب الثنائي المدفوع من السيرفر الأساسي"
  systemctl stop livekit 2>/dev/null || true
  install -m 0755 "$PUSHED" /usr/local/bin/livekit-server
  rm -f "$PUSHED"
elif [ ! -x /usr/local/bin/livekit-server ] || ! livekit-server --version 2>/dev/null | grep -q "$LIVEKIT_VERSION"; then
  TARBALL="livekit_${LIVEKIT_VERSION}_linux_amd64.tar.gz"
  BASE="https://github.com/livekit/livekit/releases/download/v${LIVEKIT_VERSION}"
  # مصادر متعددة: GitHub مباشر ثم مرايا CDN لتفادي أخطاء 500 العابرة من GitHub
  MIRRORS=(
    "$BASE/$TARBALL"
    "https://ghproxy.net/$BASE/$TARBALL"
    "https://mirror.ghproxy.com/$BASE/$TARBALL"
  )
  ok=0
  for url in "${MIRRORS[@]}"; do
    echo "    محاولة التنزيل من: $url"
    if curl -fL --retry 6 --retry-all-errors --retry-delay 5 \
            --connect-timeout 30 --max-time 300 -o "/tmp/$TARBALL" "$url"; then
      if tar -tzf "/tmp/$TARBALL" >/dev/null 2>&1; then ok=1; break; fi
    fi
    rm -f "/tmp/$TARBALL"; sleep 3
  done
  if [ "$ok" -eq 1 ]; then
    systemctl stop livekit 2>/dev/null || true
    tar -xzf "/tmp/$TARBALL" -C /tmp
    install -m 0755 /tmp/livekit-server /usr/local/bin/livekit-server
    rm -f "/tmp/$TARBALL"
  else
    # خطة بديلة نهائية: المثبّت الرسمي (يثبّت أحدث إصدار متوافق)
    echo "    تعذّر التنزيل المباشر — التحويل للمثبّت الرسمي"
    curl -sSL https://get.livekit.io | bash
  fi
fi
command -v livekit-server >/dev/null 2>&1 || { echo "!! فشل تثبيت LiveKit server"; exit 1; }

# ================================================================
log "3/6  إعداد LiveKit (redis الأساسي = نفس العنقود)"
mkdir -p /etc/livekit
cat > /etc/livekit/livekit.yaml <<YAML
port: 7880
bind_addresses:
  - ""

rtc:
  tcp_port: 7881
  port_range_start: 50000
  port_range_end: 50200
  use_external_ip: true

# Redis الخاص بالسيرفر الأساسي ⇒ عنقود واحد وتوزيع تلقائي للغرف
redis:
  address: ${MAIN_IP}:${REDIS_PORT}
  password: ${REDIS_PASSWORD}

keys:
  ${LIVEKIT_API_KEY}: ${LIVEKIT_API_SECRET}

turn:
  enabled: false

# توزيع الغرف عشوائيًا بين النودز (مش حسب الحِمل فقط)
node_selector:
  kind: any
  sort_by: random

logging:
  level: info
  json: false
YAML

cat > /etc/systemd/system/livekit.service <<'UNIT'
[Unit]
Description=LiveKit Server (node)
After=network.target
[Service]
ExecStart=/usr/local/bin/livekit-server --config /etc/livekit/livekit.yaml
Restart=always
RestartSec=2
LimitNOFILE=1048576
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable livekit
systemctl restart livekit

# ================================================================
log "4/6  coturn (TURN/STUN)"
apt-get install -y coturn
sed -i 's/^#TURNSERVER_ENABLED=1/TURNSERVER_ENABLED=1/' /etc/default/coturn 2>/dev/null || true
grep -q '^TURNSERVER_ENABLED=1' /etc/default/coturn 2>/dev/null || echo 'TURNSERVER_ENABLED=1' >> /etc/default/coturn
EXT_IP="${NODE_PUBLIC_IP:-$(curl -fsS https://api.ipify.org 2>/dev/null || echo '')}"
cat > /etc/turnserver.conf <<CONF
listening-port=3478
tls-listening-port=5349
fingerprint
use-auth-secret
static-auth-secret=${TURN_SECRET}
realm=${APP_DOMAIN:-$EXT_IP}
min-port=49152
max-port=49252
external-ip=${EXT_IP}
no-cli
no-multicast-peers
stale-nonce=600
CONF
systemctl enable coturn
systemctl restart coturn || true

# ================================================================
log "5/6  الجدار الناري"
ufw allow 22/tcp || true
ufw allow 7881/tcp || true
ufw allow 50000:50200/udp || true
ufw allow 3478/tcp || true; ufw allow 3478/udp || true; ufw allow 5349/tcp || true
ufw allow 49152:49252/udp || true
ufw --force enable || true

# ================================================================
log "6/6  تحقّق نهائي"
sleep 3
for s in livekit coturn; do
  printf '%-14s %s\n' "$s" "$(systemctl is-active $s 2>/dev/null)"
done
curl -fsS http://127.0.0.1:7880/ -o /dev/null -w 'livekit_http=%{http_code}\n' || echo 'livekit down'
# اختبار وصول Redis الأساسي (منفذ)
(timeout 3 bash -c "cat < /dev/null > /dev/tcp/${MAIN_IP}/${REDIS_PORT}" 2>/dev/null \
  && echo "redis_reachable=yes") || echo "redis_reachable=no (تحقّق من فتح منفذ ${REDIS_PORT} على السيرفر الأساسي لهذه النود)"
echo "================= تمّت تهيئة النود ================="
