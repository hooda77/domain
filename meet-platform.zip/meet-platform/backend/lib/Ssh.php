<?php
namespace App;

use phpseclib3\Net\SSH2;
use phpseclib3\Net\SFTP;

/** تجهيز النودز عبر SSH باستخدام phpseclib */
class Ssh
{
    /**
     * الدخول على النود ورفع سكربت التثبيت وتشغيله.
     * كلمة المرور تُستخدم لهذه الجلسة فقط ولا تُخزَّن.
     *
     * @param array<string,string> $uploads  ملفات تُرفع قبل التشغيل: [مسار محلي => مسار بعيد]
     * @return array{exit:int, output:string}
     */
    public static function runScript(string $host, int $port, string $user, string $password, string $script, array $uploads = []): array
    {
        // ارفع الملفات الكبيرة (مثل ثنائي livekit) عبر SFTP لتفادي GitHub تمامًا
        if ($uploads) {
            $sftp = new SFTP($host, $port);
            $sftp->setTimeout(600);
            if (!$sftp->login($user, $password)) {
                throw new \RuntimeException('فشل تسجيل الدخول عبر SSH (تحقّق من البيانات)');
            }
            foreach ($uploads as $local => $remote) {
                if (!is_file($local)) continue;
                if (!$sftp->put($remote, $local, SFTP::SOURCE_LOCAL_FILE)) {
                    throw new \RuntimeException("فشل رفع الملف إلى النود: $remote");
                }
                $sftp->chmod(0755, $remote);
            }
        }

        $ssh = new SSH2($host, $port);
        $ssh->setTimeout(600);
        if (!$ssh->login($user, $password)) {
            throw new \RuntimeException('فشل تسجيل الدخول عبر SSH (تحقّق من البيانات)');
        }

        $remote = '/tmp/install-node.sh';
        $b64 = base64_encode($script);
        // ارفع السكربت بأمان عبر base64 لتفادي مشاكل الاقتباس
        $ssh->exec("printf '%s' " . escapeshellarg($b64) . " | base64 -d > $remote && chmod +x $remote");
        $output = $ssh->exec("bash $remote 2>&1");
        $exit   = $ssh->getExitStatus();

        return ['exit' => is_int($exit) ? $exit : 1, 'output' => (string) $output];
    }
}
