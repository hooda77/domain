<?php
namespace App;

/**
 * غلاف رقيق حول امتداد phpredis مع تدهور آمن.
 * إن غاب الامتداد أو تعذّر الاتصال، تعيد available() القيمة false
 * وتتحوّل طبقة المصادقة تلقائيًا إلى وضع JWT الاحتياطي (للتطوير المحلّي).
 */
class Redis
{
    private static $client = null;
    private static ?bool $ok = null;

    /** اتصال كسول مُفرد (singleton) */
    public static function client()
    {
        if (self::$ok !== null) return self::$client;
        self::$ok = false;
        if (!class_exists('\Redis')) return null;
        try {
            $r = new \Redis();
            $host = (string) env('REDIS_HOST', '127.0.0.1');
            $port = (int) env('REDIS_PORT', 6379);
            // اتصال بمهلة قصيرة كي لا يعلّق الطلب إن كان Redis ساقطًا
            if (!@$r->connect($host, $port, 1.0)) return null;
            $pass = (string) env('REDIS_PASSWORD', '');
            if ($pass !== '' && $pass !== 'change_me_redis') { @$r->auth($pass); }
            $db = (int) env('REDIS_DB', 0);
            if ($db) @$r->select($db);
            // فحص حيّ
            if (@$r->ping() === false) return null;
            self::$client = $r;
            self::$ok = true;
        } catch (\Throwable $e) {
            self::$client = null;
            self::$ok = false;
        }
        return self::$client;
    }

    public static function available(): bool
    {
        self::client();
        return self::$ok === true;
    }

    // ---- عمليات مبسّطة (تُرجع قيمًا آمنة عند غياب Redis) ----

    public static function get(string $key): ?string
    {
        $c = self::client(); if (!$c) return null;
        $v = @$c->get($key);
        return ($v === false) ? null : (string) $v;
    }

    public static function setex(string $key, int $ttl, string $val): void
    {
        $c = self::client(); if (!$c) return;
        @$c->setex($key, $ttl, $val);
    }

    public static function del(string $key): void
    {
        $c = self::client(); if (!$c) return;
        @$c->del($key);
    }

    public static function expire(string $key, int $ttl): void
    {
        $c = self::client(); if (!$c) return;
        @$c->expire($key, $ttl);
    }

    public static function sadd(string $key, string $member): void
    {
        $c = self::client(); if (!$c) return;
        @$c->sAdd($key, $member);
    }

    public static function srem(string $key, string $member): void
    {
        $c = self::client(); if (!$c) return;
        @$c->sRem($key, $member);
    }

    /** @return string[] */
    public static function smembers(string $key): array
    {
        $c = self::client(); if (!$c) return [];
        $m = @$c->sMembers($key);
        return is_array($m) ? $m : [];
    }
}
