<?php
namespace App;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

/** المصادقة: تجزئة كلمات المرور + جلسات خادمية في Redis (مع JWT احتياطي) */
class Auth
{
    const COOKIE = 'meet_sid';       // كوكي معرّف الجلسة (خادمي)
    const CSRF_COOKIE = 'meet_csrf'; // توكن CSRF (مقروء من JS)
    const LEGACY_COOKIE = 'meet_token';

    public static function hash(string $pw): string
    {
        return password_hash($pw, PASSWORD_BCRYPT);
    }

    public static function verify(string $pw, string $hash): bool
    {
        return password_verify($pw, $hash);
    }

    private static function ttl(): int
    {
        return (int) env('SESSION_TTL', env('JWT_TTL', 604800));
    }

    /**
     * أنشئ جلسة للمستخدم وأعِد قيمة الكوكي.
     * مع Redis: معرّف جلسة عشوائي مُخزَّن خادميًا (يمكن إبطاله).
     * بدون Redis (تطوير محلّي): يعود لـ JWT عديم الحالة.
     */
    public static function issue(array $user): string
    {
        if (Redis::available()) {
            $sid  = bin2hex(random_bytes(32));
            $csrf = bin2hex(random_bytes(16));
            $uid  = (int) $user['id'];
            $data = [
                'uid'       => $uid,
                'email'     => $user['email'],
                'name'      => $user['name'],
                'role'      => $user['role'],
                'csrf'      => $csrf,
                'ip'        => $_SERVER['REMOTE_ADDR'] ?? '',
                'ua'        => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200),
                'created'   => time(),
                'last_seen' => time(),
            ];
            Redis::setex('sess:' . $sid, self::ttl(), json_encode($data, JSON_UNESCAPED_UNICODE));
            Redis::sadd('usess:' . $uid, $sid);
            Redis::expire('usess:' . $uid, self::ttl());
            return $sid;
        }
        // احتياطي: JWT
        $now = time();
        return JWT::encode([
            'sub' => (int) $user['id'], 'email' => $user['email'], 'name' => $user['name'],
            'role' => $user['role'], 'csrf' => 'jwt', 'iat' => $now, 'exp' => $now + self::ttl(),
        ], (string) env('JWT_SECRET'), 'HS256');
    }

    public static function setCookie(string $value): void
    {
        $secure = env('APP_ENV', 'production') !== 'dev';
        $exp = time() + self::ttl();
        setcookie(self::COOKIE, $value, [
            'expires' => $exp, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => $secure,
        ]);
        // توكن CSRF مقروء من JS ليُرفَق كترويسة
        setcookie(self::CSRF_COOKIE, self::csrfFor($value), [
            'expires' => $exp, 'path' => '/', 'httponly' => false, 'samesite' => 'Lax', 'secure' => $secure,
        ]);
    }

    /** استخرج توكن CSRF لقيمة كوكي معطاة */
    private static function csrfFor(string $value): string
    {
        if (Redis::available()) {
            $raw = Redis::get('sess:' . $value);
            if ($raw) { $d = json_decode($raw, true); if (isset($d['csrf'])) return (string) $d['csrf']; }
            return '';
        }
        try { $d = (array) JWT::decode($value, new Key((string) env('JWT_SECRET'), 'HS256')); return (string) ($d['csrf'] ?? 'jwt'); }
        catch (\Throwable $e) { return 'jwt'; }
    }

    public static function clearCookie(): void
    {
        // دمّر الجلسة الخادمية إن وُجدت
        $sid = $_COOKIE[self::COOKIE] ?? null;
        if ($sid && Redis::available()) {
            $raw = Redis::get('sess:' . $sid);
            if ($raw) { $d = json_decode($raw, true); if (isset($d['uid'])) Redis::srem('usess:' . (int) $d['uid'], $sid); }
            Redis::del('sess:' . $sid);
        }
        foreach ([self::COOKIE, self::CSRF_COOKIE, self::LEGACY_COOKIE] as $c) {
            setcookie($c, '', ['expires' => time() - 3600, 'path' => '/', 'samesite' => 'Lax']);
        }
    }

    /** أبطِل كل جلسات المستخدم (تسجيل خروج من كل الأجهزة) — يُبقي الحالية اختياريًا */
    public static function revokeAll(int $uid, ?string $keepSid = null): int
    {
        if (!Redis::available()) return 0;
        $n = 0;
        foreach (Redis::smembers('usess:' . $uid) as $sid) {
            if ($keepSid !== null && $sid === $keepSid) continue;
            Redis::del('sess:' . $sid);
            Redis::srem('usess:' . $uid, $sid);
            $n++;
        }
        return $n;
    }

    /** حدّث حمولة الهوية في كل جلسات المستخدم (بعد تعديل البروفايل) */
    public static function refreshIdentity(int $uid, array $fields): void
    {
        if (!Redis::available()) return;
        foreach (Redis::smembers('usess:' . $uid) as $sid) {
            $raw = Redis::get('sess:' . $sid);
            if (!$raw) continue;
            $d = json_decode($raw, true);
            if (!is_array($d)) continue;
            foreach ($fields as $k => $v) $d[$k] = $v;
            Redis::setex('sess:' . $sid, self::ttl(), json_encode($d, JSON_UNESCAPED_UNICODE));
        }
    }

    /** سرد جلسات المستخدم النشطة (للعرض في صفحة الأمان) */
    public static function listSessions(int $uid, ?string $currentSid = null): array
    {
        if (!Redis::available()) return [];
        $out = [];
        foreach (Redis::smembers('usess:' . $uid) as $sid) {
            $raw = Redis::get('sess:' . $sid);
            if (!$raw) { Redis::srem('usess:' . $uid, $sid); continue; }
            $d = json_decode($raw, true);
            if (!is_array($d)) continue;
            $out[] = [
                'id'       => substr($sid, 0, 12),
                'sid'      => $sid,
                'ip'       => $d['ip'] ?? '',
                'ua'       => $d['ua'] ?? '',
                'created'  => $d['created'] ?? null,
                'lastSeen' => $d['last_seen'] ?? null,
                'current'  => ($currentSid !== null && $sid === $currentSid),
            ];
        }
        usort($out, fn($a, $b) => ($b['lastSeen'] ?? 0) <=> ($a['lastSeen'] ?? 0));
        return $out;
    }

    /** المستخدم الحالي من كوكي الجلسة (Redis) أو JWT احتياطي، أو null */
    public static function user(): ?array
    {
        $val = $_COOKIE[self::COOKIE] ?? $_COOKIE[self::LEGACY_COOKIE] ?? null;
        if (!$val) {
            $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
            if (preg_match('/Bearer\s+(.+)/i', $h, $m)) $val = $m[1];
        }
        if (!$val) return null;

        // جلسة Redis خادمية
        if (Redis::available()) {
            $raw = Redis::get('sess:' . $val);
            if ($raw) {
                $d = json_decode($raw, true);
                if (is_array($d) && isset($d['uid'])) {
                    // انتهاء منزلق + آخر ظهور
                    $d['last_seen'] = time();
                    Redis::setex('sess:' . $val, self::ttl(), json_encode($d, JSON_UNESCAPED_UNICODE));
                    Redis::expire('usess:' . (int) $d['uid'], self::ttl());
                    return [
                        'sub' => (int) $d['uid'], 'email' => $d['email'] ?? '', 'name' => $d['name'] ?? '',
                        'role' => $d['role'] ?? 'user', 'sid' => $val, 'csrf' => $d['csrf'] ?? '',
                    ];
                }
            }
        }
        // احتياطي: JWT
        try {
            $d = (array) JWT::decode($val, new Key((string) env('JWT_SECRET'), 'HS256'));
            $d['sid'] = null;
            return $d;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** تحقّق CSRF لطلب مُغيِّر للحالة (double-submit) */
    public static function checkCsrf(array $user): void
    {
        $expected = (string) ($user['csrf'] ?? '');
        if ($expected === '' || $expected === 'jwt') return; // وضع JWT الاحتياطي بلا CSRF
        $got = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals($expected, (string) $got)) {
            Response::error('توكن CSRF غير صالح', 403);
        }
    }

    public static function require(): array
    {
        $u = self::user();
        if (!$u) Response::error('غير مصرّح', 401);
        return $u;
    }

    public static function requireAdmin(): array
    {
        $u = self::require();
        if (($u['role'] ?? '') !== 'admin') Response::error('صلاحيات غير كافية', 403);
        return $u;
    }

    // ============================================================
    //  مصادقة المطوّرين عبر api_token (خادم-لخادم)
    // ============================================================
    const API_PREFIX = 'mk_live_';

    /** ولّد مفتاح API جديدًا بصيغة يمكن تمييزها عن الـ JWT */
    public static function newApiToken(): string
    {
        return self::API_PREFIX . bin2hex(random_bytes(24)); // 8 + 48 = 56 حرفًا
    }

    /** استخرج الـ Bearer من ترويسة Authorization (أو null) */
    private static function bearer(): ?string
    {
        $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if ($h === '' && function_exists('apache_request_headers')) {
            $hdrs = apache_request_headers();
            $h = $hdrs['Authorization'] ?? $hdrs['authorization'] ?? '';
        }
        return preg_match('/Bearer\s+(.+)/i', (string) $h, $m) ? trim($m[1]) : null;
    }

    /**
     * المطوّر الحالي من api_token في ترويسة Authorization: Bearer، أو null.
     * الشكل: صفّ المستخدم من قاعدة البيانات (id/email/name/role) مع sub للتوافق.
     */
    public static function apiUser(): ?array
    {
        $tok = self::bearer();
        if (!$tok || strncmp($tok, self::API_PREFIX, strlen(self::API_PREFIX)) !== 0) return null;
        $u = Db::one('SELECT id, email, name, role FROM users WHERE api_token = ?', [$tok]);
        if (!$u) return null;
        $u['sub'] = (int) $u['id'];
        return $u;
    }

    public static function requireApi(): array
    {
        $u = self::apiUser();
        if (!$u) Response::error('مفتاح API غير صالح — أرسله في ترويسة Authorization: Bearer <api_token>', 401);
        return $u;
    }

    // ============================================================
    //  التحقّق من توكن انضمام LiveKit (لإدارة الغرفة من صفحة التضمين)
    // ============================================================
    /**
     * افحص توكن انضمام LiveKit موقّعًا بـ LIVEKIT_API_SECRET وأعِد حمولته المبسّطة،
     * أو null إن كان غير صالح/منتهيًا. لا يمسّ قاعدة البيانات — التحقّق تشفيري فقط،
     * فالتوكن غير قابل للتزوير ما دام السرّ على السيرفر.
     */
    public static function verifyLivekitToken(?string $tok = null): ?array
    {
        $tok = $tok ?? self::bearer();
        if (!$tok) return null;
        try {
            $d = (array) JWT::decode($tok, new Key((string) env('LIVEKIT_API_SECRET'), 'HS256'));
        } catch (\Throwable $e) {
            return null;
        }
        $video = isset($d['video']) ? (array) $d['video'] : [];
        $meta  = [];
        if (!empty($d['metadata'])) {
            $m = json_decode((string) $d['metadata'], true);
            if (is_array($m)) $meta = $m;
        }
        return [
            'identity' => (string) ($d['sub'] ?? ''),
            'name'     => (string) ($d['name'] ?? ''),
            'room'     => (string) ($video['room'] ?? ''),
            'role'     => (string) ($meta['role'] ?? 'user'),
            'guest'    => !empty($meta['guest']),
            'meta'     => $meta,
        ];
    }
}
