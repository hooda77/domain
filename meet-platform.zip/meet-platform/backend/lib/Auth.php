<?php
namespace App;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

/** المصادقة: تجزئة كلمات المرور + JWT في httpOnly cookie */
class Auth
{
    const COOKIE = 'meet_token';

    public static function hash(string $pw): string
    {
        return password_hash($pw, PASSWORD_BCRYPT);
    }

    public static function verify(string $pw, string $hash): bool
    {
        return password_verify($pw, $hash);
    }

    public static function issue(array $user): string
    {
        $ttl = (int) env('JWT_TTL', 604800);
        $now = time();
        $payload = [
            'sub'   => (int) $user['id'],
            'email' => $user['email'],
            'name'  => $user['name'],
            'role'  => $user['role'],
            'iat'   => $now,
            'exp'   => $now + $ttl,
        ];
        return JWT::encode($payload, (string) env('JWT_SECRET'), 'HS256');
    }

    public static function setCookie(string $token): void
    {
        $secure = env('APP_ENV', 'production') !== 'dev';
        setcookie(self::COOKIE, $token, [
            'expires'  => time() + (int) env('JWT_TTL', 604800),
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure'   => $secure,
        ]);
    }

    public static function clearCookie(): void
    {
        setcookie(self::COOKIE, '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
    }

    /** المستخدم الحالي من الكوكي أو ترويسة Bearer، أو null */
    public static function user(): ?array
    {
        $token = $_COOKIE[self::COOKIE] ?? null;
        if (!$token) {
            $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
            if (preg_match('/Bearer\s+(.+)/i', $h, $m)) $token = $m[1];
        }
        if (!$token) return null;
        try {
            $decoded = JWT::decode($token, new Key((string) env('JWT_SECRET'), 'HS256'));
            return (array) $decoded;
        } catch (\Throwable $e) {
            return null;
        }
    }

    public static function require(): array
    {
        $u = self::user();
        if (!$u) Response::error('غير مصرّح', 401);
        return $u;
    }

    public static function requireAdmin(): array
    {
        $u = self::require();
        if (($u['role'] ?? '') !== 'admin') Response::error('صلاحيات غير كافية', 403);
        return $u;
    }
}
