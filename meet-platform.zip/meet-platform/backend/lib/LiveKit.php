<?php
namespace App;

use Firebase\JWT\JWT;

/**
 * عميل LiveKit مكتفٍ ذاتيًا:
 *  - يوقّع توكنات الانضمام + توكنات الإدارة بـ HS256
 *  - يستدعي واجهات Twirp (RoomService / Egress) مباشرة عبر cURL
 * الحقول بصيغة camelCase حسب تحويل protobuf-JSON.
 */
class LiveKit
{
    /** توكن انضمام لمشارك */
    public static function joinToken(string $room, string $identity, string $name, string $metadata = ''): string
    {
        $video = [
            'room'           => $room,
            'roomJoin'       => true,
            'canPublish'     => true,
            'canSubscribe'   => true,
            'canPublishData' => true,
        ];
        $claims = ['video' => $video, 'name' => $name, 'sub' => $identity];
        if ($metadata !== '') $claims['metadata'] = $metadata;
        return self::sign($claims, 6 * 3600);
    }

    private static function sign(array $claims, int $ttl): string
    {
        $now = time();
        $payload = array_merge([
            'iss' => (string) env('LIVEKIT_API_KEY'),
            'nbf' => $now - 10,
            'iat' => $now,
            'exp' => $now + $ttl,
        ], $claims);
        return JWT::encode($payload, (string) env('LIVEKIT_API_SECRET'), 'HS256');
    }

    private static function adminToken(string $room = ''): string
    {
        $video = ['roomAdmin' => true, 'roomList' => true, 'roomCreate' => true, 'roomRecord' => true];
        if ($room !== '') $video['room'] = $room;
        return self::sign(['video' => $video, 'sub' => 'server'], 600);
    }

    private static function twirp(string $service, string $method, array $body, string $room = ''): array
    {
        $base = rtrim((string) env('LIVEKIT_HTTP_URL', 'http://livekit:7880'), '/');
        $url  = "$base/twirp/livekit.$service/$method";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . self::adminToken($room),
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($res === false) throw new \RuntimeException("تعذّر الاتصال بـ LiveKit: $err");
        if ($code >= 400)   throw new \RuntimeException("خطأ LiveKit ($code): $res");
        $data = json_decode((string) $res, true);
        return is_array($data) ? $data : [];
    }

    // ---- RoomService ----
    /**
     * أنشئ الغرفة صراحةً في LiveKit كي تبقى حيّة طوال المدة حتى لو خلت من المشاركين.
     * emptyTimeout: ثوانٍ قبل الإغلاق إن لم ينضمّ أحد أصلًا.
     * departureTimeout: ثوانٍ قبل الإغلاق بعد مغادرة آخر مشارك.
     */
    public static function createRoom(string $room, int $emptyTimeout = 300, int $departureTimeout = 0): void
    {
        $body = ['name' => $room, 'emptyTimeout' => max(1, $emptyTimeout)];
        if ($departureTimeout > 0) $body['departureTimeout'] = $departureTimeout;
        self::twirp('RoomService', 'CreateRoom', $body, $room);
    }

    public static function listParticipants(string $room): array
    {
        return self::twirp('RoomService', 'ListParticipants', ['room' => $room], $room)['participants'] ?? [];
    }

    public static function removeParticipant(string $room, string $identity): void
    {
        self::twirp('RoomService', 'RemoveParticipant', ['room' => $room, 'identity' => $identity], $room);
    }

    public static function mute(string $room, string $identity, string $trackSid, bool $muted): void
    {
        self::twirp('RoomService', 'MutePublishedTrack',
            ['room' => $room, 'identity' => $identity, 'trackSid' => $trackSid, 'muted' => $muted], $room);
    }

    public static function updateRoomMetadata(string $room, string $metadata): void
    {
        self::twirp('RoomService', 'UpdateRoomMetadata', ['room' => $room, 'metadata' => $metadata], $room);
    }

    /** تحديث metadata مشارك (نستخدمه لترقية/تنزيل صلاحية الإشراف حيًّا) */
    public static function updateParticipant(string $room, string $identity, string $metadata): void
    {
        self::twirp('RoomService', 'UpdateParticipant',
            ['room' => $room, 'identity' => $identity, 'metadata' => $metadata], $room);
    }

    /** حذف الغرفة من LiveKit (يفصل كل المشاركين فورًا) */
    public static function deleteRoom(string $room): void
    {
        self::twirp('RoomService', 'DeleteRoom', ['room' => $room], $room);
    }
}
