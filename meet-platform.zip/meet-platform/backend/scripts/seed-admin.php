<?php
// ================================================================
//  seed-admin.php — إنشاء أول حساب أدمن من ADMIN_EMAIL
//  يُستدعى من install-main.sh بعد تشغيل الستاك.
//  الاستخدام: php backend/scripts/seed-admin.php [كلمة_المرور]
// ================================================================
require __DIR__ . '/../config.php';

use App\Db;
use App\Auth;

$email = (string) env('ADMIN_EMAIL', '');
$name  = 'المدير';
$password = $argv[1] ?? getenv('ADMIN_PASSWORD') ?: '';

if ($email === '') { fwrite(STDERR, "ADMIN_EMAIL غير مضبوط في .env\n"); exit(1); }
if ($password === '') {
    // ولّد باسورد عشوائي واطبعه مرة واحدة
    $password = bin2hex(random_bytes(6));
    $generated = true;
}

$existing = Db::one('SELECT id FROM users WHERE email = ?', [$email]);
if ($existing) {
    // رقِّه إلى أدمن إن لم يكن كذلك
    Db::q('UPDATE users SET role = "admin" WHERE id = ?', [$existing['id']]);
    echo "الحساب موجود بالفعل ({$email}) — تمت ترقيته إلى أدمن.\n";
    exit(0);
}

Db::insert(
    'INSERT INTO users (email, password_hash, name, role) VALUES (?, ?, ?, "admin")',
    [$email, Auth::hash($password), $name]
);

echo "تم إنشاء الأدمن: {$email}\n";
if (!empty($generated)) {
    echo "كلمة المرور المؤقتة: {$password}\n";
    echo "غيّرها بعد أول تسجيل دخول.\n";
}
