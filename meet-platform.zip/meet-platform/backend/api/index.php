<?php
// ================================================================
//  Front controller — كل مسارات /api تمرّ من هنا
// ================================================================
declare(strict_types=1);

require __DIR__ . '/../config.php';

use App\Db;
use App\Auth;
use App\LiveKit;
use App\Ssh;
use App\Response;

// --- تحديد المسار والطريقة ---
$path   = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$segs   = array_values(array_filter(explode('/', $path), fn($s) => $s !== ''));
if (($segs[0] ?? '') === 'api') array_shift($segs);   // أزل بادئة api

// معالجة أخطاء موحّدة
set_exception_handler(function (\Throwable $e) {
    $code = $e instanceof \InvalidArgumentException ? 400 : 500;
    Response::error($e->getMessage(), $code);
});

// ---------- دوال مساعدة ----------
function room_by_code(string $code): array
{
    $room = Db::one('SELECT * FROM rooms WHERE room_code = ?', [$code]);
    if (!$room) Response::error('الغرفة غير موجودة', 404);
    $s = Db::one('SELECT * FROM room_settings WHERE room_id = ?', [$room['id']]);
    if (!$s) {
        Db::q('INSERT INTO room_settings (room_id) VALUES (?)', [$room['id']]);
        $s = ['lock_camera' => 0, 'lock_mic' => 0, 'lock_chat' => 0, 'lock_screenshare' => 0, 'lock_board' => 0];
    }
    $room['settings'] = $s;
    return $room;
}

/** هل المستخدم مشرف مُعيَّن في هذه الغرفة؟ */
function is_cohost(int $userId, int $roomId): bool
{
    if ($userId <= 0) return false;
    try {
        return (bool) Db::one('SELECT 1 FROM room_cohosts WHERE room_id = ? AND user_id = ?', [$roomId, $userId]);
    } catch (\Throwable $e) {
        return false;
    }
}

/** هل المستخدم مشرف على الغرفة؟ أدمن المنصّة، أو صاحب الاجتماع، أو مشرف عيّنه الهوست. */
function is_moderator(array $user, array $room): bool
{
    $uid = (int) ($user['sub'] ?? $user['id'] ?? 0);
    return (($user['role'] ?? '') === 'admin')
        || ($uid > 0 && $uid === (int) ($room['host_user_id'] ?? -1))
        || is_cohost($uid, (int) $room['id']);
}

/** هل المستخدم صاحب الاجتماع أو أدمن المنصّة؟ (لصلاحيات التعيين/الحذف) */
function is_owner_or_admin(array $user, array $room): bool
{
    $uid = (int) ($user['sub'] ?? $user['id'] ?? 0);
    return (($user['role'] ?? '') === 'admin')
        || ($uid > 0 && $uid === (int) ($room['host_user_id'] ?? -1));
}

/** هويّات LiveKit لكل مشرفي الغرفة (الهوست + المشرفون المعيّنون) لإعفائهم من الكتم */
function moderator_identities(array $room): array
{
    $ids = ['u' . (int) $room['host_user_id']];
    try {
        foreach (Db::all('SELECT user_id FROM room_cohosts WHERE room_id = ?', [(int) $room['id']]) as $r) {
            $ids[] = 'u' . (int) $r['user_id'];
        }
    } catch (\Throwable $e) {}
    return array_values(array_unique($ids));
}

function require_mod(array $room): array
{
    $u = Auth::require();
    if (!is_moderator($u, $room)) Response::error('هذه العملية للمضيف فقط', 403);
    return $u;
}

function require_owner(array $room): array
{
    $u = Auth::require();
    if (!is_owner_or_admin($u, $room)) Response::error('هذه العملية لصاحب الاجتماع فقط', 403);
    return $u;
}

/**
 * طبّق أقفال الغرفة (من body بمفاتيح snake_case و/أو camelCase)، احفظها،
 * ادفعها لـ LiveKit metadata، واكتم المسارات المخالِفة لغير المشرفين.
 * $extraExempt: هويّات إضافية تُعفى من الكتم (مثل هويّة الضيف-المضيف في التضمين).
 * يعيد نصّ الـ metadata النهائي.
 */
function apply_room_settings(array $room, array $b, array $extraExempt = []): string
{
    $fields = ['lock_camera', 'lock_mic', 'lock_chat', 'lock_screenshare', 'lock_board'];
    $cur = $room['settings'];
    foreach ($fields as $f) {
        if (array_key_exists($f, $b)) $cur[$f] = $b[$f] ? 1 : 0;
    }
    $camel = ['lockCamera'=>'lock_camera','lockMic'=>'lock_mic','lockChat'=>'lock_chat','lockScreenshare'=>'lock_screenshare','lockBoard'=>'lock_board'];
    foreach ($camel as $ck => $sk) {
        if (array_key_exists($ck, $b)) $cur[$sk] = $b[$ck] ? 1 : 0;
    }
    Db::q('UPDATE room_settings SET lock_camera=?, lock_mic=?, lock_chat=?, lock_screenshare=?, lock_board=? WHERE room_id=?',
        [$cur['lock_camera'], $cur['lock_mic'], $cur['lock_chat'], $cur['lock_screenshare'], $cur['lock_board'] ?? 0, $room['id']]);
    $meta = room_metadata($cur);
    try { LiveKit::updateRoomMetadata($room['room_code'], $meta); } catch (\Throwable $e) {}
    try {
        $exempt = array_merge(moderator_identities($room), $extraExempt);
        foreach (LiveKit::listParticipants($room['room_code']) as $p) {
            if (in_array($p['identity'] ?? '', $exempt, true)) continue;
            foreach (($p['tracks'] ?? []) as $t) {
                $type = $t['type'] ?? '';
                $source = $t['source'] ?? '';
                $shouldMute = ($type === 'AUDIO' && $cur['lock_mic'])
                    || ($type === 'VIDEO' && $source === 'CAMERA' && $cur['lock_camera'])
                    || ($source === 'SCREEN_SHARE' && $cur['lock_screenshare']);
                if ($shouldMute) LiveKit::mute($room['room_code'], $p['identity'], $t['sid'], true);
            }
        }
    } catch (\Throwable $e) {}
    return $meta;
}

/** بناء metadata الغرفة (الأقفال) لإرسالها لـ LiveKit والعملاء */
function room_metadata(array $settings): string
{
    return json_encode([
        'lockCamera'      => (bool) $settings['lock_camera'],
        'lockMic'         => (bool) $settings['lock_mic'],
        'lockChat'        => (bool) $settings['lock_chat'],
        'lockScreenshare' => (bool) $settings['lock_screenshare'],
        'lockBoard'       => (bool) ($settings['lock_board'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
}

/** جودة الغرفة كما تُرسل للعميل */
function room_quality(array $room): array
{
    return [
        'maxHeight'  => (int) ($room['max_height'] ?? 360),
        'maxBitrate' => (int) ($room['max_bitrate_kbps'] ?? 800),
        'maxFps'     => (int) ($room['max_fps'] ?? 15),
    ];
}

/**
 * افرض سقف المشاركين على الغرفة (لقطة حدّ المضيف). المشرفون معفَون كي يدخل
 * المضيف دائمًا. مَن هو موجود أصلًا (إعادة انضمام) لا يُحتسَب مجددًا.
 * يرمي 403 إن اكتمل العدد. يعيد السقف (int) أو 0 = غير محدود.
 */
function enforce_participant_cap(array $room, string $identity, bool $isModerator): int
{
    $cap = $room['max_participants'] ?? null;
    if ($cap === null) return 0;
    $cap = (int) $cap;
    if ($cap <= 0) return 0;
    if ($isModerator) return $cap;   // المضيف/المشرف لا يُمنع
    try {
        $parts = LiveKit::listParticipants($room['room_code']);
        $already = false;
        foreach ($parts as $p) {
            if (($p['identity'] ?? '') === $identity) { $already = true; break; }
        }
        if (!$already && count($parts) >= $cap) {
            Response::error('اكتمل عدد المشاركين المسموح به في هذا الاجتماع', 403);
        }
    } catch (\Throwable $e) { /* تعذّر العدّ → لا نمنع؛ سقف LiveKit يبقى خط الدفاع */ }
    return $cap;
}

/** أغلق غرفة: أرشِفها للسجل + افصل الجميع من LiveKit */
function close_room(array $room): void
{
    archive_room($room);
}

/**
 * أرشفة الغرفة للسجل (idempotent): تُغلق صفوف الحضور المفتوحة، تُنشئ صفّ
 * meeting_sessions، تربط الحضور به، تعلّم الغرفة archived_at، ثم تفصل الجميع.
 * إن كانت الغرفة مؤرشفة سلفًا تعود فورًا (لا ازدواج).
 */
function archive_room(array $room): void
{
    if (!empty($room['archived_at'])) return;
    $code = (string) $room['room_code'];

    try {
        // 1) أغلق صفوف الحضور المفتوحة لهذه الغرفة
        Db::q(
            "UPDATE attendance SET left_at=NOW(),
               duration_seconds=GREATEST(0, TIMESTAMPDIFF(SECOND, joined_at, NOW()))
             WHERE room_code=? AND left_at IS NULL",
            [$code]
        );

        // 2) احسب المدّة والعدّ وأنشئ صفّ الجلسة في السجل
        $agg = Db::one(
            "SELECT COUNT(DISTINCT identity) AS cnt, MIN(joined_at) AS first_join
               FROM attendance WHERE room_code=?",
            [$code]
        ) ?: ['cnt' => 0, 'first_join' => null];

        $startedAt = $agg['first_join']
            ?: ($room['starts_at'] ?? $room['created_at'] ?? date('Y-m-d H:i:s'));
        $endedAt   = $room['ended_at'] ?: date('Y-m-d H:i:s');
        $dur       = max(0, strtotime($endedAt) - strtotime((string) $startedAt));

        $sid = Db::insert(
            "INSERT INTO meeting_sessions
               (room_code, name, host_user_id, started_at, ended_at, duration_seconds, participant_count)
             VALUES (?,?,?,?,?,?,?)",
            [
                $code,
                (string) ($room['name'] ?? $code),
                $room['host_user_id'] ?? null,
                $startedAt,
                $endedAt,
                $dur,
                (int) $agg['cnt'],
            ]
        );

        // 3) اربط صفوف حضور هذه الغرفة غير المربوطة بالجلسة
        Db::q("UPDATE attendance SET session_id=? WHERE room_code=? AND session_id IS NULL", [$sid, $code]);
    } catch (\Throwable $e) {}

    // 4) علّم الغرفة منتهية ومؤرشفة (لا تُحذف الآن — يحذفها الكرون بعد ساعة)
    try {
        Db::q("UPDATE rooms SET is_active=0, ended_at=COALESCE(ended_at, NOW()), archived_at=NOW() WHERE id=?", [$room['id']]);
    } catch (\Throwable $e) {}

    // 5) افصل كل المستخدمين وأنهِ بيانات الغرفة الحيّة
    try { LiveKit::deleteRoom($code); } catch (\Throwable $e) {}
}

/** إن تجاوزت الغرفة مدتها أغلقها تلقائيًا وأعِد true */
function enforce_expiry(array &$room): bool
{
    if ((int) ($room['is_active'] ?? 0) === 1
        && !empty($room['expires_at'])
        && strtotime((string) $room['expires_at']) <= time()) {
        close_room($room);
        $room['is_active'] = 0;
        return true;
    }
    return false;
}

/** كنس كل الغرف المنتهية (يُستدعى بشكل كسول عند الوصول للتطبيق) */
function sweep_expired(): void
{
    try {
        $rows = Db::all("SELECT * FROM rooms WHERE is_active=1 AND expires_at IS NOT NULL AND expires_at <= NOW()");
        foreach ($rows as $r) archive_room($r);
    } catch (\Throwable $e) {}
    // حذف صفّ الغرفة المؤرشفة بعد ساعة (السجل يبقى لأنه بلا FK للغرف)
    try {
        Db::q("DELETE FROM rooms WHERE archived_at IS NOT NULL AND archived_at <= (NOW() - INTERVAL 1 HOUR)");
    } catch (\Throwable $e) {}
}

/** ولّد رمز غرفة فريدًا بنمط xxx-xxxx-xxx */
function mk_gen_room_code(): string
{
    $alpha = 'abcdefghijkmnpqrstuvwxyz';
    do {
        $r = '';
        for ($i = 0; $i < 10; $i++) $r .= $alpha[random_int(0, strlen($alpha) - 1)];
        $code = substr($r, 0, 3) . '-' . substr($r, 3, 4) . '-' . substr($r, 7, 3);
    } while (Db::one('SELECT id FROM rooms WHERE room_code = ?', [$code]));
    return $code;
}

/**
 * أنشئ سجلّ غرفة لمضيف معيّن (يشترك فيه إنشاء المتصفّح وواجهة الـ API).
 * يتحقّق من الجودة/المدة مقابل القوائم المسموح بها، ويدعم الجدولة/الانتظار/كلمة المرور.
 * يعيد صفّ الوصف الجاهز للإخراج.
 */
function mk_create_room(int $hostUserId, array $b): array
{
    $name = trim((string) ($b['name'] ?? '')) ?: 'اجتماع';

    $resList = array_map(fn($x) => (int) $x['height'], settings_get('resolution_presets'));
    $bitList = array_map(fn($x) => (int) $x['kbps'],   settings_get('bitrate_presets'));
    $fpsList = array_map(fn($x) => (int) $x['fps'],    settings_get('fps_presets'));
    $durList = array_map(fn($x) => (int) $x['hours'],  settings_get('duration_presets'));

    $height  = (int) ($b['maxHeight']  ?? 0);
    $bitrate = (int) ($b['maxBitrate'] ?? 0);
    $fps     = (int) ($b['maxFps']     ?? 0);
    $hours   = (int) ($b['durationHours'] ?? 0);
    if (!in_array($height, $resList, true))  $height  = max($resList ?: [360]);
    if (!in_array($bitrate, $bitList, true)) $bitrate = $bitList ? max($bitList) : 800;
    if (!in_array($fps, $fpsList, true))     $fps     = $fpsList ? max($fpsList) : 15;
    if (!in_array($hours, $durList, true))   $hours   = $durList ? max($durList) : 2;
    $durationMinutes = $hours * 60;

    // ---- حدود الحساب: رصيد الساعات + سقف المشاركين (الأدمن معفى) ----
    $host = Db::one('SELECT role, minutes_balance, max_participants FROM users WHERE id = ?', [$hostUserId]) ?: [];
    $isAdmin = (($host['role'] ?? '') === 'admin');
    // رصيد الساعات: NULL = غير محدود. غير ذلك يُخصم منه وقت الإنشاء.
    if (!$isAdmin && $host['minutes_balance'] !== null) {
        $balance = (int) $host['minutes_balance'];
        if ($balance < $durationMinutes) {
            $remainH = round($balance / 60, 1);
            Response::error(
                "رصيد ساعاتك لا يكفي لهذا الاجتماع (المتبقّي {$remainH} ساعة). تواصل مع الأدمن لإضافة ساعات.",
                402
            );
        }
    }
    // سقف المشاركين للمضيف: NULL = غير محدود (يُلقَّط على الغرفة لثباته)
    $roomMaxParticipants = (!$isAdmin && $host['max_participants'] !== null)
        ? max(1, (int) $host['max_participants'])
        : null;


    $waitingRoom = !empty($b['waitingRoom']) ? 1 : 0;
    $startsAt = null;
    $rawStart = trim((string) ($b['startsAt'] ?? ''));
    if ($rawStart !== '') {
        $ts = strtotime($rawStart);
        if ($ts !== false && $ts > time() + 60) $startsAt = date('Y-m-d H:i:s', $ts);
    }
    $roomPassword = trim((string) ($b['password'] ?? ''));
    $passwordHash = $roomPassword !== '' ? password_hash($roomPassword, PASSWORD_DEFAULT) : null;

    $roomCode = mk_gen_room_code();
    if ($startsAt !== null) {
        $id = Db::insert(
            'INSERT INTO rooms (room_code, name, host_user_id, max_height, max_bitrate_kbps, max_fps, duration_minutes, max_participants, starts_at, waiting_room, expires_at)
             VALUES (?,?,?,?,?,?,?,?,?,?, DATE_ADD(?, INTERVAL ? MINUTE))',
            [$roomCode, $name, $hostUserId, $height, $bitrate, $fps, $durationMinutes, $roomMaxParticipants, $startsAt, $waitingRoom, $startsAt, $durationMinutes]
        );
    } else {
        $id = Db::insert(
            'INSERT INTO rooms (room_code, name, host_user_id, max_height, max_bitrate_kbps, max_fps, duration_minutes, max_participants, waiting_room, expires_at)
             VALUES (?,?,?,?,?,?,?,?,?, DATE_ADD(NOW(), INTERVAL ? MINUTE))',
            [$roomCode, $name, $hostUserId, $height, $bitrate, $fps, $durationMinutes, $roomMaxParticipants, $waitingRoom, $durationMinutes]
        );
    }
    Db::q('INSERT INTO room_settings (room_id) VALUES (?)', [$id]);
    if ($passwordHash !== null) Db::q('UPDATE rooms SET password_hash = ? WHERE id = ?', [$passwordHash, $id]);

    // اخصم من رصيد ساعات المضيف (لا يقلّ عن صفر)؛ الأدمن وغير المحدود لا يُخصم منهما
    if (!$isAdmin && $host['minutes_balance'] !== null) {
        try {
            Db::q('UPDATE users SET minutes_balance = GREATEST(0, minutes_balance - ?) WHERE id = ?',
                [$durationMinutes, $hostUserId]);
        } catch (\Throwable $e) {}
    }

    return [
        'code'        => $roomCode,
        'name'        => $name,
        'startsAt'    => $startsAt,
        'waitingRoom' => (bool) $waitingRoom,
        'hasPassword' => $passwordHash !== null,
        'durationHours' => $hours,
        'maxParticipants' => $roomMaxParticipants,
    ];
}

/** الأصل العلني للمنصّة (لبناء روابط الدعوة/التضمين) */
function mk_app_origin(): string
{
    $env = trim((string) env('APP_URL', ''));
    if ($env !== '') return rtrim($env, '/');
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? (string) env('APP_DOMAIN', 'localhost');
    return $scheme . '://' . $host;
}

$top = $segs[0] ?? '';

// ================== المصادقة ==================
if ($top === 'auth') {
    $action = $segs[1] ?? '';

    if ($method === 'POST' && $action === 'register') {
        $b = Response::body();
        $name = trim((string) ($b['name'] ?? ''));
        $email = strtolower(trim((string) ($b['email'] ?? '')));
        $pw = (string) ($b['password'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 6) {
            Response::error('بيانات غير صحيحة (كلمة السر 6 أحرف على الأقل)', 422);
        }
        if (Db::one('SELECT id FROM users WHERE email = ?', [$email])) {
            Response::error('البريد مسجّل مسبقًا', 409);
        }
        $id = Db::insert('INSERT INTO users (email, password_hash, name) VALUES (?,?,?)',
            [$email, Auth::hash($pw), $name]);
        $user = ['id' => $id, 'email' => $email, 'name' => $name, 'role' => 'user'];
        Auth::setCookie(Auth::issue($user));
        Response::json(['user' => $user]);
    }

    if ($method === 'POST' && $action === 'login') {
        $b = Response::body();
        $email = strtolower(trim((string) ($b['email'] ?? '')));
        $pw = (string) ($b['password'] ?? '');
        $u = Db::one('SELECT * FROM users WHERE email = ?', [$email]);
        if (!$u || !Auth::verify($pw, $u['password_hash'])) {
            Response::error('البريد أو كلمة السر غير صحيحة', 401);
        }
        try { Db::q('UPDATE users SET last_login_at = NOW() WHERE id = ?', [(int) $u['id']]); } catch (\Throwable $e) {}
        Auth::setCookie(Auth::issue($u));
        Response::json(['user' => ['id' => (int) $u['id'], 'email' => $u['email'], 'name' => $u['name'], 'role' => $u['role']]]);
    }

    if ($method === 'POST' && $action === 'logout') {
        $u = Auth::user();
        if ($u) Auth::checkCsrf($u);
        Auth::clearCookie();
        Response::ok();
    }

    if ($method === 'GET' && $action === 'me') {
        $u = Auth::require();
        $lim = Db::one('SELECT minutes_balance, max_participants FROM users WHERE id = ?', [(int) $u['sub']]) ?: [];
        $mb = $lim['minutes_balance'] ?? null;
        $mp = $lim['max_participants'] ?? null;
        Response::json([
            'user' => [
                'id'    => (int) $u['sub'],
                'email' => $u['email'],
                'name'  => $u['name'],
                'role'  => $u['role'],
                'minutesBalance'  => $mb === null ? null : (int) $mb,   // null = غير محدود
                'hoursBalance'    => $mb === null ? null : round(((int) $mb) / 60, 1),
                'maxParticipants' => $mp === null ? null : (int) $mp,   // null = غير محدود
            ],
            'csrf' => $u['csrf'] ?? '',
        ]);
    }
}

// ================== قوائم الجودة/المدة (لأي مستخدم مسجّل) ==================
if ($top === 'settings' && ($segs[1] ?? '') === 'presets' && $method === 'GET') {
    Auth::require();
    Response::json(['presets' => settings_all()]);
}

// ================== إعدادات التطبيق (أدمن) ==================
if ($top === 'admin' && ($segs[1] ?? '') === 'settings') {
    Auth::requireAdmin();
    if ($method === 'GET') {
        Response::json(['settings' => settings_all()]);
    }
    if ($method === 'POST' || $method === 'PATCH') {
        $b = Response::body();
        $defs = settings_defaults();
        foreach ($b as $k => $v) {
            if (!array_key_exists($k, $defs) || !is_array($v)) continue;
            // نظّف كل عنصر حسب مفاتيح الافتراضي
            $keys = array_keys($defs[$k][0] ?? []);
            $clean = [];
            foreach ($v as $item) {
                if (!is_array($item)) continue;
                $row = [];
                foreach ($keys as $kk) {
                    if (!array_key_exists($kk, $item)) continue 2;
                    $row[$kk] = $kk === 'label' ? trim((string) $item[$kk]) : (int) $item[$kk];
                }
                if (($row['label'] ?? '') === '') continue;
                $clean[] = $row;
            }
            if ($clean) settings_set($k, $clean);
        }
        Response::json(['settings' => settings_all()]);
    }
}

// ================== إدارة الأعضاء (أدمن) ==================
if ($top === 'admin' && ($segs[1] ?? '') === 'users') {
    $me = Auth::requireAdmin();
    $uid = $segs[2] ?? '';

    // قائمة كل المستخدمين
    if ($method === 'GET' && $uid === '') {
        $rows = Db::all('SELECT id, email, name, role, minutes_balance, max_participants, created_at FROM users ORDER BY (role=\'admin\') DESC, id ASC');
        $out = array_map(fn($r) => [
            'id'              => (int) $r['id'],
            'email'           => $r['email'],
            'name'            => $r['name'],
            'role'            => $r['role'],
            'created_at'      => $r['created_at'],
            'minutesBalance'  => $r['minutes_balance'] === null ? null : (int) $r['minutes_balance'],
            'hoursBalance'    => $r['minutes_balance'] === null ? null : round(((int) $r['minutes_balance']) / 60, 1),
            'maxParticipants' => $r['max_participants'] === null ? null : (int) $r['max_participants'],
        ], $rows);
        Response::json(['users' => $out]);
    }

    // ضبط حدود عضو: رصيد الساعات + سقف المشاركين (unlimited = null)
    if ($method === 'POST' && $uid !== '' && ctype_digit($uid) && ($segs[3] ?? '') === 'limits') {
        if (!Db::one('SELECT id FROM users WHERE id = ?', [(int) $uid])) Response::error('المستخدم غير موجود', 404);
        $b = Response::body();

        // الساعات: hours=رقم (تعيين مطلق) أو "unlimited"/null (غير محدود)
        if (array_key_exists('hours', $b)) {
            $h = $b['hours'];
            if ($h === null || $h === '' || $h === 'unlimited') {
                Db::q('UPDATE users SET minutes_balance = NULL WHERE id = ?', [(int) $uid]);
            } else {
                $mins = (int) round(((float) $h) * 60);
                if ($mins < 0) $mins = 0;
                Db::q('UPDATE users SET minutes_balance = ? WHERE id = ?', [$mins, (int) $uid]);
            }
        }
        // إضافة ساعات فوق الرصيد الحالي (يعامل غير المحدود كأنه يبقى غير محدود)
        if (array_key_exists('addHours', $b) && $b['addHours'] !== null && $b['addHours'] !== '') {
            $addMins = (int) round(((float) $b['addHours']) * 60);
            Db::q('UPDATE users SET minutes_balance = GREATEST(0, COALESCE(minutes_balance,0) + ?) WHERE id = ? AND minutes_balance IS NOT NULL',
                [$addMins, (int) $uid]);
        }
        // سقف المشاركين
        if (array_key_exists('participants', $b)) {
            $p = $b['participants'];
            if ($p === null || $p === '' || $p === 'unlimited') {
                Db::q('UPDATE users SET max_participants = NULL WHERE id = ?', [(int) $uid]);
            } else {
                $pv = max(1, (int) $p);
                Db::q('UPDATE users SET max_participants = ? WHERE id = ?', [$pv, (int) $uid]);
            }
        }

        $r = Db::one('SELECT minutes_balance, max_participants FROM users WHERE id = ?', [(int) $uid]);
        Response::json([
            'ok'              => true,
            'id'              => (int) $uid,
            'minutesBalance'  => $r['minutes_balance'] === null ? null : (int) $r['minutes_balance'],
            'hoursBalance'    => $r['minutes_balance'] === null ? null : round(((int) $r['minutes_balance']) / 60, 1),
            'maxParticipants' => $r['max_participants'] === null ? null : (int) $r['max_participants'],
        ]);
    }

    // تغيير دور مستخدم (ترقية/تنزيل)
    if ($method === 'POST' && $uid !== '' && ctype_digit($uid) && ($segs[3] ?? '') === 'role') {
        $role = (string) (Response::body()['role'] ?? '');
        if (!in_array($role, ['user', 'admin'], true)) Response::error('دور غير صالح', 422);
        if ((int) $uid === (int) $me['sub'] && $role !== 'admin') {
            Response::error('لا يمكنك إزالة صلاحية الأدمن عن نفسك', 400);
        }
        if (!Db::one('SELECT id FROM users WHERE id = ?', [(int) $uid])) Response::error('المستخدم غير موجود', 404);
        Db::q('UPDATE users SET role = ? WHERE id = ?', [$role, (int) $uid]);
        Response::json(['ok' => true, 'id' => (int) $uid, 'role' => $role]);
    }
}

// ================== الغرف ==================
if ($top === 'rooms') {
    $code = $segs[1] ?? '';
    $sub  = $segs[2] ?? '';

    // إنشاء غرفة
    if ($method === 'POST' && $code === '') {
        $u = Auth::require();
        $room = mk_create_room((int) $u['sub'], Response::body());
        Response::json(['room' => $room]);
    }

    // قائمة غرفي (النشطة فقط — المنتهية انتقلت للسجل)
    if ($method === 'GET' && $code === '') {
        $u = Auth::require();
        sweep_expired();
        $rows = Db::all('SELECT room_code, name, is_active, duration_minutes, starts_at, waiting_room, (password_hash IS NOT NULL) AS has_password, expires_at, created_at FROM rooms WHERE host_user_id = ? AND is_active = 1 ORDER BY created_at DESC', [(int) $u['sub']]);
        Response::json(['rooms' => $rows]);
    }

    // سجل الجلسات المنتهية (يجب أن يسبق مسار "معلومات غرفة")
    if ($method === 'GET' && $code === 'history' && $sub === '') {
        $u = Auth::require();
        $rows = Db::all(
            'SELECT id, room_code, name, started_at, ended_at, duration_seconds, participant_count
               FROM meeting_sessions WHERE host_user_id = ? ORDER BY ended_at DESC LIMIT 500',
            [(int) $u['sub']]
        );
        $out = array_map(fn($r) => [
            'id'               => (int) $r['id'],
            'code'             => $r['room_code'],
            'name'             => $r['name'],
            'startedAt'        => $r['started_at'],
            'endedAt'          => $r['ended_at'],
            'durationSeconds'  => (int) $r['duration_seconds'],
            'participantCount' => (int) $r['participant_count'],
        ], $rows);
        Response::json(['sessions' => $out]);
    }

    // تفاصيل جلسة من السجل + الحضور
    if ($method === 'GET' && $code === 'history' && $sub !== '') {
        $u = Auth::require();
        $s = Db::one('SELECT * FROM meeting_sessions WHERE id = ?', [(int) $sub]);
        if (!$s || (int) $s['host_user_id'] !== (int) $u['sub']) Response::error('الجلسة غير موجودة', 404);
        $att = Db::all(
            'SELECT name, identity, joined_at, left_at, duration_seconds
               FROM attendance WHERE session_id = ? ORDER BY joined_at ASC',
            [(int) $s['id']]
        );
        Response::json([
            'session' => [
                'id'               => (int) $s['id'],
                'code'             => $s['room_code'],
                'name'             => $s['name'],
                'startedAt'        => $s['started_at'],
                'endedAt'          => $s['ended_at'],
                'durationSeconds'  => (int) $s['duration_seconds'],
                'participantCount' => (int) $s['participant_count'],
            ],
            'attendees' => array_map(fn($a) => [
                'name'            => $a['name'],
                'identity'        => $a['identity'],
                'joinedAt'        => $a['joined_at'],
                'leftAt'          => $a['left_at'],
                'durationSeconds' => (int) $a['duration_seconds'],
                'durationMinutes' => (int) round(((int) $a['duration_seconds']) / 60),
            ], $att),
        ]);
    }

    // معلومات غرفة
    if ($method === 'GET' && $code !== '' && $sub === '') {
        $room = room_by_code($code);
        enforce_expiry($room);
        Response::json(['room' => [
            'code'    => $room['room_code'],
            'name'    => $room['name'],
            'active'  => (bool) $room['is_active'],
            'quality' => room_quality($room),
            'expiresAt' => $room['expires_at'] ?? null,
            'startsAt'    => $room['starts_at'] ?? null,
            'waitingRoom' => (bool) ($room['waiting_room'] ?? 0),
            'hasPassword' => !empty($room['password_hash']),
        ]]);
    }

    // توكن انضمام
    if ($method === 'POST' && $sub === 'token') {
        $room = room_by_code($code);
        if (enforce_expiry($room) || (int) $room['is_active'] !== 1) {
            Response::error('انتهت هذه الغرفة', 410);
        }
        $u = Auth::require();
        $identity = 'u' . (int) $u['sub'];
        if (Db::one('SELECT id FROM kicked WHERE room_id = ? AND identity = ?', [$room['id'], $identity])) {
            Response::error('تم طردك من هذه الغرفة', 403);
        }
        $mod = is_moderator($u, $room);
        $owner = is_owner_or_admin($u, $room);

        // بوّابة كلمة المرور: غير المضيفين لازم يقدّموا كلمة المرور الصحيحة (تُرسَل في جسم الطلب)
        if (!$mod && !empty($room['password_hash'])) {
            $pw = (string) (Response::body()['password'] ?? '');
            if ($pw === '' || !password_verify($pw, (string) $room['password_hash'])) {
                Response::json([
                    'needPassword' => true,
                    'roomName'     => $room['name'],
                    'wrong'        => $pw !== '',
                ]);
            }
        }

        // بوّابة الجدولة: قبل موعد البدء يُحجب غير المضيفين (المضيف يدخل مبكرًا ليجهّز)
        if (!$mod && !empty($room['starts_at']) && strtotime((string) $room['starts_at']) > time()) {
            Response::json([
                'waiting'  => true,
                'reason'   => 'scheduled',
                'startsAt' => $room['starts_at'],
                'roomName' => $room['name'],
            ]);
        }

        // بوّابة غرفة الانتظار: غير المضيفين ينتظرون موافقة المضيف
        if (!$mod && (int) ($room['waiting_room'] ?? 0) === 1) {
            $adm = Db::one('SELECT status FROM room_admissions WHERE room_id = ? AND user_id = ?', [$room['id'], (int) $u['sub']]);
            $status = $adm['status'] ?? null;
            if ($status === 'denied') {
                Response::error('لم يُسمح لك بالدخول لهذه الغرفة', 403);
            }
            if ($status !== 'admitted') {
                Db::q(
                    'INSERT INTO room_admissions (room_id, user_id, name, status) VALUES (?,?,?,\'pending\')
                     ON DUPLICATE KEY UPDATE name = VALUES(name)',
                    [$room['id'], (int) $u['sub'], (string) $u['name']]
                );
                Response::json([
                    'waiting'  => true,
                    'reason'   => 'lobby',
                    'roomName' => $room['name'],
                ]);
            }
        }

        $meta = json_encode(['role' => $mod ? 'host' : 'user', 'userId' => (int) $u['sub']], JSON_UNESCAPED_UNICODE);
        // افرض سقف المشاركين قبل السكّ (المشرفون معفَون)
        $cap = enforce_participant_cap($room, $identity, $mod);
        // أبقِ غرفة LiveKit حيّة طوال المدة المتبقية حتى لو خلت مؤقتًا من المشاركين
        $remain = !empty($room['expires_at']) ? max(60, strtotime((string) $room['expires_at']) - time()) : 6 * 3600;
        try { LiveKit::createRoom($room['room_code'], $remain, $remain, $cap); } catch (\Throwable $e) {}
        $token = LiveKit::joinToken($room['room_code'], $identity, $u['name'], $meta);
        Response::json([
            'url'       => env('LIVEKIT_URL'),
            'token'     => $token,
            'identity'  => $identity,
            'isHost'    => $mod,
            'isOwner'   => $owner,
            'roomName'  => $room['room_code'],
            'settings'  => room_metadata($room['settings']),
            'quality'   => room_quality($room),
            'expiresAt' => $room['expires_at'] ?? null,
        ]);
    }

    // إعدادات الغرفة (الأقفال)
    if ($method === 'GET' && $sub === 'settings') {
        $room = room_by_code($code);
        require_mod($room);
        Response::json(['settings' => room_metadata($room['settings'])]);
    }

    if ($method === 'POST' && $sub === 'settings') {
        $room = room_by_code($code);
        require_mod($room);
        $meta = apply_room_settings($room, Response::body());
        Response::json(['settings' => $meta]);
    }

    // كتم مسار مشارك بعينه
    if ($method === 'POST' && $sub === 'mute') {
        $room = room_by_code($code);
        require_mod($room);
        $b = Response::body();
        LiveKit::mute($room['room_code'], (string) $b['identity'], (string) $b['trackSid'], (bool) ($b['muted'] ?? true));
        Response::ok();
    }

    // طرد مشارك
    if ($method === 'POST' && $sub === 'kick') {
        $room = room_by_code($code);
        require_mod($room);
        $identity = (string) (Response::body()['identity'] ?? '');
        if ($identity === '') Response::error('identity مطلوب', 422);
        Db::q('INSERT IGNORE INTO kicked (room_id, identity) VALUES (?,?)', [$room['id'], $identity]);
        try { LiveKit::removeParticipant($room['room_code'], $identity); } catch (\Throwable $e) {}
        Response::ok();
    }

    // إنهاء الاجتماع فورًا (أدمن) — يفصل الجميع ويغلق الغرفة
    if ($method === 'POST' && $sub === 'end') {
        $room = room_by_code($code);
        require_mod($room);
        close_room($room);
        Response::ok();
    }

    // قائمة المنتظِرين في غرفة الانتظار (للمضيف)
    if ($method === 'GET' && $sub === 'waiting') {
        $room = room_by_code($code);
        require_mod($room);
        $rows = Db::all(
            'SELECT user_id AS userId, name FROM room_admissions WHERE room_id = ? AND status = \'pending\' ORDER BY updated_at ASC',
            [(int) $room['id']]
        );
        Response::json(['waiting' => $rows]);
    }

    // قبول/رفض منتظِر (للمضيف)
    if ($method === 'POST' && $sub === 'admit') {
        $room = room_by_code($code);
        require_mod($room);
        $b = Response::body();
        $targetId = (int) ($b['userId'] ?? 0);
        $decision = (string) ($b['decision'] ?? '');
        if ($targetId <= 0) Response::error('userId مطلوب', 422);
        $newStatus = $decision === 'admit' ? 'admitted' : ($decision === 'deny' ? 'denied' : '');
        if ($newStatus === '') Response::error('decision يجب أن يكون admit أو deny', 422);
        Db::q('UPDATE room_admissions SET status = ? WHERE room_id = ? AND user_id = ?', [$newStatus, (int) $room['id'], $targetId]);
        Response::json(['ok' => true, 'userId' => $targetId, 'status' => $newStatus]);
    }

    // تعيين مشرف (co-host) — لصاحب الاجتماع أو الأدمن فقط
    if ($method === 'POST' && $sub === 'cohost') {
        $room = room_by_code($code);
        require_owner($room);
        $targetId = (int) (Response::body()['userId'] ?? 0);
        if ($targetId <= 0) Response::error('userId مطلوب', 422);
        if (!Db::one('SELECT id FROM users WHERE id = ?', [$targetId])) Response::error('المستخدم غير موجود', 404);
        Db::q('INSERT IGNORE INTO room_cohosts (room_id, user_id) VALUES (?,?)', [(int) $room['id'], $targetId]);
        // رقِّه حيًّا: حدّث metadata مشاركه في LiveKit إلى host
        try {
            $meta = json_encode(['role' => 'host', 'userId' => $targetId], JSON_UNESCAPED_UNICODE);
            LiveKit::updateParticipant($room['room_code'], 'u' . $targetId, $meta);
        } catch (\Throwable $e) {}
        Response::json(['ok' => true, 'userId' => $targetId]);
    }

    // إلغاء إشراف — DELETE /rooms/:code/cohost/:userId
    if ($method === 'DELETE' && $sub === 'cohost') {
        $room = room_by_code($code);
        require_owner($room);
        $targetId = (int) ($segs[3] ?? 0);
        if ($targetId <= 0) Response::error('userId مطلوب', 422);
        Db::q('DELETE FROM room_cohosts WHERE room_id = ? AND user_id = ?', [(int) $room['id'], $targetId]);
        try {
            $meta = json_encode(['role' => 'user', 'userId' => $targetId], JSON_UNESCAPED_UNICODE);
            LiveKit::updateParticipant($room['room_code'], 'u' . $targetId, $meta);
        } catch (\Throwable $e) {}
        Response::json(['ok' => true, 'userId' => $targetId]);
    }

    // حذف اجتماع منتهٍ يدويًا — لصاحب الاجتماع أو الأدمن فقط
    if ($method === 'DELETE' && $code !== '' && $sub === '') {
        $room = room_by_code($code);
        require_owner($room);
        if ((int) $room['is_active'] === 1) Response::error('لا يمكن حذف اجتماع نشط، أنهِه أولًا', 400);
        try { LiveKit::deleteRoom($room['room_code']); } catch (\Throwable $e) {}
        Db::q('DELETE FROM rooms WHERE id = ?', [(int) $room['id']]);
        Response::ok();
    }

}

// ================== إدارة مفتاح API للمستخدم (متصفّح، مصادقة بالكوكي) ==================
if ($top === 'account' && ($segs[1] ?? '') === 'api-token') {
    $u = Auth::require();
    $uid = (int) $u['sub'];

    // عرض المفتاح الحالي (قد يكون فارغًا لم يُنشأ بعد)
    if ($method === 'GET') {
        $row = Db::one('SELECT api_token FROM users WHERE id = ?', [$uid]);
        Response::json(['apiToken' => $row['api_token'] ?? null]);
    }

    // توليد/تدوير المفتاح (يُبطِل القديم فورًا)
    if ($method === 'POST') {
        Auth::checkCsrf($u);
        do {
            $tok = Auth::newApiToken();
        } while (Db::one('SELECT id FROM users WHERE api_token = ?', [$tok]));
        Db::q('UPDATE users SET api_token = ? WHERE id = ?', [$tok, $uid]);
        Response::json(['apiToken' => $tok]);
    }

    // إلغاء المفتاح
    if ($method === 'DELETE') {
        Auth::checkCsrf($u);
        Db::q('UPDATE users SET api_token = NULL WHERE id = ?', [$uid]);
        Response::ok();
    }
}

// ================== الملف الشخصي (متصفّح، مصادقة بالكوكي) ==================
if ($top === 'account' && ($segs[1] ?? '') === 'profile') {
    $u = Auth::require();
    $uid = (int) $u['sub'];

    if ($method === 'GET') {
        $row = Db::one('SELECT id,email,name,role,created_at,last_login_at FROM users WHERE id = ?', [$uid]);
        if (!$row) Response::error('غير موجود', 404);
        Response::json(['profile' => [
            'id' => (int) $row['id'], 'email' => $row['email'], 'name' => $row['name'],
            'role' => $row['role'], 'createdAt' => $row['created_at'], 'lastLoginAt' => $row['last_login_at'] ?? null,
        ]]);
    }

    if ($method === 'POST') {
        Auth::checkCsrf($u);
        $b = Response::body();
        $name = trim((string) ($b['name'] ?? ''));
        $email = strtolower(trim((string) ($b['email'] ?? '')));
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Response::error('بيانات غير صحيحة', 422);
        }
        $dupe = Db::one('SELECT id FROM users WHERE email = ? AND id <> ?', [$email, $uid]);
        if ($dupe) Response::error('البريد مستخدم من حساب آخر', 409);
        try { Db::q('UPDATE users SET name = ?, email = ?, updated_at = NOW() WHERE id = ?', [$name, $email, $uid]); }
        catch (\Throwable $e) { Db::q('UPDATE users SET name = ?, email = ? WHERE id = ?', [$name, $email, $uid]); }
        Auth::refreshIdentity($uid, ['name' => $name, 'email' => $email]);
        Response::json(['profile' => ['id' => $uid, 'email' => $email, 'name' => $name, 'role' => $u['role']]]);
    }
}

// ================== تغيير كلمة المرور ==================
if ($top === 'account' && ($segs[1] ?? '') === 'password' && $method === 'POST') {
    $u = Auth::require();
    Auth::checkCsrf($u);
    $uid = (int) $u['sub'];
    $b = Response::body();
    $cur = (string) ($b['current'] ?? '');
    $new = (string) ($b['new'] ?? ($b['password'] ?? ''));
    $revokeOthers = ($b['revokeOthers'] ?? true) ? true : false;
    if (strlen($new) < 6) Response::error('كلمة المرور الجديدة 6 أحرف على الأقل', 422);
    $row = Db::one('SELECT password_hash FROM users WHERE id = ?', [$uid]);
    if (!$row || !Auth::verify($cur, $row['password_hash'])) {
        Response::error('كلمة المرور الحالية غير صحيحة', 401);
    }
    try { Db::q('UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?', [Auth::hash($new), $uid]); }
    catch (\Throwable $e) { Db::q('UPDATE users SET password_hash = ? WHERE id = ?', [Auth::hash($new), $uid]); }
    // إبطال بقيّة الجلسات (إبقاء الحالية) بعد تغيير كلمة المرور — اختياري حسب اختيار المستخدم
    $revoked = $revokeOthers ? Auth::revokeAll($uid, $u['sid'] ?? null) : 0;
    Response::json(['ok' => true, 'revokedSessions' => $revoked]);
}

// ================== الجلسات النشطة (سرد/إبطال) ==================
if ($top === 'account' && ($segs[1] ?? '') === 'sessions') {
    $u = Auth::require();
    $uid = (int) $u['sub'];
    $cur = $u['sid'] ?? null;
    $sub = $segs[2] ?? '';

    if ($method === 'GET' && $sub === '') {
        Response::json(['sessions' => Auth::listSessions($uid, $cur)]);
    }
    if ($method === 'POST' && $sub === 'revoke-all') {
        Auth::checkCsrf($u);
        $n = Auth::revokeAll($uid, $cur);
        Response::json(['ok' => true, 'revoked' => $n]);
    }
    if ($method === 'DELETE' && $sub !== '') {
        Auth::checkCsrf($u);
        // $sub هو معرّف الجلسة الكامل (sid)
        $raw = \App\Redis::get('sess:' . $sub);
        if ($raw) {
            $d = json_decode($raw, true);
            if (is_array($d) && (int) ($d['uid'] ?? 0) === $uid) {
                \App\Redis::del('sess:' . $sub);
                \App\Redis::srem('usess:' . $uid, $sub);
                Response::ok();
            }
        }
        Response::error('جلسة غير موجودة', 404);
    }
}

// ================== واجهة المطوّرين العلنية (مصادقة بـ api_token) ==================
//  كل المسارات تحت /api/v1/*  وتتطلّب ترويسة: Authorization: Bearer <api_token>
if ($top === 'v1') {
    $u   = Auth::requireApi();          // المطوّر (صاحب المفتاح)
    $uid = (int) $u['sub'];
    $res = $segs[1] ?? '';

    if ($res === 'rooms') {
        $code = $segs[2] ?? '';
        $sub  = $segs[3] ?? '';

        // إنشاء اجتماع
        if ($method === 'POST' && $code === '') {
            $room = mk_create_room($uid, Response::body());
            $origin = mk_app_origin();
            $room['inviteUrl'] = $origin . '/room.html?room=' . $room['code'];
            Response::json(['room' => $room], 201);
        }

        // قائمة اجتماعات المطوّر (النشطة فقط — المنتهية في السجل)
        if ($method === 'GET' && $code === '') {
            sweep_expired();
            $rows = Db::all(
                'SELECT room_code AS code, name, is_active, duration_minutes, starts_at, waiting_room, (password_hash IS NOT NULL) AS has_password, expires_at, created_at
                 FROM rooms WHERE host_user_id = ? AND is_active = 1 ORDER BY created_at DESC',
                [$uid]
            );
            Response::json(['rooms' => $rows]);
        }

        // سجل الجلسات المنتهية للمطوّر
        if ($method === 'GET' && $code === 'history' && $sub === '') {
            $limit  = max(1, min(500, (int) ($_GET['limit'] ?? 100)));
            $offset = max(0, (int) ($_GET['offset'] ?? 0));
            $rows = Db::all(
                "SELECT id, room_code AS code, name, started_at, ended_at, duration_seconds, participant_count
                   FROM meeting_sessions WHERE host_user_id = ? ORDER BY ended_at DESC LIMIT $limit OFFSET $offset",
                [$uid]
            );
            $out = array_map(fn($r) => [
                'id'               => (int) $r['id'],
                'code'             => $r['code'],
                'name'             => $r['name'],
                'startedAt'        => $r['started_at'],
                'endedAt'          => $r['ended_at'],
                'durationSeconds'  => (int) $r['duration_seconds'],
                'participantCount' => (int) $r['participant_count'],
            ], $rows);
            Response::json(['sessions' => $out]);
        }

        // تفاصيل جلسة + الحضور
        if ($method === 'GET' && $code === 'history' && $sub !== '') {
            $s = Db::one('SELECT * FROM meeting_sessions WHERE id = ?', [(int) $sub]);
            if (!$s || (int) $s['host_user_id'] !== $uid) Response::error('الجلسة غير موجودة', 404);
            $att = Db::all(
                'SELECT name, identity, joined_at, left_at, duration_seconds
                   FROM attendance WHERE session_id = ? ORDER BY joined_at ASC',
                [(int) $s['id']]
            );
            Response::json([
                'session' => [
                    'id'               => (int) $s['id'],
                    'code'             => $s['room_code'],
                    'name'             => $s['name'],
                    'startedAt'        => $s['started_at'],
                    'endedAt'          => $s['ended_at'],
                    'durationSeconds'  => (int) $s['duration_seconds'],
                    'participantCount' => (int) $s['participant_count'],
                ],
                'attendees' => array_map(fn($a) => [
                    'name'            => $a['name'],
                    'identity'        => $a['identity'],
                    'joinedAt'        => $a['joined_at'],
                    'leftAt'          => $a['left_at'],
                    'durationSeconds' => (int) $a['duration_seconds'],
                    'durationMinutes' => (int) round(((int) $a['duration_seconds']) / 60),
                ], $att),
            ]);
        }

        if ($code !== '') {
            $room = room_by_code($code);
            // المطوّر لا يتصرّف إلا في اجتماعاته هو
            if ((int) $room['host_user_id'] !== $uid) Response::error('لا تملك صلاحية على هذا الاجتماع', 403);

            // معلومات اجتماع
            if ($method === 'GET' && $sub === '') {
                enforce_expiry($room);
                Response::json(['room' => [
                    'code'        => $room['room_code'],
                    'name'        => $room['name'],
                    'active'      => (bool) $room['is_active'],
                    'quality'     => room_quality($room),
                    'startsAt'    => $room['starts_at'] ?? null,
                    'waitingRoom' => (bool) ($room['waiting_room'] ?? 0),
                    'hasPassword' => !empty($room['password_hash']),
                    'expiresAt'   => $room['expires_at'] ?? null,
                ]]);
            }

            // إنهاء/حذف اجتماع
            if ($method === 'DELETE' && $sub === '') {
                close_room($room);
                Response::ok();
            }

            // ★ سكّ توكن انضمام لمستخدم نهائي عند المطوّر (غير مسجّل عندنا)
            //   body: { identity, name, role?('host'|'participant'|'viewer'), ttl? }
            if ($method === 'POST' && $sub === 'token') {
                if (enforce_expiry($room) || (int) $room['is_active'] !== 1) {
                    Response::error('انتهى هذا الاجتماع', 410);
                }
                $b = Response::body();
                $rawId = trim((string) ($b['identity'] ?? ''));
                $name  = trim((string) ($b['name'] ?? '')) ?: 'ضيف';
                $role  = (string) ($b['role'] ?? 'participant');
                if ($rawId === '') Response::error('identity مطلوب (معرّف المستخدم لديك)', 422);
                if (mb_strlen($name) > 80) $name = mb_substr($name, 0, 80);

                // نطاق منفصل لهويّات الضيوف كي لا تصطدم بهويّات مستخدمينا (u<id>)
                $identity = 'g_' . preg_replace('/[^A-Za-z0-9_.\-]/', '_', $rawId);
                $identity = substr($identity, 0, 120);

                $isHost = ($role === 'host');
                $canPublish = ($role !== 'viewer');
                $meta = json_encode(['role' => $isHost ? 'host' : 'user', 'guest' => true], JSON_UNESCAPED_UNICODE);

                $remain = !empty($room['expires_at'])
                    ? max(60, strtotime((string) $room['expires_at']) - time())
                    : 6 * 3600;
                $ttl = (int) ($b['ttl'] ?? $remain);
                $ttl = max(60, min($ttl, $remain));

                try { LiveKit::createRoom($room['room_code'], $remain, $remain, enforce_participant_cap($room, $identity, $isHost)); } catch (\Throwable $e) {}
                $token = LiveKit::joinToken($room['room_code'], $identity, $name, $meta, [
                    'canPublish' => $canPublish,
                    'ttl'        => $ttl,
                ]);
                $origin = mk_app_origin();
                Response::json([
                    'token'    => $token,
                    'url'      => env('LIVEKIT_URL'),        // wsUrl لعميل LiveKit
                    'identity' => $identity,
                    'room'     => $room['room_code'],
                    'roomName' => $room['name'],
                    'role'     => $isHost ? 'host' : ($canPublish ? 'participant' : 'viewer'),
                    'expiresIn'=> $ttl,
                    // صفحة اجتماع جاهزة نستضيفها؛ التوكن في الـ hash فلا يُسجَّل في السجلّات
                    'embedUrl' => $origin . '/embed.html#token=' . rawurlencode($token)
                        . '&url=' . rawurlencode((string) env('LIVEKIT_URL'))
                        . '&name=' . rawurlencode((string) $room['name']),
                ]);
            }
        }
    }

    Response::error('مسار API غير موجود: /v1/' . implode('/', array_slice($segs, 1)), 404);
}

// ================== النودز (أدمن) ==================
if ($top === 'nodes') {
    $id = $segs[1] ?? '';
    $sub = $segs[2] ?? '';

    if ($method === 'GET' && $id === '') {
        Auth::requireAdmin();
        $rows = Db::all('SELECT id, name, host, ssh_user, ssh_port, region, is_main, status, last_error, last_seen, created_at FROM nodes ORDER BY is_main DESC, id ASC');
        Response::json(['nodes' => $rows]);
    }

    if ($method === 'POST' && $id === '') {
        Auth::requireAdmin();
        $b = Response::body();
        $host = trim((string) ($b['host'] ?? ''));
        $name = trim((string) ($b['name'] ?? '')) ?: $host;
        if ($host === '') Response::error('عنوان النود (host) مطلوب', 422);
        if (Db::one('SELECT id FROM nodes WHERE host = ?', [$host])) Response::error('النود مضافة مسبقًا', 409);
        $nid = Db::insert('INSERT INTO nodes (name, host, ssh_user, ssh_port, region, status) VALUES (?,?,?,?,?,?)',
            [$name, $host, trim((string) ($b['ssh_user'] ?? 'root')), (int) ($b['ssh_port'] ?? 22), trim((string) ($b['region'] ?? '')) ?: null, 'provisioning']);
        Response::json(['node' => ['id' => $nid, 'host' => $host, 'name' => $name, 'status' => 'provisioning']]);
    }

    if ($id !== '' && ctype_digit($id)) {
        Auth::requireAdmin();
        $node = Db::one('SELECT * FROM nodes WHERE id = ?', [(int) $id]);
        if (!$node) Response::error('النود غير موجودة', 404);

        // تعديل بيانات النود
        if (($method === 'POST' || $method === 'PATCH') && $sub === '') {
            $b = Response::body();
            $name = trim((string) ($b['name'] ?? $node['name']));
            $host = trim((string) ($b['host'] ?? $node['host']));
            $user = trim((string) ($b['ssh_user'] ?? $node['ssh_user']));
            $port = (int) ($b['ssh_port'] ?? $node['ssh_port']);
            $region = array_key_exists('region', $b) ? (trim((string) $b['region']) ?: null) : $node['region'];
            Db::q('UPDATE nodes SET name=?, host=?, ssh_user=?, ssh_port=?, region=? WHERE id=?',
                [$name, $host, $user, $port, $region, $node['id']]);
            Response::json(['node' => ['id' => (int) $node['id'], 'name' => $name, 'host' => $host]]);
        }

        // حذف نود (ليست الأساسية)
        if ($method === 'DELETE' && $sub === '') {
            if ((int) $node['is_main'] === 1) Response::error('لا يمكن حذف السيرفر الأساسي', 400);
            Db::q('DELETE FROM nodes WHERE id = ?', [$node['id']]);
            Response::ok();
        }

        // تجهيز النود عبر SSH وتثبيت كل شيء
        if ($method === 'POST' && $sub === 'provision') {
            $password = (string) (Response::body()['password'] ?? '');
            if ($password === '') Response::error('كلمة مرور SSH مطلوبة لهذه المرة فقط', 422);
            // مسار السكربت نسبةً لجذر التطبيق (backend/api/index.php ⇒ جذر التطبيق = dirname مرّتين)
            $scriptFile = dirname(__DIR__, 2) . '/scripts/install-node.sh';
            if (!is_file($scriptFile)) Response::error('سكربت تثبيت النود غير متوفر على السيرفر', 500);

            $vars = [
                'MAIN_IP'            => env('PUBLIC_IP'),
                'REDIS_PORT'         => env('REDIS_PORT', '6379'),
                'REDIS_PASSWORD'     => env('REDIS_PASSWORD'),
                'LIVEKIT_API_KEY'    => env('LIVEKIT_API_KEY'),
                'LIVEKIT_API_SECRET' => env('LIVEKIT_API_SECRET'),
                'TURN_SECRET'        => env('TURN_SECRET'),
                'APP_DOMAIN'         => env('APP_DOMAIN'),
                'NODE_PUBLIC_IP'     => $node['host'],
            ];
            $prefix = "#!/usr/bin/env bash\n";
            foreach ($vars as $k => $v) $prefix .= "export $k=" . escapeshellarg((string) $v) . "\n";
            $script = $prefix . file_get_contents($scriptFile);

            // ادفع ثنائي LiveKit الجاهز من السيرفر الأساسي إلى النود مباشرةً،
            // فيتخطّى سكربت التثبيت التنزيل من GitHub (الذي قد يُرجع 500).
            $uploads = [];
            $mainBin = '/usr/local/bin/livekit-server';
            if (is_file($mainBin) && is_readable($mainBin)) {
                // نرفع إلى /tmp (وليس مباشرةً فوق الثنائي) لأن الملف قد يكون قيد التشغيل
                // على النود، فيرفض SFTP الكتابة فوقه (ETXTBSY). السكربت يركّبه من /tmp.
                $uploads[$mainBin] = '/tmp/livekit-server.push';
            }

            // افتح جدار الأساسي لهذه النود على منفذ Redis فقط (عبر helper مقيّد بـ sudoers)
            // كي تتصل النود بعنقود LiveKit فور إقلاعها. IP النود فقط، لا العالم.
            if (filter_var($node['host'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                @exec('sudo -n /usr/local/sbin/meet-allow-node ' . escapeshellarg($node['host']) . ' 2>&1', $_o, $_rc);
            }

            Db::q("UPDATE nodes SET status='provisioning', last_error=NULL WHERE id=?", [$node['id']]);
            try {
                $res = Ssh::runScript($node['host'], (int) $node['ssh_port'], $node['ssh_user'], $password, $script, $uploads);
            } catch (\Throwable $e) {
                Db::q("UPDATE nodes SET status='error', last_error=? WHERE id=?", [$e->getMessage(), $node['id']]);
                Response::error($e->getMessage(), 502);
            }
            $ok = ($res['exit'] === 0);
            Db::q("UPDATE nodes SET status=?, last_error=?, last_seen=NOW() WHERE id=?",
                [$ok ? 'online' : 'error', $ok ? null : substr($res['output'], -2000), $node['id']]);
            Response::json(['exit' => $res['exit'], 'output' => $res['output'], 'status' => $ok ? 'online' : 'error']);
        }
    }
}

// ================== إدارة داخل الغرفة بتوكن LiveKit (لصفحة التضمين/الضيوف) ==================
//  المصادقة بتوكن الانضمام نفسه (موقّع بـ LIVEKIT_API_SECRET) — لا كوكيز.
//  العمليات المتغيّرة تتطلّب role=host في حمولة التوكن. السرّ يبقى على السيرفر.
//  المسارات:  /rtc/:code/settings (GET/POST) · /mute · /kick · /end
if ($top === 'rtc') {
    $code = $segs[1] ?? '';
    $sub  = $segs[2] ?? '';

    $tk = Auth::verifyLivekitToken();
    if (!$tk)                       Response::error('توكن الغرفة غير صالح أو منتهٍ', 401);
    if ($code === '' || $tk['room'] !== $code) Response::error('التوكن لا يخصّ هذه الغرفة', 403);

    $room   = room_by_code($code);
    $isHost = ($tk['role'] === 'host');
    $needHost = function () use ($isHost) {
        if (!$isHost) Response::error('هذه العملية للمضيف فقط', 403);
    };

    // قراءة الأقفال الحالية (لأي مشارك)
    if ($method === 'GET' && $sub === 'settings') {
        Response::json(['settings' => room_metadata($room['settings'])]);
    }

    // تعديل الأقفال (للمضيف) — نعفي هويّة المضيف-الضيف الحالية من الكتم الذاتي
    if ($method === 'POST' && $sub === 'settings') {
        $needHost();
        $meta = apply_room_settings($room, Response::body(), [$tk['identity']]);
        Response::json(['settings' => $meta]);
    }

    // كتم مسار مشارك بعينه (للمضيف)
    if ($method === 'POST' && $sub === 'mute') {
        $needHost();
        $b = Response::body();
        LiveKit::mute($room['room_code'], (string) ($b['identity'] ?? ''), (string) ($b['trackSid'] ?? ''), (bool) ($b['muted'] ?? true));
        Response::ok();
    }

    // طرد مشارك (للمضيف) — لا يطرد نفسه
    if ($method === 'POST' && $sub === 'kick') {
        $needHost();
        $identity = (string) (Response::body()['identity'] ?? '');
        if ($identity === '') Response::error('identity مطلوب', 422);
        if ($identity === $tk['identity']) Response::error('لا يمكنك طرد نفسك', 400);
        Db::q('INSERT IGNORE INTO kicked (room_id, identity) VALUES (?,?)', [$room['id'], $identity]);
        try { LiveKit::removeParticipant($room['room_code'], $identity); } catch (\Throwable $e) {}
        Response::ok();
    }

    // إنهاء الاجتماع فورًا (للمضيف)
    if ($method === 'POST' && $sub === 'end') {
        $needHost();
        close_room($room);
        Response::ok();
    }

    Response::error('مسار غير موجود: /rtc/' . implode('/', array_slice($segs, 1)), 404);
}

// ================== LiveKit Webhook ==================
if ($top === 'webhook' && $method === 'POST') {
    $raw = file_get_contents('php://input') ?: '';
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    $token = preg_match('/Bearer\s+(.+)/i', $auth, $m) ? $m[1] : $auth;
    try {
        \Firebase\JWT\JWT::decode($token, new \Firebase\JWT\Key((string) env('LIVEKIT_API_SECRET'), 'HS256'));
    } catch (\Throwable $e) {
        Response::error('توقيع webhook غير صالح', 401);
    }
    $ev = json_decode($raw, true) ?: [];
    $type = $ev['event'] ?? '';

    if ($type === 'participant_joined') {
        $rn = $ev['room']['name'] ?? '';
        $p  = $ev['participant'] ?? [];
        $identity = (string) ($p['identity'] ?? '');
        if ($rn && $identity !== '') {
            $pname = (string) ($p['name'] ?? $identity);
            try {
                Db::q(
                    "INSERT INTO attendance (room_code, identity, name, joined_at) VALUES (?,?,?,NOW())",
                    [$rn, $identity, $pname]
                );
            } catch (\Throwable $e) {}
        }
    } elseif ($type === 'participant_left') {
        $rn = $ev['room']['name'] ?? '';
        $identity = (string) ($ev['participant']['identity'] ?? '');
        if ($rn && $identity !== '') {
            try {
                Db::q(
                    "UPDATE attendance SET left_at=NOW(),
                       duration_seconds=GREATEST(0, TIMESTAMPDIFF(SECOND, joined_at, NOW()))
                     WHERE room_code=? AND identity=? AND left_at IS NULL
                     ORDER BY id DESC LIMIT 1",
                    [$rn, $identity]
                );
            } catch (\Throwable $e) {}
        }
    } elseif ($type === 'room_finished') {
        $rn = $ev['room']['name'] ?? '';
        if ($rn) {
            $room = Db::one("SELECT * FROM rooms WHERE room_code=?", [$rn]);
            if ($room) archive_room($room);
        }
    }

    Response::ok();
}

Response::error('المسار غير موجود: /' . implode('/', $segs), 404);
