<?php
// ================================================================
//  تحميل الإعدادات + Composer autoload + دوال مساعدة عامة
// ================================================================
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

// حمّل .env عند وجوده (مفيد لسكربتات CLI؛ في الحاوية تأتي القيم من env_file)
if (is_file(__DIR__ . '/../.env')) {
    Dotenv\Dotenv::createImmutable(__DIR__ . '/..')->safeLoad();
}

/** قراءة متغيّر بيئة مع قيمة افتراضية */
function env(string $key, $default = null)
{
    $v = getenv($key);
    if ($v === false && isset($_ENV[$key]))     $v = $_ENV[$key];
    if ($v === false && isset($_SERVER[$key]))   $v = $_SERVER[$key];
    return ($v === false || $v === null) ? $default : $v;
}

// إظهار الأخطاء في التطوير فقط
if (env('APP_ENV', 'production') === 'dev') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    ini_set('display_errors', '0');
}

// ================================================================
//  الإعدادات العامة القابلة للتحرير (قوائم الجودة/المدة) + الافتراضيات
// ================================================================
/** القيم الافتراضية إن لم تكن مُخزّنة في app_settings */
function settings_defaults(): array
{
    return [
        'resolution_presets' => [
            ['label' => '144p', 'height' => 144],
            ['label' => '240p', 'height' => 240],
            ['label' => '360p', 'height' => 360],
            ['label' => '480p', 'height' => 480],
            ['label' => '720p', 'height' => 720],
        ],
        'bitrate_presets' => [
            ['label' => '200k', 'kbps' => 200],
            ['label' => '300k', 'kbps' => 300],
            ['label' => '500k', 'kbps' => 500],
            ['label' => '800k', 'kbps' => 800],
            ['label' => '1M',   'kbps' => 1000],
        ],
        'fps_presets' => [
            ['label' => '5 fps',  'fps' => 5],
            ['label' => '8 fps',  'fps' => 8],
            ['label' => '10 fps', 'fps' => 10],
            ['label' => '12 fps', 'fps' => 12],
            ['label' => '15 fps', 'fps' => 15],
        ],
        'duration_presets' => [
            ['label' => 'ساعة',     'hours' => 1],
            ['label' => 'ساعتان',   'hours' => 2],
            ['label' => '3 ساعات',  'hours' => 3],
            ['label' => '4 ساعات',  'hours' => 4],
            ['label' => '5 ساعات',  'hours' => 5],
            ['label' => '6 ساعات',  'hours' => 6],
        ],
        // توزيعات الباقات (قيم متدرّجة افتراضية قابلة للتعديل من لوحة الأدمن).
        // hours=null / maxParticipants=null ⇒ غير محدود. reset ∈ daily|weekly|monthly|off.
        // كل مستخدم مسجَّل على normal تلقائيًّا، تتجدّد شهريًّا مجانًا (تجديد كسول بلا cron).
        'plan_tiers' => [
            'normal' => ['hours' => 2,    'maxParticipants' => 10,   'reset' => 'monthly'],
            'vip1'   => ['hours' => 10,   'maxParticipants' => 25,   'reset' => 'monthly'],
            'vip2'   => ['hours' => 40,   'maxParticipants' => 100,  'reset' => 'monthly'],
            'vip3'   => ['hours' => null, 'maxParticipants' => null, 'reset' => 'off'],
        ],
    ];
}

/** اقرأ مفتاح إعداد واحدًا (مع الرجوع للافتراضي) */
function settings_get(string $key): array
{
    $defaults = settings_defaults();
    // كاش Redis قصير الأجل لقراءة ساخنة (يتدهور بأمان إن غاب Redis)
    $ck = 'set:' . $key;
    try {
        $cached = \App\Redis::get($ck);
        if (is_string($cached) && $cached !== '') {
            $val = json_decode($cached, true);
            if (is_array($val) && $val) return $val;
        }
    } catch (\Throwable $e) { /* تجاهل الكاش */ }
    try {
        $row = \App\Db::one('SELECT v FROM app_settings WHERE k = ?', [$key]);
        if ($row && isset($row['v'])) {
            $val = json_decode((string) $row['v'], true);
            if (is_array($val) && $val) {
                try { \App\Redis::setex($ck, 300, json_encode($val, JSON_UNESCAPED_UNICODE)); } catch (\Throwable $e) {}
                return $val;
            }
        }
    } catch (\Throwable $e) { /* الجدول غير موجود بعد → الافتراضي */ }
    return $defaults[$key] ?? [];
}

/** اقرأ كل قوائم الإعدادات دفعة واحدة */
function settings_all(): array
{
    $out = [];
    foreach (array_keys(settings_defaults()) as $k) $out[$k] = settings_get($k);
    return $out;
}

/** احفظ مفتاح إعداد (مصفوفة) */
function settings_set(string $key, array $value): void
{
    if (!array_key_exists($key, settings_defaults())) {
        throw new \InvalidArgumentException('مفتاح إعداد غير معروف: ' . $key);
    }
    \App\Db::q(
        'INSERT INTO app_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
        [$key, json_encode(array_values($value), JSON_UNESCAPED_UNICODE)]
    );
    // إبطال كاش القراءة
    try { \App\Redis::del('set:' . $key); } catch (\Throwable $e) {}
}

/**
 * احفظ مفتاح إعداد يحافظ على البنية الترابطية (associative) كما هي — لا يطبّق
 * array_values مثل settings_set. يُستخدم لكائنات مثل plan_tiers (مفاتيح باقات).
 */
function settings_set_raw(string $key, array $value): void
{
    if (!array_key_exists($key, settings_defaults())) {
        throw new \InvalidArgumentException('مفتاح إعداد غير معروف: ' . $key);
    }
    \App\Db::q(
        'INSERT INTO app_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)',
        [$key, json_encode($value, JSON_UNESCAPED_UNICODE)]
    );
    try { \App\Redis::del('set:' . $key); } catch (\Throwable $e) {}
}
