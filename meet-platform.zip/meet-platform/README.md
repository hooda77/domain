# منصّة الاجتماعات (Meet Platform)

منصّة اجتماعات فيديو شبيهة بـ Google Meet — LiveKit SFU + PHP-FPM + MySQL + Redis + nginx،
بواجهة عربية RTL، لوحة تحكم وأدمن، وتوزيع الغرف على عنقود نودز.

## المزايا
- غرف فيديو/صوت لحظية عبر LiveKit، مع كتم/طرد وإدارة.
- إدارة الاجتماع للمضيف (host) + مشرفين معيَّنين (co-hosts)، بالإضافة لأدمن المنصّة.
- حذف الاجتماعات المنتهية يدويًا + حذف تلقائي بعد 24 ساعة.
- **تسجيل محلي من المتصفح** (فيديو+صوت أو صوت فقط، للجميع أو لشخص معيّن) يُنزَّل MP4/WebM بلا أي تخزين على السيرفر.
- مشاركة الشاشة، دردشة، ومشاركة رابط الغرفة.

## التثبيت على Ubuntu (22.04 / 24.04)

على سيرفر نظيف بصلاحية root، بأمر واحد:

```bash
curl -fsSL https://github.com/hooda77/domain/raw/refs/heads/main/install.sh | sudo bash
```

سيسألك عن الدومين، دومين LiveKit، بريد/كلمة مرور الأدمن، ويكتشف الـ IP تلقائيًا،
ثم يحمّل الحزمة ويثبّت كل شيء. **قبل التشغيل** وجّه سجلّي `A` للدومينين إلى IP السيرفر
(انظر «متطلّبات DNS» أدناه) لتنجح شهادة TLS.

### تثبيت صامت (بدون أسئلة)
مرّر الإعدادات كمتغيّرات بيئة:

```bash
curl -fsSL https://github.com/hooda77/domain/raw/refs/heads/main/install.sh | sudo \
  APP_DOMAIN=meet.site.com \
  LIVEKIT_DOMAIN=livekit.site.com \
  ADMIN_EMAIL=admin@site.com \
  ADMIN_PASSWORD='ChangeMe!123' \
  ENABLE_TLS=y MEET_NONINTERACTIVE=1 bash
```

### أو يدويًا من الحزمة
حمّل `meet-platform.zip`، فُكّها وشغّل:

```bash
unzip meet-platform.zip && cd meet-platform
sudo bash install.sh
```

## ما الذي يفعله المثبِّت
1. يزيل أي Docker قديم ويثبّت الحزم الأساسية.
2. يولّد الأسرار في `/var/www/meet/.env` (يحافظ عليها عند إعادة التشغيل).
3. يثبّت ويضبط: MySQL، Redis (بكلمة مرور)، PHP-FPM + Composer.
4. ينشر التطبيق، يستورد المخطط + كل الهجرات، وينشئ الأدمن.
5. يثبّت LiveKit (binary + systemd)، coturn، nginx + TLS، والجدار الناري.
6. يركّب مؤقّت التنظيف الدوري (systemd timer كل ساعة).
7. **يتحقّق من كل خدمة، وما لا يعمل يعيد تشغيله ثم يعيد تثبيته تلقائيًا**، ويطبع تقريرًا.

بيانات الدخول والأسرار تُحفظ في `/root/meet-credentials.txt` وسجلّ التثبيت في `/var/log/meet-install.log`.

## متطلّبات DNS (لـ TLS)
وجّه سجلّي `A` لكل من `APP_DOMAIN` و `LIVEKIT_DOMAIN` إلى IP السيرفر قبل التثبيت
حتى تنجح شهادة Let's Encrypt. بدون ذلك يعمل الموقع على شهادة ذاتية التوقيع
ويمكن إصدار شهادة لاحقًا بإعادة التشغيل بـ `ENABLE_TLS=y`.

## إعادة التشغيل والإصلاح
السكربت idempotent — أعد تشغيله في أي وقت لإصلاح خدمة متوقّفة أو تحديث الملفات:

```bash
sudo bash install.sh
```

## الأمان (اقرأ بعد التثبيت)
- غيّر كلمة مرور الأدمن بعد أول دخول.
- الأسرار في `.env` و`meet-credentials.txt` بصلاحيات `600` — لا تشاركها.
